-- MySQL dump 10.13  Distrib 5.7.24, for osx10.14 (x86_64)
--
-- Host: localhost    Database: careto
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assets_filename_folderId_unq_idx` (`filename`,`folderId`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  KEY `categories_parentId_fk` (`parentId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorygroups_name_idx` (`name`),
  KEY `categorygroups_handle_idx` (`handle`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `categorygroups_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contactform_submissions`
--

DROP TABLE IF EXISTS `contactform_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactform_submissions` (
  `id` int(11) NOT NULL,
  `form` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `fromName` varchar(255) DEFAULT NULL,
  `fromEmail` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  CONSTRAINT `contactform_submissions_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_address` int(11) DEFAULT NULL,
  `field_businessName` text,
  `field_teaserDescription` text,
  `field_sectionDescription` text,
  `field_email` varchar(255) DEFAULT NULL,
  `field_sectionName` text,
  `field_optimizedHero` text,
  `field_optimizedImages` text,
  `field_optimizedOverview` text,
  `field_optimizedServices` text,
  `field_optimizedVideoThumbnails` text,
  `field_pageName` text,
  `field_pageTitle` text,
  `field_phone` text,
  `field_sectionTitle` text,
  `field_videoSource` varchar(255) DEFAULT NULL,
  `field_videoUrl` text,
  `field_optimizedFullPage` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_dateDeleted_idx` (`dateDeleted`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  KEY `elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  KEY `entries_parentId_fk` (`parentId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrydrafts`
--

DROP TABLE IF EXISTS `entrydrafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrydrafts_sectionId_idx` (`sectionId`),
  KEY `entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entrydrafts_siteId_idx` (`siteId`),
  KEY `entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `entrytypes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entryversions`
--

DROP TABLE IF EXISTS `entryversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entryversions_sectionId_idx` (`sectionId`),
  KEY `entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entryversions_siteId_idx` (`siteId`),
  KEY `entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_dateDeleted_idx` (`dateDeleted`),
  KEY `fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `globalsets_handle_unq_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `config` mediumtext,
  `configMap` mediumtext,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `matrixblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_contentbuilder`
--

DROP TABLE IF EXISTS `matrixcontent_contentbuilder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_contentbuilder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heading_heading` text,
  `field_text_leadText` tinyint(1) DEFAULT NULL,
  `field_text_heading` text,
  `field_text_body` text,
  `field_text_width` varchar(255) DEFAULT NULL,
  `field_text_position` varchar(255) DEFAULT NULL,
  `field_image_caption` text,
  `field_image_width` varchar(255) DEFAULT NULL,
  `field_image_position` varchar(255) DEFAULT NULL,
  `field_video_videoUrl` text,
  `field_video_videoSource` varchar(255) DEFAULT NULL,
  `field_video_caption` text,
  `field_video_width` varchar(255) DEFAULT NULL,
  `field_video_position` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_contentbuilder_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_contentbuilder_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_contentbuilder_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_contentbuilder_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_socialbuilder`
--

DROP TABLE IF EXISTS `matrixcontent_socialbuilder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_socialbuilder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_social_socialType` varchar(255) DEFAULT NULL,
  `field_social_socialHandle` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_socialbuilder_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_socialbuilder_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_socialbuilder_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_socialbuilder_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_socialmedia`
--

DROP TABLE IF EXISTS `matrixcontent_socialmedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_socialmedia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_socialMedia_socialMediaName` varchar(255) DEFAULT NULL,
  `field_socialMedia_socialMediaUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_socialmedia_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_socialmedia_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_socialmedia_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_socialmedia_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_visualbuilder`
--

DROP TABLE IF EXISTS `matrixcontent_visualbuilder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_visualbuilder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_pageSection_heading` text,
  `field_pageSection_description` text,
  `field_pageSection_position` varchar(255) DEFAULT NULL,
  `field_pageSection_button` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_visualbuilder_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_visualbuilder_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_visualbuilder_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_visualbuilder_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `migrations_pluginId_idx` (`pluginId`),
  KEY `migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagateEntries` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sections_handle_idx` (`handle`),
  KEY `sections_name_idx` (`name`),
  KEY `sections_structureId_idx` (`structureId`),
  KEY `sections_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seomatic_metabundles`
--

DROP TABLE IF EXISTS `seomatic_metabundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seomatic_metabundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) NOT NULL DEFAULT '',
  `sourceId` int(11) DEFAULT NULL,
  `sourceName` varchar(255) NOT NULL DEFAULT '',
  `sourceHandle` varchar(64) NOT NULL DEFAULT '',
  `sourceType` varchar(64) NOT NULL DEFAULT '',
  `sourceTemplate` varchar(500) DEFAULT '',
  `sourceSiteId` int(11) DEFAULT NULL,
  `sourceAltSiteSettings` text,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text,
  `metaSiteVars` text,
  `metaSitemapVars` text,
  `metaContainers` text,
  `redirectsContainer` text,
  `frontendTemplatesContainer` text,
  `metaBundleSettings` text,
  PRIMARY KEY (`id`),
  KEY `seomatic_metabundles_sourceBundleType_idx` (`sourceBundleType`),
  KEY `seomatic_metabundles_sourceId_idx` (`sourceId`),
  KEY `seomatic_metabundles_sourceSiteId_idx` (`sourceSiteId`),
  KEY `seomatic_metabundles_sourceHandle_idx` (`sourceHandle`),
  CONSTRAINT `seomatic_metabundles_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sitegroups_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sites_dateDeleted_idx` (`dateDeleted`),
  KEY `sites_handle_idx` (`handle`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sproutfields_addresses`
--

DROP TABLE IF EXISTS `sproutfields_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sproutfields_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) DEFAULT NULL,
  `siteId` int(11) DEFAULT NULL,
  `fieldId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) DEFAULT NULL,
  `administrativeAreaCode` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supertableblocks`
--

DROP TABLE IF EXISTS `supertableblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supertableblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `supertableblocks_ownerId_idx` (`ownerId`),
  KEY `supertableblocks_fieldId_idx` (`fieldId`),
  KEY `supertableblocks_typeId_idx` (`typeId`),
  KEY `supertableblocks_sortOrder_idx` (`sortOrder`),
  KEY `supertableblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `supertableblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `supertableblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `supertableblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supertableblocktypes`
--

DROP TABLE IF EXISTS `supertableblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supertableblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `supertableblocktypes_fieldId_idx` (`fieldId`),
  KEY `supertableblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `supertableblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taggroups_name_idx` (`name`),
  KEY `taggroups_handle_idx` (`handle`),
  KEY `taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_email_idx` (`email`),
  KEY `users_username_idx` (`username`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `volumes_name_idx` (`name`),
  KEY `volumes_handle_idx` (`handle`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `volumes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'careto'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-05 21:17:17
-- MySQL dump 10.13  Distrib 5.7.24, for osx10.14 (x86_64)
--
-- Host: localhost    Database: careto
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (5,2,2,'homepage_1.mp4','video',NULL,NULL,38351222,NULL,NULL,NULL,'2019-02-05 17:07:30','2019-02-05 17:07:30','2019-02-05 17:07:30','e86cbc62-99ad-4b05-a4c2-95029000f4d3'),(6,2,2,'homepage_2.mp4','video',NULL,NULL,33649590,NULL,NULL,NULL,'2019-02-05 17:07:31','2019-02-05 17:07:31','2019-02-05 17:07:31','71eaa2a7-c053-468b-bd88-6c15df564c1d'),(7,2,2,'homepage_3.mp4','video',NULL,NULL,40112481,NULL,NULL,NULL,'2019-02-05 17:07:32','2019-02-05 17:07:32','2019-02-05 17:07:32','8c01ee27-bdce-4f86-8f54-9003d9376d81'),(8,2,2,'homepage_4.mp4','video',NULL,NULL,27114498,NULL,NULL,NULL,'2019-02-05 17:07:32','2019-02-05 17:07:32','2019-02-05 17:07:32','e3a86967-8919-4d7d-b447-3409439bd6b3'),(9,2,2,'homepage_5.mp4','video',NULL,NULL,35911186,NULL,NULL,NULL,'2019-02-05 17:07:33','2019-02-05 17:07:33','2019-02-05 17:07:33','a36d39a7-1251-41fe-acb3-5ec4db9ade96'),(10,2,2,'homepage_6.mp4','video',NULL,NULL,29823315,NULL,NULL,NULL,'2019-02-05 17:07:34','2019-02-05 17:07:34','2019-02-05 17:07:34','1e0eab8a-1a94-497e-b58f-abae97897927'),(11,2,2,'homepage_7.mp4','video',NULL,NULL,31323779,NULL,NULL,NULL,'2019-02-05 17:07:35','2019-02-05 17:07:35','2019-02-05 17:07:35','a0564474-8b2b-4fdd-9d09-08764c4abba7'),(12,2,2,'homepage_8.mp4','video',NULL,NULL,38389591,NULL,NULL,NULL,'2019-02-05 17:07:35','2019-02-05 17:07:35','2019-02-05 17:07:35','d6f4bffd-1a6a-4b3b-87b5-b36278b75b0f'),(13,2,2,'homepage_9.mp4','video',NULL,NULL,57250342,NULL,NULL,NULL,'2019-02-05 17:07:37','2019-02-05 17:07:37','2019-02-05 17:07:37','a619bd20-3b50-4f26-b2fc-5b092bfcc187'),(24,1,1,'IndividueleTherapie_Subpage_1.jpg','image',1920,1080,1110092,NULL,NULL,NULL,'2019-02-05 17:53:25','2019-02-05 17:53:25','2019-02-05 17:53:25','285e9a9e-75ee-49af-bc65-47a124f8cb81'),(25,1,1,'IndividueleTherapie_Subpage_2.jpg','image',1920,1080,1260531,NULL,NULL,NULL,'2019-02-05 17:53:25','2019-02-05 17:53:25','2019-02-05 17:53:25','06e41329-35d7-424c-82fc-1160eb657571'),(26,1,1,'IndividueleTherapie_Subpage_3.jpg','image',1920,1080,954667,NULL,NULL,NULL,'2019-02-05 17:53:25','2019-02-05 17:53:26','2019-02-05 17:53:26','fecbd59f-a4d6-4ab0-bedc-2e2c8c9d1287'),(30,3,3,'IndividueleTherapie_Subpage_2.jpg','image',1920,1080,1260531,NULL,NULL,NULL,'2019-02-05 18:09:40','2019-02-05 18:09:40','2019-02-05 18:09:40','f50e5b5b-0c36-41f7-8a5e-5b33b6d12896'),(40,1,1,'careto-logo.svg','image',2141,392,4159,NULL,NULL,NULL,'2019-02-05 19:29:59','2019-02-05 19:29:59','2019-02-05 19:29:59','9422d0c8-84e7-4543-bcfa-0f4d9091afbc');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categories` VALUES (35,1,NULL,NULL,'2019-02-05 19:27:05','2019-02-05 19:27:05','a123d252-4588-4334-ac9d-77446f0d71c0'),(36,1,NULL,NULL,'2019-02-05 19:27:14','2019-02-05 19:27:14','102348ed-c901-4c6d-b28c-0ccdf296a514'),(37,1,NULL,NULL,'2019-02-05 19:27:17','2019-02-05 19:27:17','9227306e-2849-4ee6-bbb3-56726db2e147'),(38,1,NULL,NULL,'2019-02-05 19:27:30','2019-02-05 19:27:30','7eb5d9b1-75de-4b54-9aa8-836077bb1640'),(39,1,NULL,NULL,'2019-02-05 19:27:34','2019-02-05 19:27:34','70e14487-4f20-457a-93c9-479ca9ef5b39');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups` VALUES (1,1,NULL,'Blog','blog','2019-02-05 16:45:07','2019-02-05 16:45:11',NULL,'0e2ea179-556a-4404-ad6b-d2a673b23e8e');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,1,'blog/{slug}','blog/_category','2019-02-05 16:45:07','2019-02-05 16:45:11','2a5772c0-ad28-4778-8ab8-431c954a9b50');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `contactform_submissions`
--

LOCK TABLES `contactform_submissions` WRITE;
/*!40000 ALTER TABLE `contactform_submissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `contactform_submissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2019-02-05 15:44:19','2019-02-05 15:44:19','c10fc6ff-bd85-471d-ab9f-7bd706bc6a39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,2,1,'Homepage','2019-02-05 16:45:06','2019-02-05 17:58:50','abc82a5c-6b47-4e77-a948-5aad748759b5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,3,1,NULL,'2019-02-05 16:45:11','2019-02-05 16:45:11','1eae12a6-3af9-4655-8508-604e86618a5f',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,5,1,'Homepage_1','2019-02-05 17:07:30','2019-02-05 17:07:30','48d693e4-0d27-44a0-91f8-b02aa8f629d3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,6,1,'Homepage_2','2019-02-05 17:07:31','2019-02-05 17:07:31','b850b42e-37b3-4083-b386-c7345b307e82',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,7,1,'Homepage_3','2019-02-05 17:07:32','2019-02-05 17:07:32','f3596d7c-aece-4e03-882a-6168bf450717',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,8,1,'Homepage_4','2019-02-05 17:07:32','2019-02-05 17:07:32','76ef7449-f898-40e7-ab98-d7fb043542a4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,9,1,'Homepage_5','2019-02-05 17:07:33','2019-02-05 17:07:33','b86debc1-6dc0-4b50-a0c0-efde220e6fb6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,10,1,'Homepage_6','2019-02-05 17:07:34','2019-02-05 17:07:34','965a4f72-a133-4228-bf1d-beb7ace657ef',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,11,1,'Homepage_7','2019-02-05 17:07:35','2019-02-05 17:07:35','fb7cc292-88c6-4829-8dbd-47798b66e480',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,12,1,'Homepage_8','2019-02-05 17:07:35','2019-02-05 17:07:35','207ba79a-4840-4230-a2d4-2c8b024fb5bf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,13,1,'Homepage_9','2019-02-05 17:07:37','2019-02-05 17:07:37','743c4e5e-e8cb-4f17-b75b-6f2c729e29e2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,16,1,NULL,'2019-02-05 17:32:51','2019-02-05 17:34:00','3bee0004-6d5b-4df2-94a8-0fa3218e4120',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,19,1,'Familiale Bemiddeling','2019-02-05 17:44:56','2019-02-05 18:12:38','1dd2d667-1533-4c9e-a1fa-e0334f79239b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,20,1,'Individuele Therapie','2019-02-05 17:45:08','2019-02-05 17:55:51','a26c3ea4-40a9-45d1-98de-53a08f360139',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,21,1,'Relatietherapie','2019-02-05 17:45:13','2019-02-05 17:55:51','87fd36de-6c1b-4375-a64a-0caf4cc2945f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,22,1,'Love2Us','2019-02-05 17:45:30','2019-02-05 17:55:51','4afc32f1-2294-4094-9a9f-c8e842360687',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,23,1,'Bedrijfstherapie','2019-02-05 17:45:42','2019-02-05 17:55:51','813bdc50-04fc-4c3e-8631-592f7e54fffa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,24,1,'Individuele Therapie_Subpage_1','2019-02-05 17:53:24','2019-02-05 17:53:24','32509cc5-6864-4755-b065-8013f233bbfb',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"optimizedImageUrls\":{\"1200\":\"http://careto.test/assets/img/uploads/general/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_1.jpg\",\"992\":\"http://careto.test/assets/img/uploads/general/_992x558_crop_center-center_82_line/IndividueleTherapie_Subpage_1.jpg\",\"768\":\"http://careto.test/assets/img/uploads/general/_768x576_crop_center-center_60_line/IndividueleTherapie_Subpage_1.jpg\",\"576\":\"http://careto.test/assets/img/uploads/general/_576x432_crop_center-center_60_line/IndividueleTherapie_Subpage_1.jpg\",\"1152\":\"http://careto.test/assets/img/uploads/general/_1152x864_crop_center-center_45_line/IndividueleTherapie_Subpage_1.jpg\"},\"optimizedWebPImageUrls\":{\"1200\":\"http://careto.test/assets/img/uploads/general/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_1.jpg.webp\",\"992\":\"http://careto.test/assets/img/uploads/general/_992x558_crop_center-center_82_line/IndividueleTherapie_Subpage_1.jpg.webp\",\"768\":\"http://careto.test/assets/img/uploads/general/_768x576_crop_center-center_60_line/IndividueleTherapie_Subpage_1.jpg.webp\",\"576\":\"http://careto.test/assets/img/uploads/general/_576x432_crop_center-center_60_line/IndividueleTherapie_Subpage_1.jpg.webp\",\"1152\":\"http://careto.test/assets/img/uploads/general/_1152x864_crop_center-center_45_line/IndividueleTherapie_Subpage_1.jpg.webp\"},\"variantSourceWidths\":[\"1200\",\"992\",\"768\",\"576\",\"576\"],\"variantHeights\":{\"1200\":675,\"992\":558,\"768\":576,\"576\":432,\"1152\":864},\"focalPoint\":{\"x\":0.5,\"y\":0.5},\"originalImageWidth\":\"1920\",\"originalImageHeight\":\"1080\",\"placeholder\":\"/9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2OTApLCBxdWFsaXR5ID0gNTAK/9sAQwAQCwwODAoQDg0OEhEQExgoGhgWFhgxIyUdKDozPTw5Mzg3QEhcTkBEV0U3OFBtUVdfYmdoZz5NcXlwZHhcZWdj/9sAQwEREhIYFRgvGhovY0I4QmNjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2Nj/8AAEQgACQAQAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8Amg1WGe88pGXywOGznd6YweKvedCy5WVCPXcK880z/j/g/wB4Vpan/wAeK/74/lVpEOdj/9k=\",\"placeholderSvg\":\"%3Csvg id=\'svg\' version=\'1.1\' width=\'300\' height=\'168\' style=\'background-color: %23FEFEFE\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M78.500 54.169 C 76.850 54.755%2C74.825 55.632%2C74.000 56.119 C 73.175 56.606%2C71.531 57.426%2C70.347 57.941 C 67.330 59.253%2C66.606 60.820%2C68.156 62.688 C 69.314 64.083%2C69.223 64.206%2C67.455 63.644 C 65.853 63.136%2C65.390 63.471%2C65.257 65.235 C 65.165 66.465%2C64.619 67.627%2C64.044 67.819 C 63.470 68.010%2C63.000 69.003%2C63.000 70.024 C 63.000 71.046%2C62.550 72.160%2C62.000 72.500 C 59.874 73.814%2C60.921 76.237%2C63.352 75.627 C 66.817 74.757%2C67.196 75.876%2C64.441 78.847 C 61.746 81.753%2C61.343 83.594%2C63.250 84.288 C 64.960 84.910%2C62.905 88.378%2C60.552 88.841 C 58.035 89.336%2C54.507 85.299%2C55.944 83.568 C 56.810 82.524%2C56.494 82.090%2C54.506 81.591 C 51.849 80.924%2C48.000 82.370%2C48.000 84.035 C 48.000 84.566%2C46.085 85.000%2C43.743 85.000 C 41.402 85.000%2C38.090 85.401%2C36.383 85.890 C 33.361 86.757%2C32.205 87.536%2C25.477 93.248 C 21.853 96.325%2C15.738 107.995%2C13.932 115.283 C 12.552 120.850%2C10.215 122.619%2C6.125 121.193 C 0.270 119.152%2C0.000 120.219%2C0.000 145.360 L 0.000 168.000 106.465 168.000 C 200.843 168.000%2C213.458 167.821%2C217.581 166.421 C 220.140 165.552%2C223.263 165.100%2C224.522 165.416 C 226.449 165.900%2C226.726 165.667%2C226.275 163.944 C 225.808 162.159%2C226.077 161.981%2C228.370 162.557 C 230.951 163.205%2C231.000 163.123%2C231.000 158.144 C 231.000 154.198%2C230.581 152.846%2C229.116 152.062 C 228.080 151.508%2C226.944 149.517%2C226.592 147.638 C 225.808 143.460%2C221.072 140.850%2C217.885 142.840 C 216.339 143.805%2C216.000 143.735%2C216.000 142.449 C 216.000 141.587%2C215.605 141.126%2C215.121 141.425 C 214.638 141.724%2C212.780 141.238%2C210.993 140.347 C 206.827 138.268%2C199.486 137.404%2C198.571 138.885 C 197.614 140.433%2C193.843 140.279%2C191.436 138.593 C 190.330 137.818%2C188.318 137.155%2C186.963 137.118 C 178.518 136.890%2C170.200 135.516%2C167.261 133.866 C 163.514 131.761%2C156.792 132.757%2C154.301 135.786 C 153.255 137.057%2C152.893 137.036%2C151.479 135.622 C 149.494 133.637%2C148.000 133.532%2C148.000 135.378 C 148.000 136.135%2C147.344 137.299%2C146.542 137.965 C 145.580 138.764%2C145.283 140.164%2C145.667 142.087 C 146.024 143.872%2C145.830 145.000%2C145.165 145.000 C 144.103 145.000%2C144.013 145.830%2C144.076 155.000 C 144.101 158.605%2C143.858 159.251%2C142.854 158.250 C 141.169 156.571%2C140.000 156.673%2C140.000 158.500 C 140.000 160.240%2C137.441 160.522%2C136.434 158.893 C 135.957 158.122%2C135.493 158.198%2C134.903 159.143 C 133.489 161.410%2C130.645 158.804%2C129.190 153.908 C 128.469 151.484%2C127.156 147.925%2C126.271 146.000 C 125.386 144.075%2C124.765 141.534%2C124.889 140.353 C 125.183 137.573%2C122.389 126.862%2C121.170 126.092 C 114.026 121.582%2C105.074 112.466%2C97.181 101.666 C 93.531 96.672%2C93.781 94.500%2C98.351 91.506 C 100.658 89.994%2C104.000 81.431%2C104.000 77.030 C 104.000 75.768%2C104.945 73.208%2C106.099 71.340 C 107.687 68.771%2C107.926 67.616%2C107.082 66.599 C 106.468 65.859%2C106.208 64.621%2C106.505 63.848 C 107.325 61.710%2C104.294 58.111%2C103.144 59.857 C 102.194 61.299%2C100.440 59.715%2C101.352 58.239 C 101.611 57.820%2C101.188 56.609%2C100.411 55.548 C 99.180 53.864%2C99.000 53.834%2C99.000 55.309 C 99.000 56.239%2C98.550 57.000%2C98.000 57.000 C 97.450 57.000%2C97.000 56.550%2C97.000 56.000 C 97.000 55.450%2C96.663 55.053%2C96.250 55.118 C 95.838 55.184%2C95.275 55.149%2C95.000 55.042 C 90.906 53.446%2C81.884 52.969%2C78.500 54.169 M88.148 73.250 C 88.229 74.488%2C88.342 76.308%2C88.398 77.295 C 88.454 78.282%2C89.560 80.194%2C90.855 81.545 C 92.150 82.895%2C92.686 84.000%2C92.046 84.000 C 91.406 84.000%2C91.141 84.419%2C91.457 84.931 C 92.414 86.478%2C90.780 86.756%2C84.787 86.063 C 78.540 85.341%2C77.569 86.657%2C81.305 90.784 C 83.396 93.095%2C83.451 94.000%2C81.500 94.000 C 80.675 94.000%2C79.990 94.563%2C79.977 95.250 C 79.965 95.938%2C79.233 95.038%2C78.352 93.250 C 77.471 91.463%2C76.342 90.000%2C75.843 90.000 C 75.344 90.000%2C74.548 88.988%2C74.075 87.750 C 72.990 84.912%2C75.940 81.392%2C80.185 80.459 C 82.828 79.879%2C83.054 79.523%2C82.471 76.867 C 81.730 73.496%2C83.284 71.000%2C86.122 71.000 C 87.359 71.000%2C88.051 71.768%2C88.148 73.250 M25.000 103.878 C 25.000 106.977%2C24.457 109.206%2C23.511 109.991 C 20.860 112.191%2C22.879 112.841%2C27.749 111.356 C 35.726 108.923%2C43.426 111.555%2C42.232 116.307 C 41.929 117.513%2C41.078 118.860%2C40.341 119.300 C 38.157 120.602%2C38.810 122.843%2C41.474 123.184 C 43.411 123.431%2C43.736 123.825%2C42.974 125.000 C 42.108 126.333%2C41.891 126.333%2C41.015 125.000 C 40.213 123.779%2C40.028 123.761%2C40.015 124.905 C 40.003 126.022%2C39.626 125.971%2C38.171 124.655 C 36.089 122.771%2C33.518 122.411%2C34.595 124.155 C 35.038 124.870%2C34.870 125.038%2C34.155 124.595 C 33.425 124.144%2C33.000 124.639%2C33.000 125.941 C 33.000 127.073%2C32.373 128.000%2C31.607 128.000 C 30.841 128.000%2C29.955 128.675%2C29.638 129.500 C 29.322 130.325%2C28.388 131.000%2C27.563 131.000 C 26.640 131.000%2C26.284 130.422%2C26.638 129.500 C 26.955 128.675%2C26.705 128.000%2C26.082 128.000 C 24.456 128.000%2C23.114 132.143%2C23.717 135.301 C 24.143 137.530%2C23.873 138.000%2C22.162 138.000 C 19.622 138.000%2C18.581 133.590%2C18.993 124.583 C 19.146 121.237%2C19.276 115.463%2C19.282 111.750 C 19.288 108.038%2C19.567 105.000%2C19.902 105.000 C 20.237 105.000%2C21.109 103.650%2C21.840 102.000 C 23.784 97.607%2C25.000 98.330%2C25.000 103.878 M100.172 132.668 C 104.541 136.934%2C105.568 141.632%2C101.875 140.460 C 100.546 140.039%2C99.415 140.294%2C98.856 141.143 C 98.135 142.238%2C97.676 142.125%2C96.481 140.559 C 95.666 139.491%2C94.955 139.041%2C94.900 139.559 C 94.845 140.076%2C94.488 139.376%2C94.106 138.002 C 93.521 135.900%2C92.570 135.371%2C88.104 134.660 L 82.797 133.815 86.148 130.893 C 90.633 126.982%2C94.903 127.523%2C100.172 132.668 M271.314 142.375 C 271.773 143.572%2C271.263 144.330%2C269.563 144.976 C 266.319 146.209%2C263.000 145.861%2C263.000 144.287 C 263.000 143.579%2C262.523 143.000%2C261.941 143.000 C 261.359 143.000%2C261.203 143.520%2C261.595 144.155 C 262.038 144.870%2C261.870 145.038%2C261.155 144.595 C 260.478 144.177%2C260.000 144.503%2C260.000 145.382 C 260.000 146.207%2C259.532 147.171%2C258.960 147.525 C 258.278 147.946%2C258.158 147.221%2C258.610 145.419 C 259.208 143.034%2C259.056 142.764%2C257.456 143.378 C 256.443 143.767%2C253.508 143.546%2C250.935 142.887 C 245.856 141.585%2C241.339 142.338%2C244.028 144.038 C 245.225 144.796%2C245.127 144.978%2C243.500 145.016 C 241.724 145.058%2C241.678 145.200%2C243.088 146.282 C 243.961 146.952%2C244.498 148.027%2C244.281 148.671 C 244.026 149.428%2C244.703 149.665%2C246.193 149.341 C 248.486 148.843%2C248.484 148.855%2C245.932 151.216 C 244.519 152.522%2C243.544 154.133%2C243.765 154.796 C 243.986 155.458%2C243.712 156.000%2C243.157 156.000 C 242.601 156.000%2C241.941 155.213%2C241.689 154.250 C 241.414 153.197%2C241.186 153.619%2C241.116 155.309 C 241.052 156.854%2C240.592 157.866%2C240.093 157.558 C 239.594 157.249%2C239.451 158.009%2C239.774 159.249 C 240.328 161.372%2C240.264 161.403%2C238.652 159.792 C 237.023 158.166%2C233.476 158.343%2C234.500 160.000 C 234.769 160.435%2C234.288 161.059%2C233.431 161.388 C 232.574 161.717%2C232.122 162.388%2C232.425 162.879 C 232.729 163.371%2C232.083 164.007%2C230.989 164.293 C 229.895 164.579%2C229.000 165.530%2C229.000 166.406 C 229.000 167.835%2C232.684 168.000%2C264.500 168.000 L 300.000 168.000 300.000 154.941 C 300.000 146.608%2C299.643 142.103%2C299.013 142.492 C 298.471 142.827%2C296.363 142.642%2C294.330 142.081 C 292.296 141.519%2C290.153 141.392%2C289.566 141.799 C 288.331 142.655%2C284.874 142.567%2C276.583 141.469 C 271.260 140.764%2C270.730 140.855%2C271.314 142.375 \' stroke=\'none\' fill=\'%23C0CFD6\' fill-rule=\'evenodd\'/%3E%3C/svg%3E\",\"colorPalette\":[\"#aca9b5\",\"#1f2a2f\",\"#3f5e6a\",\"#796c6c\",\"#69545c\"],\"placeholderWidth\":1200,\"placeholderHeight\":675}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,25,1,'Individuele Therapie_Subpage_2','2019-02-05 17:53:25','2019-02-05 17:53:25','d2bfdab7-a1a4-489a-a64e-31abc0f88b96',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"optimizedImageUrls\":{\"1200\":\"http://careto.test/assets/img/uploads/general/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg\",\"992\":\"http://careto.test/assets/img/uploads/general/_992x558_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg\",\"768\":\"http://careto.test/assets/img/uploads/general/_768x576_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg\",\"576\":\"http://careto.test/assets/img/uploads/general/_576x432_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg\",\"1152\":\"http://careto.test/assets/img/uploads/general/_1152x864_crop_center-center_45_line/IndividueleTherapie_Subpage_2.jpg\"},\"optimizedWebPImageUrls\":{\"1200\":\"http://careto.test/assets/img/uploads/general/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"992\":\"http://careto.test/assets/img/uploads/general/_992x558_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"768\":\"http://careto.test/assets/img/uploads/general/_768x576_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"576\":\"http://careto.test/assets/img/uploads/general/_576x432_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"1152\":\"http://careto.test/assets/img/uploads/general/_1152x864_crop_center-center_45_line/IndividueleTherapie_Subpage_2.jpg.webp\"},\"variantSourceWidths\":[\"1200\",\"992\",\"768\",\"576\",\"576\"],\"variantHeights\":{\"1200\":675,\"992\":558,\"768\":576,\"576\":432,\"1152\":864},\"focalPoint\":{\"x\":0.5,\"y\":0.5},\"originalImageWidth\":\"1920\",\"originalImageHeight\":\"1080\",\"placeholder\":\"/9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2OTApLCBxdWFsaXR5ID0gNTAK/9sAQwAQCwwODAoQDg0OEhEQExgoGhgWFhgxIyUdKDozPTw5Mzg3QEhcTkBEV0U3OFBtUVdfYmdoZz5NcXlwZHhcZWdj/9sAQwEREhIYFRgvGhovY0I4QmNjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2Nj/8AAEQgACQAQAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8Ap2Gr6aIwGt44j6qu4j3qlq80F9KRaQs5J+VlTGRWBF/rV+tWk/1o/wB2s1BXuaObsf/Z\",\"placeholderSvg\":\"%3Csvg id=\'svg\' version=\'1.1\' width=\'300\' height=\'168\' style=\'background-color: %23FEFEFE\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0.000 17.035 C 0.000 33.426%2C0.071 34.032%2C1.889 33.060 C 4.703 31.553%2C9.038 31.490%2C13.230 32.893 C 15.282 33.580%2C17.454 33.837%2C18.057 33.465 C 18.659 33.093%2C21.481 32.665%2C24.326 32.515 C 30.744 32.177%2C31.421 32.004%2C36.645 29.363 C 40.256 27.538%2C40.957 27.445%2C41.448 28.726 C 41.835 29.733%2C42.430 29.918%2C43.262 29.289 C 45.219 27.810%2C57.099 25.925%2C61.500 26.396 C 65.759 26.852%2C68.805 25.477%2C72.702 21.338 C 74.822 19.088%2C80.000 18.059%2C80.000 19.889 C 80.000 20.377%2C81.620 21.081%2C83.601 21.453 C 85.581 21.824%2C88.703 22.845%2C90.539 23.720 C 93.619 25.189%2C94.077 25.180%2C96.478 23.606 C 99.593 21.565%2C115.838 19.782%2C117.750 21.271 C 118.649 21.971%2C119.022 21.719%2C119.079 20.372 C 119.123 19.319%2C119.378 19.047%2C119.662 19.750 C 119.940 20.438%2C120.831 21.000%2C121.642 21.000 C 122.454 21.000%2C122.870 20.598%2C122.566 20.107 C 122.262 19.615%2C123.136 18.932%2C124.507 18.588 C 125.878 18.243%2C127.000 17.403%2C127.000 16.721 C 127.000 13.721%2C132.169 9.796%2C135.378 10.358 C 144.490 11.955%2C145.544 12.049%2C143.315 11.071 C 142.114 10.544%2C140.635 9.187%2C140.030 8.056 C 138.570 5.328%2C140.689 5.313%2C147.761 8.001 C 150.654 9.100%2C154.115 10.000%2C155.451 10.000 C 156.787 10.000%2C160.945 11.076%2C164.690 12.391 C 168.436 13.706%2C172.625 15.041%2C174.000 15.359 C 175.375 15.677%2C179.425 18.883%2C183.000 22.484 C 189.978 29.512%2C195.125 33.267%2C197.205 32.847 C 201.613 31.957%2C204.000 33.973%2C204.000 38.586 C 204.000 42.680%2C203.800 43.071%2C202.000 42.500 C 200.853 42.136%2C200.000 42.320%2C200.000 42.933 C 200.000 43.520%2C200.477 44.000%2C201.059 44.000 C 201.641 44.000%2C201.840 44.450%2C201.500 45.000 C 200.075 47.306%2C202.336 48.206%2C204.003 45.997 C 205.697 43.750%2C205.758 43.744%2C208.796 45.538 C 210.488 46.538%2C212.114 48.318%2C212.409 49.494 C 212.704 50.669%2C213.861 52.686%2C214.979 53.976 C 217.409 56.778%2C217.112 57.317%2C213.618 56.440 C 212.028 56.041%2C211.000 55.088%2C211.000 54.014 C 211.000 53.041%2C210.325 51.685%2C209.500 51.000 C 208.464 50.140%2C208.000 50.102%2C208.000 50.878 C 208.000 51.495%2C207.373 52.000%2C206.607 52.000 C 205.841 52.000%2C204.931 52.736%2C204.586 53.636 C 204.005 55.151%2C203.824 55.150%2C202.148 53.634 C 201.152 52.733%2C200.089 52.245%2C199.784 52.549 C 199.480 52.853%2C198.758 51.745%2C198.180 50.086 C 197.443 47.973%2C196.286 46.895%2C194.314 46.483 C 192.766 46.160%2C188.968 44.569%2C185.873 42.948 C 182.696 41.284%2C178.690 40.000%2C176.672 40.000 C 174.707 40.000%2C170.837 39.515%2C168.073 38.922 C 161.398 37.491%2C158.108 38.260%2C163.882 39.902 C 166.293 40.588%2C169.105 41.673%2C170.132 42.315 C 172.412 43.738%2C172.586 46.000%2C170.417 46.000 C 169.546 46.000%2C169.017 46.563%2C169.242 47.250 C 169.802 48.966%2C176.248 51.051%2C177.450 49.906 C 178.785 48.633%2C181.745 48.778%2C182.597 50.158 C 183.087 50.951%2C182.634 51.138%2C181.157 50.751 C 179.972 50.441%2C178.750 50.596%2C178.442 51.094 C 178.134 51.592%2C178.632 52.000%2C179.548 52.000 C 180.618 52.000%2C181.008 52.537%2C180.638 53.500 C 179.902 55.419%2C181.422 55.435%2C183.329 53.528 C 184.563 52.294%2C184.984 52.276%2C185.926 53.411 C 186.783 54.443%2C186.682 54.908%2C185.503 55.361 C 184.225 55.851%2C184.170 56.299%2C185.186 57.926 C 186.170 59.501%2C186.707 59.658%2C187.853 58.707 C 189.047 57.716%2C189.173 57.879%2C188.604 59.674 C 188.223 60.872%2C188.388 62.122%2C188.976 62.485 C 189.557 62.844%2C189.797 63.519%2C189.509 63.985 C 189.221 64.451%2C189.479 66.107%2C190.082 67.666 C 191.678 71.794%2C192.148 73.964%2C192.537 79.000 C 192.728 81.475%2C193.154 85.525%2C193.484 88.000 C 193.857 90.808%2C193.743 91.998%2C193.180 91.166 C 192.455 90.094%2C192.153 90.158%2C191.642 91.490 C 190.607 94.187%2C187.629 90.616%2C188.388 87.590 C 188.713 86.297%2C188.340 83.498%2C187.560 81.370 C 186.779 79.241%2C186.109 78.089%2C186.070 78.809 C 185.968 80.707%2C184.029 79.206%2C182.963 76.403 C 181.384 72.251%2C180.503 73.759%2C180.423 80.749 C 180.344 87.645%2C179.142 96.000%2C178.229 96.000 C 177.949 96.000%2C177.165 95.241%2C176.487 94.313 C 175.359 92.770%2C175.194 92.814%2C174.555 94.827 C 174.171 96.037%2C170.401 99.609%2C166.178 102.764 C 158.667 108.375%2C158.358 108.500%2C151.973 108.500 C 145.918 108.500%2C145.118 108.231%2C140.895 104.770 C 138.391 102.718%2C135.371 100.891%2C134.183 100.710 C 132.995 100.529%2C130.986 99.479%2C129.718 98.377 C 128.450 97.274%2C126.645 96.078%2C125.707 95.718 C 124.768 95.357%2C124.000 94.572%2C124.000 93.972 C 124.000 91.883%2C121.999 94.134%2C121.924 96.309 C 121.866 97.990%2C121.534 97.686%2C120.500 95.000 C 119.282 91.838%2C119.139 91.741%2C119.013 94.000 L 118.873 96.500 117.885 94.024 C 117.078 92.002%2C116.726 91.819%2C115.964 93.024 C 115.264 94.132%2C115.023 93.751%2C115.000 91.500 C 114.976 89.193%2C114.746 88.846%2C114.000 90.000 C 113.251 91.159%2C113.010 90.818%2C112.938 88.500 C 112.850 85.615%2C112.796 85.653%2C111.528 89.500 L 110.210 93.500 110.105 89.309 C 110.004 85.292%2C108.000 81.902%2C108.000 85.750 C 108.000 86.777%2C107.339 88.491%2C106.532 89.559 C 105.086 91.470%2C105.063 91.469%2C105.032 89.463 C 104.992 86.938%2C101.435 86.417%2C100.642 88.820 C 100.337 89.744%2C98.954 92.405%2C97.569 94.733 C 96.150 97.116%2C95.321 99.673%2C95.671 100.584 C 96.127 101.773%2C95.801 102.108%2C94.440 101.846 C 92.383 101.450%2C91.304 98.522%2C90.993 92.500 C 90.793 88.620%2C90.755 88.580%2C89.732 91.161 L 88.676 93.822 86.918 91.661 C 85.210 89.563%2C85.073 89.550%2C82.193 91.239 C 79.558 92.785%2C79.087 92.810%2C77.972 91.467 C 77.282 90.635%2C75.964 90.194%2C75.042 90.487 C 73.298 91.040%2C68.859 85.361%2C67.453 80.776 C 66.475 77.586%2C64.957 75.909%2C63.733 76.665 C 63.027 77.102%2C62.911 75.169%2C63.374 70.654 C 64.090 63.668%2C63.490 62.696%2C60.500 66.000 C 58.210 68.531%2C56.783 68.523%2C54.471 65.968 C 53.460 64.851%2C51.928 64.027%2C51.066 64.137 C 50.205 64.247%2C48.280 63.747%2C46.789 63.026 C 44.412 61.876%2C42.074 62.155%2C27.789 65.298 C 18.830 67.269%2C9.700 69.173%2C7.500 69.528 C -0.831 70.875%2C0.000 65.329%2C0.000 119.567 L 0.000 168.000 150.000 168.000 L 300.000 168.000 299.994 155.750 L 299.989 143.500 295.744 143.365 C 292.521 143.263%2C291.981 143.443%2C293.500 144.113 C 294.921 144.739%2C294.523 144.820%2C292.125 144.391 C 289.912 143.994%2C288.971 144.144%2C289.391 144.824 C 289.744 145.395%2C289.575 146.144%2C289.016 146.490 C 288.457 146.835%2C288.000 146.586%2C288.000 145.937 C 288.000 145.056%2C287.618 145.072%2C286.500 146.000 C 285.675 146.685%2C284.944 146.965%2C284.875 146.622 C 284.806 146.280%2C284.694 145.565%2C284.625 145.032 C 284.556 144.500%2C283.701 143.131%2C282.723 141.990 C 280.729 139.661%2C278.802 140.154%2C279.625 142.782 C 280.124 144.375%2C280.058 144.372%2C278.721 142.750 C 277.928 141.788%2C276.782 141.000%2C276.175 141.000 C 274.768 141.000%2C272.847 144.513%2C273.756 145.423 C 274.537 146.204%2C272.132 147.962%2C270.250 147.985 C 269.563 147.993%2C269.000 147.293%2C269.000 146.429 C 269.000 144.566%2C271.493 141.827%2C272.381 142.714 C 272.721 143.055%2C273.000 142.103%2C273.000 140.599 C 273.000 138.320%2C273.333 137.971%2C275.000 138.500 C 276.377 138.937%2C277.000 138.680%2C277.000 137.673 C 277.000 136.825%2C277.945 136.210%2C279.250 136.208 C 280.488 136.205%2C283.075 135.783%2C285.000 135.269 C 289.274 134.127%2C296.893 134.802%2C294.861 136.143 C 293.485 137.051%2C296.940 141.000%2C299.111 141.000 C 299.621 141.000%2C300.000 110.978%2C300.000 70.500 L 300.000 0.000 150.000 0.000 L 0.000 0.000 0.000 17.035 M140.201 36.093 C 136.990 36.749%2C131.748 40.000%2C133.900 40.000 C 134.917 40.000%2C134.971 40.330%2C134.122 41.353 C 133.195 42.470%2C133.915 42.624%2C138.249 42.236 C 143.254 41.787%2C147.513 40.000%2C143.578 40.000 C 142.038 40.000%2C141.956 39.757%2C143.053 38.436 C 143.781 37.559%2C145.263 37.078%2C146.426 37.341 C 147.567 37.599%2C149.400 37.463%2C150.500 37.039 C 153.113 36.032%2C144.409 35.232%2C140.201 36.093 \' stroke=\'none\' fill=\'%23C0CFD6\' fill-rule=\'evenodd\'/%3E%3C/svg%3E\",\"colorPalette\":[\"#37261b\",\"#cbac8c\",\"#926748\",\"#a78e77\",\"#848484\"],\"placeholderWidth\":1200,\"placeholderHeight\":675}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,26,1,'Individuele Therapie_Subpage_3','2019-02-05 17:53:25','2019-02-05 17:53:25','ae90d341-14c7-4c0b-8186-7a6b48d34e3e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"optimizedImageUrls\":{\"1200\":\"http://careto.test/assets/img/uploads/general/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_3.jpg\",\"992\":\"http://careto.test/assets/img/uploads/general/_992x558_crop_center-center_82_line/IndividueleTherapie_Subpage_3.jpg\",\"768\":\"http://careto.test/assets/img/uploads/general/_768x576_crop_center-center_60_line/IndividueleTherapie_Subpage_3.jpg\",\"576\":\"http://careto.test/assets/img/uploads/general/_576x432_crop_center-center_60_line/IndividueleTherapie_Subpage_3.jpg\",\"1152\":\"http://careto.test/assets/img/uploads/general/_1152x864_crop_center-center_45_line/IndividueleTherapie_Subpage_3.jpg\"},\"optimizedWebPImageUrls\":{\"1200\":\"http://careto.test/assets/img/uploads/general/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_3.jpg.webp\",\"992\":\"http://careto.test/assets/img/uploads/general/_992x558_crop_center-center_82_line/IndividueleTherapie_Subpage_3.jpg.webp\",\"768\":\"http://careto.test/assets/img/uploads/general/_768x576_crop_center-center_60_line/IndividueleTherapie_Subpage_3.jpg.webp\",\"576\":\"http://careto.test/assets/img/uploads/general/_576x432_crop_center-center_60_line/IndividueleTherapie_Subpage_3.jpg.webp\",\"1152\":\"http://careto.test/assets/img/uploads/general/_1152x864_crop_center-center_45_line/IndividueleTherapie_Subpage_3.jpg.webp\"},\"variantSourceWidths\":[\"1200\",\"992\",\"768\",\"576\",\"576\"],\"variantHeights\":{\"1200\":675,\"992\":558,\"768\":576,\"576\":432,\"1152\":864},\"focalPoint\":{\"x\":0.5,\"y\":0.5},\"originalImageWidth\":\"1920\",\"originalImageHeight\":\"1080\",\"placeholder\":\"/9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2OTApLCBxdWFsaXR5ID0gNTAK/9sAQwAQCwwODAoQDg0OEhEQExgoGhgWFhgxIyUdKDozPTw5Mzg3QEhcTkBEV0U3OFBtUVdfYmdoZz5NcXlwZHhcZWdj/9sAQwEREhIYFRgvGhovY0I4QmNjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2Nj/8AAEQgACQAQAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8AqQ2trKDskDY64B4qW6sbWGKMGVSWyQQDz261Lon/ACC5/wDdb+Rpl5/x42P/AFzf+dDqyKhTi3r5n//Z\",\"placeholderSvg\":\"%3Csvg id=\'svg\' version=\'1.1\' width=\'300\' height=\'168\' style=\'background-color: %23FEFEFE\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0.000 43.000 L 0.000 86.000 2.250 85.983 C 3.488 85.973%2C7.650 85.298%2C11.500 84.483 C 15.349 83.667%2C19.651 83.000%2C21.058 83.000 C 22.466 83.000%2C24.491 82.339%2C25.559 81.532 C 26.626 80.724%2C29.611 80.049%2C32.191 80.032 C 34.771 80.014%2C37.160 79.550%2C37.500 79.000 C 37.840 78.450%2C39.857 78.000%2C41.983 78.000 C 44.108 78.000%2C48.019 77.573%2C50.674 77.051 C 53.328 76.529%2C58.103 75.593%2C61.285 74.971 C 67.802 73.698%2C132.831 73.460%2C162.900 74.599 C 176.647 75.120%2C181.121 75.006%2C180.591 74.148 C 180.115 73.378%2C180.908 73.000%2C183.000 73.000 C 185.102 73.000%2C185.886 72.624%2C185.405 71.845 C 184.985 71.167%2C185.128 70.961%2C185.752 71.346 C 186.420 71.759%2C187.073 70.060%2C187.518 66.751 C 188.600 58.693%2C190.234 57.254%2C189.505 65.000 C 189.169 68.575%2C188.645 73.127%2C188.341 75.115 C 187.825 78.485%2C188.015 78.820%2C191.144 80.050 C 192.990 80.776%2C194.819 81.543%2C195.208 81.754 C 195.597 81.966%2C195.282 80.867%2C194.506 79.313 C 193.731 77.759%2C192.962 74.015%2C192.798 70.994 C 192.634 67.972%2C192.095 65.207%2C191.600 64.848 C 190.422 63.996%2C190.661 50.360%2C191.921 46.500 C 192.631 44.326%2C192.752 46.323%2C192.362 53.750 C 191.992 60.800%2C192.163 64.000%2C192.912 64.000 C 193.510 64.000%2C194.076 62.088%2C194.168 59.750 L 194.336 55.500 194.740 59.443 C 195.049 62.463%2C195.383 63.048%2C196.166 61.943 C 196.986 60.786%2C197.073 60.857%2C196.606 62.302 C 196.218 63.500%2C196.407 63.866%2C197.169 63.396 C 197.950 62.913%2C198.134 63.381%2C197.745 64.868 C 196.924 68.006%2C198.674 73.459%2C201.627 76.969 C 204.394 80.257%2C203.760 80.921%2C200.223 78.443 C 198.168 77.005%2C198.000 77.025%2C198.000 78.716 C 198.000 79.776%2C199.452 81.327%2C201.454 82.405 C 203.353 83.428%2C205.871 85.163%2C207.049 86.260 L 209.190 88.255 211.345 86.051 C 212.851 84.512%2C213.048 83.930%2C212.000 84.121 C 211.175 84.272%2C208.925 83.373%2C207.000 82.125 L 203.500 79.855 207.000 80.543 C 208.925 80.921%2C210.991 81.625%2C211.592 82.107 C 213.248 83.435%2C213.969 82.094%2C213.326 78.882 C 212.765 76.075%2C214.174 74.855%2C215.500 77.000 C 216.544 78.689%2C220.590 78.110%2C222.500 76.000 C 225.061 73.170%2C226.000 73.508%2C226.000 77.259 C 226.000 81.174%2C229.225 83.888%2C231.567 81.944 C 232.343 81.300%2C232.731 80.374%2C232.430 79.887 C 231.191 77.881%2C233.874 79.177%2C235.253 81.250 C 236.700 83.425%2C236.793 83.300%2C238.042 77.500 L 239.335 71.500 240.312 75.500 C 240.849 77.700%2C241.786 79.831%2C242.394 80.235 C 243.002 80.639%2C243.167 80.976%2C242.760 80.985 C 242.353 80.993%2C242.779 81.887%2C243.706 82.970 C 245.787 85.400%2C246.550 84.896%2C245.046 82.086 C 243.689 79.550%2C244.736 79.340%2C246.721 81.750 C 248.095 83.417%2C248.137 83.417%2C247.613 81.750 C 247.145 80.262%2C247.733 80.000%2C251.531 80.000 C 253.989 80.000%2C256.000 80.450%2C256.000 81.000 C 256.000 81.550%2C255.100 82.000%2C254.000 82.000 C 251.536 82.000%2C251.358 83.683%2C253.750 84.361 C 254.713 84.634%2C259.325 85.147%2C264.000 85.501 C 268.979 85.878%2C274.256 86.943%2C276.739 88.072 C 279.071 89.133%2C282.189 90.000%2C283.669 90.000 C 287.906 90.000%2C296.000 94.055%2C296.000 96.178 C 296.000 97.333%2C296.732 98.000%2C298.000 98.000 C 299.973 98.000%2C300.000 97.333%2C300.000 49.000 L 300.000 0.000 150.000 0.000 L 0.000 0.000 0.000 43.000 M223.453 20.161 C 224.854 20.799%2C226.037 21.586%2C226.082 21.911 C 226.127 22.235%2C226.368 23.738%2C226.616 25.250 C 226.938 27.206%2C226.645 28.000%2C225.602 28.000 C 224.795 28.000%2C223.843 28.919%2C223.487 30.042 C 223.041 31.446%2C222.276 31.905%2C221.038 31.512 C 219.175 30.921%2C217.485 33.357%2C218.556 35.090 C 218.865 35.591%2C218.332 36.000%2C217.372 36.000 C 215.941 36.000%2C216.120 36.516%2C218.360 38.854 C 219.864 40.424%2C221.443 43.012%2C221.868 44.604 C 222.518 47.040%2C223.372 47.659%2C227.243 48.500 C 233.457 49.850%2C233.483 49.908%2C231.494 58.025 C 228.481 70.318%2C222.527 74.385%2C213.783 70.122 C 204.338 65.518%2C200.854 59.625%2C203.331 52.442 C 204.589 48.794%2C204.999 48.477%2C208.845 48.193 C 211.130 48.023%2C213.000 47.408%2C213.000 46.826 C 213.000 46.239%2C211.899 45.977%2C210.530 46.239 C 209.021 46.527%2C208.303 46.318%2C208.685 45.701 C 209.040 45.127%2C208.811 44.999%2C208.155 45.405 C 207.437 45.848%2C207.000 45.401%2C207.000 44.226 C 207.000 43.185%2C206.681 42.014%2C206.291 41.624 C 205.901 41.234%2C205.710 39.134%2C205.867 36.957 C 206.024 34.781%2C205.744 33.000%2C205.244 33.000 C 203.857 33.000%2C205.048 22.809%2C206.619 21.238 C 207.794 20.064%2C208.002 20.204%2C208.014 22.179 C 208.050 28.294%2C209.652 30.205%2C212.421 27.436 C 213.334 26.523%2C214.508 26.201%2C215.242 26.661 C 216.830 27.656%2C221.000 28.259%2C221.000 27.494 C 221.000 27.178%2C220.047 25.630%2C218.882 24.055 C 215.617 19.639%2C217.949 17.653%2C223.453 20.161 M238.923 94.128 C 238.881 94.332%2C238.712 95.183%2C238.546 96.018 C 238.050 98.519%2C232.000 106.930%2C229.880 108.064 C 226.140 110.066%2C221.643 108.829%2C220.558 105.500 C 219.234 101.437%2C219.261 101.454%2C217.161 103.354 C 212.200 107.844%2C211.673 124.982%2C216.081 138.500 C 217.336 142.350%2C218.262 146.063%2C218.138 146.750 C 218.014 147.438%2C218.326 148.000%2C218.831 148.000 C 219.758 148.000%2C221.169 152.676%2C221.442 156.651 C 221.524 157.833%2C222.183 159.515%2C222.907 160.388 C 223.631 161.261%2C223.963 162.655%2C223.643 163.487 C 223.324 164.319%2C223.499 165.000%2C224.031 165.000 C 224.564 165.000%2C225.000 165.675%2C225.000 166.500 C 225.000 167.325%2C225.436 168.000%2C225.969 168.000 C 226.501 168.000%2C226.678 167.325%2C226.362 166.500 C 226.045 165.675%2C226.247 165.000%2C226.810 165.000 C 227.373 165.000%2C228.021 165.563%2C228.249 166.250 C 228.718 167.659%2C239.808 167.908%2C244.000 166.604 C 245.907 166.011%2C246.144 166.080%2C245.000 166.898 C 243.919 167.670%2C251.391 167.974%2C271.750 167.985 L 300.000 168.000 300.000 136.860 L 300.000 105.719 286.207 106.419 C 272.842 107.098%2C272.261 107.043%2C267.457 104.649 C 261.520 101.690%2C252.788 100.285%2C253.608 102.421 C 253.981 103.392%2C255.274 103.639%2C258.049 103.267 C 263.994 102.469%2C264.195 104.882%2C258.652 110.505 C 254.400 114.818%2C254.058 114.977%2C253.062 113.115 C 252.478 112.024%2C252.000 110.369%2C252.000 109.437 C 252.000 108.505%2C250.529 106.113%2C248.730 104.121 C 246.932 102.130%2C244.794 99.600%2C243.980 98.500 C 242.430 96.405%2C239.055 93.487%2C238.923 94.128 M132.500 111.098 C 125.900 111.546%2C115.550 112.386%2C109.500 112.964 C 103.450 113.543%2C92.580 114.083%2C85.344 114.164 L 72.189 114.312 75.844 117.812 C 84.092 125.708%2C92.791 129.453%2C117.792 135.873 C 133.487 139.903%2C137.756 142.195%2C138.142 146.802 C 138.221 147.736%2C138.406 149.945%2C138.554 151.711 C 138.757 154.137%2C138.356 155.070%2C136.910 155.528 C 135.313 156.035%2C135.098 156.763%2C135.607 159.942 C 135.981 162.284%2C135.789 164.012%2C135.108 164.433 C 134.498 164.810%2C134.000 165.766%2C134.000 166.559 C 134.000 167.772%2C137.633 168.000%2C156.937 168.000 L 179.875 168.000 179.821 164.093 C 179.789 161.807%2C180.910 157.770%2C182.521 154.363 C 185.500 148.067%2C185.812 144.720%2C184.534 132.750 C 183.758 125.481%2C183.826 125.000%2C185.631 125.000 C 188.490 125.000%2C191.282 128.740%2C190.563 131.607 C 190.232 132.923%2C190.351 134.000%2C190.826 134.000 C 192.681 134.000%2C197.045 127.029%2C196.921 124.264 C 196.874 123.217%2C196.637 123.008%2C196.338 123.750 C 195.635 125.491%2C194.000 125.316%2C194.000 123.500 C 194.000 122.675%2C193.438 121.978%2C192.750 121.952 C 192.063 121.925%2C189.086 121.737%2C186.134 121.534 C 182.060 121.253%2C178.812 121.865%2C172.634 124.077 C 168.161 125.679%2C163.713 126.992%2C162.750 126.995 C 161.788 126.998%2C161.000 127.403%2C161.000 127.896 C 161.000 128.789%2C145.527 132.006%2C141.250 132.002 C 138.526 132.000%2C138.404 130.357%2C140.750 125.284 C 142.719 121.027%2C143.342 120.221%2C149.278 114.258 L 153.500 110.016 149.000 110.150 C 146.525 110.224%2C139.100 110.651%2C132.500 111.098 M30.500 114.042 C 14.550 114.416%2C1.163 114.785%2C0.750 114.861 C 0.338 114.937%2C0.000 126.939%2C0.000 141.530 L 0.000 168.060 18.077 167.953 C 33.641 167.860%2C36.075 167.638%2C35.584 166.357 C 35.155 165.241%2C35.510 165.027%2C37.006 165.502 C 38.419 165.950%2C39.000 165.678%2C39.000 164.567 C 39.000 163.705%2C39.338 163.077%2C39.750 163.171 C 41.012 163.459%2C50.375 161.913%2C52.500 161.065 C 53.600 160.627%2C55.625 159.793%2C57.000 159.212 C 58.375 158.632%2C60.175 158.196%2C61.000 158.245 C 61.825 158.293%2C64.153 157.548%2C66.172 156.589 C 68.192 155.630%2C70.442 154.746%2C71.172 154.625 C 71.903 154.503%2C73.498 153.855%2C74.717 153.185 C 75.936 152.514%2C79.662 151.116%2C82.997 150.078 C 86.332 149.040%2C90.619 147.002%2C92.524 145.550 C 95.927 142.954%2C95.958 142.865%2C94.309 140.349 C 93.386 138.941%2C89.227 136.120%2C85.066 134.079 C 71.185 127.273%2C65.184 122.428%2C63.292 116.500 C 62.765 114.850%2C61.697 113.469%2C60.917 113.431 C 60.138 113.393%2C46.450 113.668%2C30.500 114.042 M272.073 149.635 C 270.933 151.084%2C270.000 152.849%2C270.000 153.557 C 270.000 155.369%2C262.857 161.272%2C256.964 164.329 C 252.987 166.392%2C252.000 166.602%2C252.000 165.385 C 252.000 164.320%2C251.401 164.055%2C250.000 164.500 C 248.853 164.864%2C248.000 164.680%2C248.000 164.067 C 248.000 162.712%2C239.501 162.662%2C236.995 164.003 C 235.715 164.687%2C234.912 164.666%2C234.461 163.936 C 233.495 162.373%2C234.239 161.942%2C241.273 159.992 C 246.840 158.448%2C248.047 158.400%2C250.921 159.609 C 254.544 161.132%2C254.948 160.991%2C260.000 156.437 C 269.204 148.140%2C270.623 147.057%2C272.323 147.029 C 274.021 147.002%2C274.004 147.180%2C272.073 149.635 \' stroke=\'none\' fill=\'%23C0CFD6\' fill-rule=\'evenodd\'/%3E%3C/svg%3E\",\"colorPalette\":[\"#596a7d\",\"#cdccca\",\"#e12e36\",\"#4a3427\",\"#a0a8bd\"],\"placeholderWidth\":1200,\"placeholderHeight\":675}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,30,1,'Individuele Therapie_Subpage_2','2019-02-05 18:09:39','2019-02-05 18:09:39','d70b4f7d-9882-41a6-bd6b-bd988d5b4248',NULL,NULL,NULL,NULL,NULL,NULL,'{\"optimizedImageUrls\":{\"1440\":\"http://careto.test/assets/img/uploads/hero/_1440x810_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg\",\"1200\":\"http://careto.test/assets/img/uploads/hero/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg\",\"900\":\"http://careto.test/assets/img/uploads/hero/_900x506_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg\",\"1800\":\"http://careto.test/assets/img/uploads/hero/_1800x1012_crop_center-center_45_line/IndividueleTherapie_Subpage_2.jpg\",\"576\":\"http://careto.test/assets/img/uploads/hero/_576x768_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg\"},\"optimizedWebPImageUrls\":{\"1440\":\"http://careto.test/assets/img/uploads/hero/_1440x810_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"1200\":\"http://careto.test/assets/img/uploads/hero/_1200x675_crop_center-center_82_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"900\":\"http://careto.test/assets/img/uploads/hero/_900x506_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"1800\":\"http://careto.test/assets/img/uploads/hero/_1800x1012_crop_center-center_45_line/IndividueleTherapie_Subpage_2.jpg.webp\",\"576\":\"http://careto.test/assets/img/uploads/hero/_576x768_crop_center-center_60_line/IndividueleTherapie_Subpage_2.jpg.webp\"},\"variantSourceWidths\":[\"1440\",\"1200\",\"1200\",\"900\",\"900\",\"576\"],\"variantHeights\":{\"1440\":810,\"1200\":675,\"900\":506,\"1800\":1012,\"576\":768},\"focalPoint\":{\"x\":0.5,\"y\":0.5},\"originalImageWidth\":\"1920\",\"originalImageHeight\":\"1080\",\"placeholder\":\"/9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2OTApLCBxdWFsaXR5ID0gNTAK/9sAQwAQCwwODAoQDg0OEhEQExgoGhgWFhgxIyUdKDozPTw5Mzg3QEhcTkBEV0U3OFBtUVdfYmdoZz5NcXlwZHhcZWdj/9sAQwEREhIYFRgvGhovY0I4QmNjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2Nj/8AAEQgACQAQAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8Ap2Gr6aIwGt44j6qu4j3qlq80F9KRaQs5J+VlTGRWBF/rV+tWk/1o/wB2s1BXuaObsf/Z\",\"placeholderSvg\":\"%3Csvg id=\'svg\' version=\'1.1\' width=\'300\' height=\'168\' style=\'background-color: %23FEFEFE\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0.000 17.035 C 0.000 33.426%2C0.071 34.032%2C1.889 33.060 C 4.703 31.553%2C9.038 31.490%2C13.230 32.893 C 15.282 33.580%2C17.454 33.837%2C18.057 33.465 C 18.659 33.093%2C21.481 32.665%2C24.326 32.515 C 30.744 32.177%2C31.421 32.004%2C36.645 29.363 C 40.256 27.538%2C40.957 27.445%2C41.448 28.726 C 41.835 29.733%2C42.430 29.918%2C43.262 29.289 C 45.219 27.810%2C57.099 25.925%2C61.500 26.396 C 65.759 26.852%2C68.805 25.477%2C72.702 21.338 C 74.822 19.088%2C80.000 18.059%2C80.000 19.889 C 80.000 20.377%2C81.620 21.081%2C83.601 21.453 C 85.581 21.824%2C88.703 22.845%2C90.539 23.720 C 93.619 25.189%2C94.077 25.180%2C96.478 23.606 C 99.593 21.565%2C115.838 19.782%2C117.750 21.271 C 118.649 21.971%2C119.022 21.719%2C119.079 20.372 C 119.123 19.319%2C119.378 19.047%2C119.662 19.750 C 119.940 20.438%2C120.831 21.000%2C121.642 21.000 C 122.454 21.000%2C122.870 20.598%2C122.566 20.107 C 122.262 19.615%2C123.136 18.932%2C124.507 18.588 C 125.878 18.243%2C127.000 17.403%2C127.000 16.721 C 127.000 13.721%2C132.169 9.796%2C135.378 10.358 C 144.490 11.955%2C145.544 12.049%2C143.315 11.071 C 142.114 10.544%2C140.635 9.187%2C140.030 8.056 C 138.570 5.328%2C140.689 5.313%2C147.761 8.001 C 150.654 9.100%2C154.115 10.000%2C155.451 10.000 C 156.787 10.000%2C160.945 11.076%2C164.690 12.391 C 168.436 13.706%2C172.625 15.041%2C174.000 15.359 C 175.375 15.677%2C179.425 18.883%2C183.000 22.484 C 189.978 29.512%2C195.125 33.267%2C197.205 32.847 C 201.613 31.957%2C204.000 33.973%2C204.000 38.586 C 204.000 42.680%2C203.800 43.071%2C202.000 42.500 C 200.853 42.136%2C200.000 42.320%2C200.000 42.933 C 200.000 43.520%2C200.477 44.000%2C201.059 44.000 C 201.641 44.000%2C201.840 44.450%2C201.500 45.000 C 200.075 47.306%2C202.336 48.206%2C204.003 45.997 C 205.697 43.750%2C205.758 43.744%2C208.796 45.538 C 210.488 46.538%2C212.114 48.318%2C212.409 49.494 C 212.704 50.669%2C213.861 52.686%2C214.979 53.976 C 217.409 56.778%2C217.112 57.317%2C213.618 56.440 C 212.028 56.041%2C211.000 55.088%2C211.000 54.014 C 211.000 53.041%2C210.325 51.685%2C209.500 51.000 C 208.464 50.140%2C208.000 50.102%2C208.000 50.878 C 208.000 51.495%2C207.373 52.000%2C206.607 52.000 C 205.841 52.000%2C204.931 52.736%2C204.586 53.636 C 204.005 55.151%2C203.824 55.150%2C202.148 53.634 C 201.152 52.733%2C200.089 52.245%2C199.784 52.549 C 199.480 52.853%2C198.758 51.745%2C198.180 50.086 C 197.443 47.973%2C196.286 46.895%2C194.314 46.483 C 192.766 46.160%2C188.968 44.569%2C185.873 42.948 C 182.696 41.284%2C178.690 40.000%2C176.672 40.000 C 174.707 40.000%2C170.837 39.515%2C168.073 38.922 C 161.398 37.491%2C158.108 38.260%2C163.882 39.902 C 166.293 40.588%2C169.105 41.673%2C170.132 42.315 C 172.412 43.738%2C172.586 46.000%2C170.417 46.000 C 169.546 46.000%2C169.017 46.563%2C169.242 47.250 C 169.802 48.966%2C176.248 51.051%2C177.450 49.906 C 178.785 48.633%2C181.745 48.778%2C182.597 50.158 C 183.087 50.951%2C182.634 51.138%2C181.157 50.751 C 179.972 50.441%2C178.750 50.596%2C178.442 51.094 C 178.134 51.592%2C178.632 52.000%2C179.548 52.000 C 180.618 52.000%2C181.008 52.537%2C180.638 53.500 C 179.902 55.419%2C181.422 55.435%2C183.329 53.528 C 184.563 52.294%2C184.984 52.276%2C185.926 53.411 C 186.783 54.443%2C186.682 54.908%2C185.503 55.361 C 184.225 55.851%2C184.170 56.299%2C185.186 57.926 C 186.170 59.501%2C186.707 59.658%2C187.853 58.707 C 189.047 57.716%2C189.173 57.879%2C188.604 59.674 C 188.223 60.872%2C188.388 62.122%2C188.976 62.485 C 189.557 62.844%2C189.797 63.519%2C189.509 63.985 C 189.221 64.451%2C189.479 66.107%2C190.082 67.666 C 191.678 71.794%2C192.148 73.964%2C192.537 79.000 C 192.728 81.475%2C193.154 85.525%2C193.484 88.000 C 193.857 90.808%2C193.743 91.998%2C193.180 91.166 C 192.455 90.094%2C192.153 90.158%2C191.642 91.490 C 190.607 94.187%2C187.629 90.616%2C188.388 87.590 C 188.713 86.297%2C188.340 83.498%2C187.560 81.370 C 186.779 79.241%2C186.109 78.089%2C186.070 78.809 C 185.968 80.707%2C184.029 79.206%2C182.963 76.403 C 181.384 72.251%2C180.503 73.759%2C180.423 80.749 C 180.344 87.645%2C179.142 96.000%2C178.229 96.000 C 177.949 96.000%2C177.165 95.241%2C176.487 94.313 C 175.359 92.770%2C175.194 92.814%2C174.555 94.827 C 174.171 96.037%2C170.401 99.609%2C166.178 102.764 C 158.667 108.375%2C158.358 108.500%2C151.973 108.500 C 145.918 108.500%2C145.118 108.231%2C140.895 104.770 C 138.391 102.718%2C135.371 100.891%2C134.183 100.710 C 132.995 100.529%2C130.986 99.479%2C129.718 98.377 C 128.450 97.274%2C126.645 96.078%2C125.707 95.718 C 124.768 95.357%2C124.000 94.572%2C124.000 93.972 C 124.000 91.883%2C121.999 94.134%2C121.924 96.309 C 121.866 97.990%2C121.534 97.686%2C120.500 95.000 C 119.282 91.838%2C119.139 91.741%2C119.013 94.000 L 118.873 96.500 117.885 94.024 C 117.078 92.002%2C116.726 91.819%2C115.964 93.024 C 115.264 94.132%2C115.023 93.751%2C115.000 91.500 C 114.976 89.193%2C114.746 88.846%2C114.000 90.000 C 113.251 91.159%2C113.010 90.818%2C112.938 88.500 C 112.850 85.615%2C112.796 85.653%2C111.528 89.500 L 110.210 93.500 110.105 89.309 C 110.004 85.292%2C108.000 81.902%2C108.000 85.750 C 108.000 86.777%2C107.339 88.491%2C106.532 89.559 C 105.086 91.470%2C105.063 91.469%2C105.032 89.463 C 104.992 86.938%2C101.435 86.417%2C100.642 88.820 C 100.337 89.744%2C98.954 92.405%2C97.569 94.733 C 96.150 97.116%2C95.321 99.673%2C95.671 100.584 C 96.127 101.773%2C95.801 102.108%2C94.440 101.846 C 92.383 101.450%2C91.304 98.522%2C90.993 92.500 C 90.793 88.620%2C90.755 88.580%2C89.732 91.161 L 88.676 93.822 86.918 91.661 C 85.210 89.563%2C85.073 89.550%2C82.193 91.239 C 79.558 92.785%2C79.087 92.810%2C77.972 91.467 C 77.282 90.635%2C75.964 90.194%2C75.042 90.487 C 73.298 91.040%2C68.859 85.361%2C67.453 80.776 C 66.475 77.586%2C64.957 75.909%2C63.733 76.665 C 63.027 77.102%2C62.911 75.169%2C63.374 70.654 C 64.090 63.668%2C63.490 62.696%2C60.500 66.000 C 58.210 68.531%2C56.783 68.523%2C54.471 65.968 C 53.460 64.851%2C51.928 64.027%2C51.066 64.137 C 50.205 64.247%2C48.280 63.747%2C46.789 63.026 C 44.412 61.876%2C42.074 62.155%2C27.789 65.298 C 18.830 67.269%2C9.700 69.173%2C7.500 69.528 C -0.831 70.875%2C0.000 65.329%2C0.000 119.567 L 0.000 168.000 150.000 168.000 L 300.000 168.000 299.994 155.750 L 299.989 143.500 295.744 143.365 C 292.521 143.263%2C291.981 143.443%2C293.500 144.113 C 294.921 144.739%2C294.523 144.820%2C292.125 144.391 C 289.912 143.994%2C288.971 144.144%2C289.391 144.824 C 289.744 145.395%2C289.575 146.144%2C289.016 146.490 C 288.457 146.835%2C288.000 146.586%2C288.000 145.937 C 288.000 145.056%2C287.618 145.072%2C286.500 146.000 C 285.675 146.685%2C284.944 146.965%2C284.875 146.622 C 284.806 146.280%2C284.694 145.565%2C284.625 145.032 C 284.556 144.500%2C283.701 143.131%2C282.723 141.990 C 280.729 139.661%2C278.802 140.154%2C279.625 142.782 C 280.124 144.375%2C280.058 144.372%2C278.721 142.750 C 277.928 141.788%2C276.782 141.000%2C276.175 141.000 C 274.768 141.000%2C272.847 144.513%2C273.756 145.423 C 274.537 146.204%2C272.132 147.962%2C270.250 147.985 C 269.563 147.993%2C269.000 147.293%2C269.000 146.429 C 269.000 144.566%2C271.493 141.827%2C272.381 142.714 C 272.721 143.055%2C273.000 142.103%2C273.000 140.599 C 273.000 138.320%2C273.333 137.971%2C275.000 138.500 C 276.377 138.937%2C277.000 138.680%2C277.000 137.673 C 277.000 136.825%2C277.945 136.210%2C279.250 136.208 C 280.488 136.205%2C283.075 135.783%2C285.000 135.269 C 289.274 134.127%2C296.893 134.802%2C294.861 136.143 C 293.485 137.051%2C296.940 141.000%2C299.111 141.000 C 299.621 141.000%2C300.000 110.978%2C300.000 70.500 L 300.000 0.000 150.000 0.000 L 0.000 0.000 0.000 17.035 M140.201 36.093 C 136.990 36.749%2C131.748 40.000%2C133.900 40.000 C 134.917 40.000%2C134.971 40.330%2C134.122 41.353 C 133.195 42.470%2C133.915 42.624%2C138.249 42.236 C 143.254 41.787%2C147.513 40.000%2C143.578 40.000 C 142.038 40.000%2C141.956 39.757%2C143.053 38.436 C 143.781 37.559%2C145.263 37.078%2C146.426 37.341 C 147.567 37.599%2C149.400 37.463%2C150.500 37.039 C 153.113 36.032%2C144.409 35.232%2C140.201 36.093 \' stroke=\'none\' fill=\'%23C0CFD6\' fill-rule=\'evenodd\'/%3E%3C/svg%3E\",\"colorPalette\":[\"#37261b\",\"#cbac8c\",\"#926748\",\"#a78e77\",\"#848484\"],\"placeholderWidth\":1440,\"placeholderHeight\":810}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,31,1,'Familiale bemiddeling info','2019-02-05 18:10:22','2019-02-05 19:28:24','9828c5a6-de84-4b44-9e48-0b2e4d8a0653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,34,1,NULL,'2019-02-05 19:26:02','2019-02-05 19:34:20','6cea8f47-b2fa-4f84-9cee-1078d31454c6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,35,1,'Bemiddeling','2019-02-05 19:27:05','2019-02-05 19:27:05','8ff3fa9c-3149-4520-abec-8295a9005719',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,36,1,'Relatie','2019-02-05 19:27:14','2019-02-05 19:27:14','93e8fa48-2b9e-4337-a56d-d302f17204f8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,37,1,'Bedrijf','2019-02-05 19:27:17','2019-02-05 19:27:17','350d6b23-12b3-406a-9787-39562ea98be5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,38,1,'Opvoeding','2019-02-05 19:27:30','2019-02-05 19:27:30','1efc5264-7cd7-40c9-8548-dde9e7f98fef',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,39,1,'Therapie','2019-02-05 19:27:34','2019-02-05 19:27:34','78456a06-2322-43e7-ba32-f67addf8e83d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,40,1,'Careto-logo','2019-02-05 19:29:59','2019-02-05 19:29:59','1d851154-110b-4daf-8af2-18f0edbd4af4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"optimizedImageUrls\":[],\"optimizedWebPImageUrls\":[],\"variantSourceWidths\":[],\"variantHeights\":[],\"focalPoint\":null,\"originalImageWidth\":null,\"originalImageHeight\":null,\"placeholder\":\"\",\"placeholderSvg\":\"\",\"colorPalette\":[],\"placeholderWidth\":null,\"placeholderHeight\":null}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,41,1,'Contact','2019-02-05 20:09:34','2019-02-05 20:12:20','5f277225-bcbf-4a63-bd05-eb8e852efba3',NULL,NULL,NULL,'<p>Contacteer CareTo ...</p>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Contacteer CareTo',NULL,'Contact',NULL,NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,'craft\\elements\\User',1,0,'2019-02-05 15:44:19','2019-02-05 15:44:19',NULL,'b3e340e2-b7a9-4892-8593-8b3df6d03dbf'),(2,7,'craft\\elements\\Entry',1,0,'2019-02-05 16:45:06','2019-02-05 17:58:50',NULL,'dbe8b375-9d2c-4b36-a136-9e0e218da777'),(3,13,'craft\\elements\\GlobalSet',1,0,'2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'2e6083c6-8f1d-400f-ae9f-4408b92cc70a'),(4,14,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:06:26','2019-02-05 17:58:50',NULL,'ad47adb9-64a7-49dd-8bcd-d7716427a9b1'),(5,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:30','2019-02-05 17:07:30',NULL,'5becd138-2823-4976-9c65-fb90a75b8cda'),(6,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:31','2019-02-05 17:07:31',NULL,'435d979c-e7e2-4464-a66a-20d513157137'),(7,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:32','2019-02-05 17:07:32',NULL,'29a1036e-14c8-46c1-a5c4-dfb8e02faf8e'),(8,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:32','2019-02-05 17:07:32',NULL,'03898795-fce6-45d4-82c8-ff1ad8636e5d'),(9,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:33','2019-02-05 17:07:33',NULL,'ae4020cc-f557-4315-a5a6-566375fbaf96'),(10,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:34','2019-02-05 17:07:34',NULL,'236e4887-8dec-45de-b71d-a778e8ec2d53'),(11,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:35','2019-02-05 17:07:35',NULL,'32786f1e-98cb-4b78-b16b-fb58ef4f3864'),(12,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:35','2019-02-05 17:07:35',NULL,'92c7578e-fbaf-47cb-bc03-d00869b7a00d'),(13,NULL,'craft\\elements\\Asset',1,0,'2019-02-05 17:07:37','2019-02-05 17:07:37',NULL,'957a100f-3637-4784-8881-b1737c569043'),(14,14,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:26:06','2019-02-05 17:58:50',NULL,'8fce06d7-2a13-4fdb-b32a-e739a00a5a19'),(15,14,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:26:49','2019-02-05 17:58:50',NULL,'2ba76e7b-e76e-4de5-83f2-282b122998ff'),(16,16,'craft\\elements\\GlobalSet',1,0,'2019-02-05 17:32:51','2019-02-05 17:34:00',NULL,'bcef697c-9a25-4819-9953-e06f94bce25c'),(17,15,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:34:00','2019-02-05 17:34:00',NULL,'637c0de1-3596-4157-bb36-1d4ed5dd7b24'),(18,15,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:34:00','2019-02-05 17:34:00',NULL,'27815181-753d-4549-b3e5-b93d1a0a60ea'),(19,17,'craft\\elements\\Entry',1,0,'2019-02-05 17:44:56','2019-02-05 18:12:38',NULL,'be0e8b20-0e4d-485f-9596-6952a3ed559a'),(20,17,'craft\\elements\\Entry',1,0,'2019-02-05 17:45:08','2019-02-05 17:55:51',NULL,'8c74d953-dc67-4701-a1a7-82ec1406de25'),(21,17,'craft\\elements\\Entry',1,0,'2019-02-05 17:45:13','2019-02-05 17:55:51',NULL,'1c034243-536e-4303-b348-c35283073a5b'),(22,17,'craft\\elements\\Entry',1,0,'2019-02-05 17:45:30','2019-02-05 17:55:51',NULL,'bb745ed0-f97f-4150-8fe1-ec939bfb5832'),(23,17,'craft\\elements\\Entry',1,0,'2019-02-05 17:45:42','2019-02-05 17:55:51',NULL,'f9871a49-3a6d-4254-a85f-fd2835d06c56'),(24,8,'craft\\elements\\Asset',1,0,'2019-02-05 17:53:24','2019-02-05 17:53:24',NULL,'7798230d-d1c9-4300-94eb-dda34f8674f2'),(25,8,'craft\\elements\\Asset',1,0,'2019-02-05 17:53:25','2019-02-05 17:53:25',NULL,'d2ce17ae-52fb-4b3c-8866-662bf38a5ad6'),(26,8,'craft\\elements\\Asset',1,0,'2019-02-05 17:53:25','2019-02-05 17:53:25',NULL,'c8b44238-6af5-4065-8c28-c1d8c84c2316'),(27,14,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:54:07','2019-02-05 18:12:38',NULL,'c84850b0-adf7-47c3-8d16-1c81c05932d3'),(28,14,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:54:07','2019-02-05 18:12:38',NULL,'f647dea4-0110-48f2-81ac-dc6b6cb54e6f'),(29,14,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 17:54:07','2019-02-05 18:12:38',NULL,'75ae0a9e-9b41-4c43-b72a-fba20790043f'),(30,9,'craft\\elements\\Asset',1,0,'2019-02-05 18:09:39','2019-02-05 18:09:39',NULL,'b92abee0-77d7-4f05-a1bb-ed5ff5f2115d'),(31,18,'craft\\elements\\Entry',1,0,'2019-02-05 18:10:22','2019-02-05 19:28:24',NULL,'1231745b-6920-44ca-adfc-70d0e98b9ea0'),(32,1,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 18:10:23','2019-02-05 19:28:24',NULL,'3b939865-82c3-4ffc-8b49-a711f9f44782'),(33,2,'craft\\elements\\MatrixBlock',1,0,'2019-02-05 18:10:23','2019-02-05 19:28:24',NULL,'23836bee-cefe-4945-8089-1e43248f588d'),(34,19,'craft\\elements\\GlobalSet',1,0,'2019-02-05 19:26:02','2019-02-05 19:34:20',NULL,'b24680f2-966e-4f34-a233-773cc8261e27'),(35,NULL,'craft\\elements\\Category',1,0,'2019-02-05 19:27:05','2019-02-05 19:27:05',NULL,'5f02397e-07c2-4d37-a8fb-5204b1786599'),(36,NULL,'craft\\elements\\Category',1,0,'2019-02-05 19:27:14','2019-02-05 19:27:14',NULL,'932b3f69-c746-4ff7-89c0-221f04ad917c'),(37,NULL,'craft\\elements\\Category',1,0,'2019-02-05 19:27:17','2019-02-05 19:27:17',NULL,'3ad8dd5b-02fe-4e6a-b89d-4942c4bfee31'),(38,NULL,'craft\\elements\\Category',1,0,'2019-02-05 19:27:30','2019-02-05 19:27:30',NULL,'ee61f41c-b017-4d9d-bcf2-81e760597f9a'),(39,NULL,'craft\\elements\\Category',1,0,'2019-02-05 19:27:34','2019-02-05 19:27:34',NULL,'84196504-e554-4445-a024-c4fefa1c80e8'),(40,8,'craft\\elements\\Asset',1,0,'2019-02-05 19:29:59','2019-02-05 19:29:59',NULL,'9462f133-d58d-4ebf-8fb0-0d5622d996da'),(41,20,'craft\\elements\\Entry',1,0,'2019-02-05 20:09:34','2019-02-05 20:12:20',NULL,'fdc00cb2-30b5-4f3c-a084-de6e7b94d0a5');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2019-02-05 15:44:19','2019-02-05 15:44:19','b700021f-56e8-402e-8911-6802663cc9b6'),(2,2,1,'homepage','__home__',1,'2019-02-05 16:45:06','2019-02-05 17:58:50','9c45ce0a-12a6-490f-82c2-790028327285'),(3,3,1,NULL,NULL,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','ed95fa70-f362-47d6-9c60-a097884d1b86'),(4,4,1,NULL,NULL,1,'2019-02-05 17:06:26','2019-02-05 17:58:50','097a198a-0252-455f-88c9-b6e63d466ce7'),(5,5,1,NULL,NULL,1,'2019-02-05 17:07:30','2019-02-05 17:07:30','d4c32ce0-e8e1-4912-8260-5061ba1e7418'),(6,6,1,NULL,NULL,1,'2019-02-05 17:07:31','2019-02-05 17:07:31','0a43a45e-0a0b-4cf9-97e7-a33661f6d8d5'),(7,7,1,NULL,NULL,1,'2019-02-05 17:07:32','2019-02-05 17:07:32','869cdb5c-5581-415c-97ee-0ec0c865e95c'),(8,8,1,NULL,NULL,1,'2019-02-05 17:07:32','2019-02-05 17:07:32','8e0cc1fa-4754-41a6-ac82-4643008aed0d'),(9,9,1,NULL,NULL,1,'2019-02-05 17:07:33','2019-02-05 17:07:33','6aa99c4c-cfc0-4982-b6b9-ca6ddb04b7a3'),(10,10,1,NULL,NULL,1,'2019-02-05 17:07:34','2019-02-05 17:07:34','7fc998d0-93a6-4fcd-aa70-5774ebc6dd8f'),(11,11,1,NULL,NULL,1,'2019-02-05 17:07:35','2019-02-05 17:07:35','e44e0d66-f778-4d41-827f-8f341563678f'),(12,12,1,NULL,NULL,1,'2019-02-05 17:07:35','2019-02-05 17:07:35','c0973b16-b988-4384-93a8-483c54e2a280'),(13,13,1,NULL,NULL,1,'2019-02-05 17:07:37','2019-02-05 17:07:37','24560b25-8582-4ada-bb3d-2c7cd0d53e9a'),(14,14,1,NULL,NULL,1,'2019-02-05 17:26:06','2019-02-05 17:58:50','20787523-41b4-45fc-8c5a-2679d8102c1b'),(15,15,1,NULL,NULL,1,'2019-02-05 17:26:49','2019-02-05 17:58:50','9c708cd6-66ab-4049-a74c-370321d52623'),(16,16,1,NULL,NULL,1,'2019-02-05 17:32:51','2019-02-05 17:34:00','46e2d4bd-0016-4b44-92dd-0988e5cdcce9'),(17,17,1,NULL,NULL,1,'2019-02-05 17:34:00','2019-02-05 17:34:00','043c5c2d-16f8-4766-90e5-a6214052f5ed'),(18,18,1,NULL,NULL,1,'2019-02-05 17:34:00','2019-02-05 17:34:00','6f950a75-2119-4889-8db3-5dc8d9fdef8c'),(19,19,1,'familiale-bemiddeling','familiale-bemiddeling',1,'2019-02-05 17:44:56','2019-02-05 18:12:38','6ccbae4f-10d5-488f-adf7-dfaf5cf9a723'),(20,20,1,'individuele-therapie','individuele-therapie',1,'2019-02-05 17:45:08','2019-02-05 17:55:51','0a332a5c-0dd1-473b-9da6-84464c457144'),(21,21,1,'relatietherapie','relatietherapie',1,'2019-02-05 17:45:13','2019-02-05 17:55:51','55dd72e0-b60a-451f-86b5-b337a66dfdc7'),(22,22,1,'love2us','love2us',1,'2019-02-05 17:45:30','2019-02-05 17:55:51','bd90ef03-b5fa-4f7b-a896-f88f2b8563ea'),(23,23,1,'bedrijfstherapie','bedrijfstherapie',1,'2019-02-05 17:45:42','2019-02-05 17:55:51','fe9c1434-3354-456d-b588-0af171fb6771'),(24,24,1,NULL,NULL,1,'2019-02-05 17:53:24','2019-02-05 17:53:24','7bd00051-43c7-4bc9-abef-2659dc0885ec'),(25,25,1,NULL,NULL,1,'2019-02-05 17:53:25','2019-02-05 17:53:25','1ab19d12-c39c-4b7f-bbae-7ef9af8e3243'),(26,26,1,NULL,NULL,1,'2019-02-05 17:53:25','2019-02-05 17:53:25','b0506b69-8217-485a-b259-e1ab8fa27b5b'),(27,27,1,NULL,NULL,1,'2019-02-05 17:54:07','2019-02-05 18:12:38','7dc61b11-8269-4f28-8588-7e44c5055cc0'),(28,28,1,NULL,NULL,1,'2019-02-05 17:54:07','2019-02-05 18:12:38','149bf7a5-d7b1-40f7-ae09-29113d0e4e40'),(29,29,1,NULL,NULL,1,'2019-02-05 17:54:07','2019-02-05 18:12:38','6884afcd-43a0-4bc4-ab42-7db258388564'),(30,30,1,NULL,NULL,1,'2019-02-05 18:09:39','2019-02-05 18:09:39','a7738bff-fac4-4790-801a-8c41633c72d0'),(31,31,1,'familiale-bemiddeling','familiale-bemiddeling/familiale-bemiddeling',1,'2019-02-05 18:10:22','2019-02-05 19:28:24','f8a942bc-b095-4ef1-91f6-2a4f307bde28'),(32,32,1,NULL,NULL,1,'2019-02-05 18:10:23','2019-02-05 19:28:24','0688552f-9e38-4cac-ac75-765e2d2d8c65'),(33,33,1,NULL,NULL,1,'2019-02-05 18:10:23','2019-02-05 19:28:24','32f103a4-fef5-4cde-86e0-3be20ba2cf44'),(34,34,1,NULL,NULL,1,'2019-02-05 19:26:02','2019-02-05 19:34:20','f070ea74-8c55-4cad-b62d-16617c660b03'),(35,35,1,'bemiddeling','blog/bemiddeling',1,'2019-02-05 19:27:05','2019-02-05 19:27:06','1c395f22-1eed-4cc3-9c4d-6e361f21ec5f'),(36,36,1,'relatie','blog/relatie',1,'2019-02-05 19:27:14','2019-02-05 19:27:14','cc2f2575-b6b3-42b4-9fb9-71498808185e'),(37,37,1,'bedrijf','blog/bedrijf',1,'2019-02-05 19:27:17','2019-02-05 19:27:18','130e364e-d784-44db-9b4a-faebedf39317'),(38,38,1,'opvoeding','blog/opvoeding',1,'2019-02-05 19:27:30','2019-02-05 19:27:31','9ef5e6d3-2ebc-4177-814b-dd774cfb64c5'),(39,39,1,'therapie','blog/therapie',1,'2019-02-05 19:27:34','2019-02-05 19:27:34','06d69164-82be-4235-ada5-a82ef327704d'),(40,40,1,NULL,NULL,1,'2019-02-05 19:29:59','2019-02-05 19:29:59','2cf77f82-52a2-4b8b-95af-d59a8f015edd'),(41,41,1,'contact','contact',1,'2019-02-05 20:09:34','2019-02-05 20:12:20','b3241572-d4af-418d-968e-c0437dcd98cd');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,2,NULL,2,NULL,'2019-02-05 16:45:00',NULL,NULL,'2019-02-05 16:45:06','2019-02-05 17:58:50','c83b551b-35ef-4102-9ed2-a3b8c069d8f1'),(19,3,NULL,3,1,'2019-02-05 17:44:00',NULL,NULL,'2019-02-05 17:44:56','2019-02-05 18:12:38','5ebc6406-6eb1-490c-8663-260d2a4c1b7f'),(20,3,NULL,3,1,'2019-02-05 17:45:00',NULL,NULL,'2019-02-05 17:45:08','2019-02-05 17:55:51','fc6a2103-cd9d-4b3e-854a-b7ebaa4a2d6b'),(21,3,NULL,3,1,'2019-02-05 17:45:00',NULL,NULL,'2019-02-05 17:45:13','2019-02-05 17:55:51','95571683-d4bb-451a-af10-10e1c95b33ac'),(22,3,NULL,3,1,'2019-02-05 17:45:00',NULL,NULL,'2019-02-05 17:45:30','2019-02-05 17:55:51','ee99742a-4703-480f-8020-0844264b0d16'),(23,3,NULL,3,1,'2019-02-05 17:45:00',NULL,NULL,'2019-02-05 17:45:42','2019-02-05 17:55:51','53b60478-91b2-4a27-a733-d41b55f4b3ad'),(31,3,NULL,4,1,'2019-02-05 18:10:00',NULL,NULL,'2019-02-05 18:10:22','2019-02-05 19:28:24','3aa75ae8-f15c-4839-9a24-c00b925138a2'),(41,4,NULL,5,NULL,'2019-02-05 20:09:00',NULL,NULL,'2019-02-05 20:09:34','2019-02-05 20:12:20','bb7b50a1-8bca-48b9-aa00-dba130a1ff12');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrydrafts`
--

LOCK TABLES `entrydrafts` WRITE;
/*!40000 ALTER TABLE `entrydrafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `entrydrafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,6,'Blog','blog',1,'Title',NULL,1,'2019-02-05 16:45:06','2019-02-05 16:45:11',NULL,'5a7034e8-3859-440e-a10c-81bef694075a'),(2,2,7,'Homepage','home',0,'','{section.name|raw}',1,'2019-02-05 16:45:06','2019-02-05 17:02:25',NULL,'f4bef959-cbd7-4bb7-a9ae-c4c63f73446f'),(3,3,17,'Visuele Pagina\'s ','visualPages',1,'Title','',1,'2019-02-05 17:37:57','2019-02-05 17:38:32',NULL,'32f6ba84-8af3-4465-8a43-cf96770ad7d2'),(4,3,18,'Textuele Pagina\'s ','textualPages',1,'Title','',2,'2019-02-05 17:39:21','2019-02-05 17:39:21',NULL,'a6c4307b-1614-425c-8164-e2c892f1afa5'),(5,4,20,'Contact','contact',0,NULL,'{section.name|raw}',1,'2019-02-05 20:09:34','2019-02-05 20:09:34',NULL,'0ba792ca-b17b-4790-905a-574666808176');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entryversions`
--

LOCK TABLES `entryversions` WRITE;
/*!40000 ALTER TABLE `entryversions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entryversions` VALUES (1,2,2,1,1,1,'Revision from Feb 5, 2019, 9:02:25 AM','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":\"1\",\"newParentId\":null,\"fields\":{\"53\":[]}}','2019-02-05 17:06:26','2019-02-05 17:06:26','3058fe91-f7a2-4cf3-816e-d577b11f9f48'),(2,2,2,1,1,2,'','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"53\":{\"4\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Soms heeft een zoektocht, een gids nodig\",\"description\":null,\"video\":[],\"position\":\"\"}}}}}','2019-02-05 17:06:26','2019-02-05 17:06:26','cb7e914f-2589-4ae0-a582-2b2db19a75b7'),(3,2,2,1,1,3,'','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"53\":{\"4\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Soms heeft een zoektocht, een gids nodig\",\"description\":\"<p>Ben je de weg kwijt, voel je je eenzaam en onbegrepen, twijfel je aan jezelf, voel je je uitgeblust, is de magie uit jullie relatie verdwenen, ontbreekt het je aan levenslust , stel je vragen bij je toekomst,… Weet je, iedereen verdient gelukkig te zijn en dit ook te voelen. Bij careto ondersteunen we koppels, kinderen, ouders en individuen in hun zoektocht naar hun eigen geluk.</p>\\n\",\"video\":[\"5\"],\"position\":\"left\"}}}}}','2019-02-05 17:07:52','2019-02-05 17:07:52','b102c0ab-0c62-44e8-80cb-08436b0b2029'),(4,2,2,1,1,4,'','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"53\":{\"4\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Soms heeft een zoektocht, een gids nodig\",\"description\":\"<p>Ben je de weg kwijt, voel je je eenzaam en onbegrepen, twijfel je aan jezelf, voel je je uitgeblust, is de magie uit jullie relatie verdwenen, ontbreekt het je aan levenslust , stel je vragen bij je toekomst,… Weet je, iedereen verdient gelukkig te zijn en dit ook te voelen. Bij careto ondersteunen we koppels, kinderen, ouders en individuen in hun zoektocht naar hun eigen geluk.</p><p>Scheiden brengt veel zorgen, onzekerheden en verdriet met zich mee. Dikwijls ontstaat er ook een strijd, die niet alleen emotioneel maar ook financieel uitputtend kan zijn. Bemiddeling houdt jullie uit de strijd met elkaar... De bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex-partner en ouder.</p>\",\"video\":[\"5\"],\"position\":\"left\"}},\"14\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Zing je eigen lied,  dans je eigen dans\",\"description\":\"<p>Wanneer een moeilijke fase je leven binnensluipt, hebben jouw emoties zorg en aandacht nodig. Careto is een ruimte waar je even tot rust kan komen, vrij en on over je emoties kan spreken. Een plaats waar alles mag zijn en niets ‘moet’. Een plek waar je gedachten, angsten, boosheid, verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt.</p>\",\"video\":[\"6\"],\"position\":\"right\"}}}}}','2019-02-05 17:26:06','2019-02-05 17:26:06','d1396bed-5603-483b-a24f-36f99b232dbf'),(5,2,2,1,1,5,'','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"53\":{\"4\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Soms heeft een zoektocht, een gids nodig\",\"description\":\"<p>Ben je de weg kwijt, voel je je eenzaam en onbegrepen, twijfel je aan jezelf, voel je je uitgeblust, is de magie uit jullie relatie verdwenen, ontbreekt het je aan levenslust , stel je vragen bij je toekomst,… Weet je, iedereen verdient gelukkig te zijn en dit ook te voelen. Bij careto ondersteunen we koppels, kinderen, ouders en individuen in hun zoektocht naar hun eigen geluk.</p>\\n<p>Scheiden brengt veel zorgen, onzekerheden en verdriet met zich mee. Dikwijls ontstaat er ook een strijd, die niet alleen emotioneel maar ook financieel uitputtend kan zijn. Bemiddeling houdt jullie uit de strijd met elkaar... De bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex-partner en ouder.</p>\",\"video\":[\"5\"],\"position\":\"left\"}},\"14\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Zing je eigen lied,  dans je eigen dans\",\"description\":\"<p>Wanneer een moeilijke fase je leven binnensluipt, hebben jouw emoties zorg en aandacht nodig. Careto is een ruimte waar je even tot rust kan komen, vrij en on over je emoties kan spreken. Een plaats waar alles mag zijn en niets ‘moet’. Een plek waar je gedachten, angsten, boosheid, verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt.</p>\",\"video\":[\"6\"],\"position\":\"right\"}},\"15\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Verandering begint bij jezelf, eenzaam in de relatie?\",\"description\":\"<p>Geen uitweg meer in de sleur van het dagdagelijks leven? Hoe moet het verder met jullie relatie na ontrouw van je partner? Het gevoel als broer en zus te leven? Jullie zijn niet de enige met dit probleem.</p><p>Dagelijks wordt je geconfronteerd met ruzies die jullie uitputten en waarvoor geen oplossing lijkt te zijn. Wat is jullie toekomst nog samen? Soms gaan koppels uit voorzorg in therapie, om de relatie te verrijken. Bespreek het met onze therapeut.</p>\",\"video\":[\"7\"],\"position\":\"right\"}}}}}','2019-02-05 17:26:49','2019-02-05 17:26:49','65150d07-f335-418b-bdda-bb91056fda4c'),(6,19,3,1,1,1,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Familiale Bemiddeling\",\"slug\":\"familiale-bemiddeling\",\"postDate\":1549388640,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":[]}}','2019-02-05 17:44:56','2019-02-05 17:44:56','62bf781f-9b5d-4bb8-a439-e7ae2c22b012'),(7,20,3,1,1,1,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Individuele Therapie\",\"slug\":\"individuele-therapie\",\"postDate\":1549388700,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":[]}}','2019-02-05 17:45:08','2019-02-05 17:45:08','f9a3c816-3517-4693-9b60-9116aabf76c1'),(8,21,3,1,1,1,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Relatietherapie\",\"slug\":\"relatietherapie\",\"postDate\":1549388700,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":[]}}','2019-02-05 17:45:13','2019-02-05 17:45:13','073463c7-dc8c-41c7-a1ce-de94b0da1fc9'),(9,22,3,1,1,1,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Love2Us\",\"slug\":\"love2us\",\"postDate\":1549388700,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":[]}}','2019-02-05 17:45:30','2019-02-05 17:45:30','577ebde6-9d2d-4d0f-a446-d16357c2c7d3'),(10,23,3,1,1,1,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Bedrijfstherapie\",\"slug\":\"bedrijfstherapie\",\"postDate\":1549388700,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":[]}}','2019-02-05 17:45:42','2019-02-05 17:45:42','83864417-679c-4c2a-8e1d-f16bf3df6639'),(11,2,2,1,1,6,'','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"53\":{\"4\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Soms heeft een zoektocht, een gids nodig\",\"description\":\"<p>Ben je de weg kwijt, voel je je eenzaam en onbegrepen, twijfel je aan jezelf, voel je je uitgeblust, is de magie uit jullie relatie verdwenen, ontbreekt het je aan levenslust , stel je vragen bij je toekomst,… Weet je, iedereen verdient gelukkig te zijn en dit ook te voelen. Bij careto ondersteunen we koppels, kinderen, ouders en individuen in hun zoektocht naar hun eigen geluk.</p>\\n<p>Scheiden brengt veel zorgen, onzekerheden en verdriet met zich mee. Dikwijls ontstaat er ook een strijd, die niet alleen emotioneel maar ook financieel uitputtend kan zijn. Bemiddeling houdt jullie uit de strijd met elkaar... De bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex-partner en ouder.</p>\",\"image\":[],\"video\":[\"5\"],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"Therapie\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":\"20\"}}},\"14\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Zing je eigen lied,  dans je eigen dans\",\"description\":\"<p>Wanneer een moeilijke fase je leven binnensluipt, hebben jouw emoties zorg en aandacht nodig. Careto is een ruimte waar je even tot rust kan komen, vrij en on over je emoties kan spreken. Een plaats waar alles mag zijn en niets ‘moet’. Een plek waar je gedachten, angsten, boosheid, verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt.</p>\",\"image\":[],\"video\":[\"6\"],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"15\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Verandering begint bij jezelf, eenzaam in de relatie?\",\"description\":\"<p>Geen uitweg meer in de sleur van het dagdagelijks leven? Hoe moet het verder met jullie relatie na ontrouw van je partner? Het gevoel als broer en zus te leven? Jullie zijn niet de enige met dit probleem.</p>\\n<p>Dagelijks wordt je geconfronteerd met ruzies die jullie uitputten en waarvoor geen oplossing lijkt te zijn. Wat is jullie toekomst nog samen? Soms gaan koppels uit voorzorg in therapie, om de relatie te verrijken. Bespreek het met onze therapeut.</p>\",\"image\":[],\"video\":[\"7\"],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}}}}}','2019-02-05 17:47:41','2019-02-05 17:47:41','2bc33d86-307a-4eb2-acb0-91a8de085a87'),(12,19,3,1,1,2,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Familiale Bemiddeling\",\"slug\":\"familiale-bemiddeling\",\"postDate\":1549388640,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":{\"27\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 1\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"24\"],\"video\":[],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"28\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 2 Rechts\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"25\"],\"video\":[],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"29\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 3 Links\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"26\"],\"video\":[],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}}}}}','2019-02-05 17:54:08','2019-02-05 17:54:08','b11fad00-da5f-487a-a0d9-153c4289ef45'),(13,2,2,1,1,7,'','{\"typeId\":\"2\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1549385100,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"53\":{\"4\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Soms heeft een zoektocht, een gids nodig\",\"description\":\"<p>Ben je de weg kwijt, voel je je eenzaam en onbegrepen, twijfel je aan jezelf, voel je je uitgeblust, is de magie uit jullie relatie verdwenen, ontbreekt het je aan levenslust , stel je vragen bij je toekomst,… Weet je, iedereen verdient gelukkig te zijn en dit ook te voelen. Bij careto ondersteunen we koppels, kinderen, ouders en individuen in hun zoektocht naar hun eigen geluk.</p>\\n<p>Scheiden brengt veel zorgen, onzekerheden en verdriet met zich mee. Dikwijls ontstaat er ook een strijd, die niet alleen emotioneel maar ook financieel uitputtend kan zijn. Bemiddeling houdt jullie uit de strijd met elkaar... De bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex-partner en ouder.</p>\",\"image\":[],\"video\":[\"5\"],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"Bemiddeling\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":\"19\"}}},\"14\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Zing je eigen lied,  dans je eigen dans\",\"description\":\"<p>Wanneer een moeilijke fase je leven binnensluipt, hebben jouw emoties zorg en aandacht nodig. Careto is een ruimte waar je even tot rust kan komen, vrij en on over je emoties kan spreken. Een plaats waar alles mag zijn en niets ‘moet’. Een plek waar je gedachten, angsten, boosheid, verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt.</p>\",\"image\":[],\"video\":[\"6\"],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"15\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Verandering begint bij jezelf, eenzaam in de relatie?\",\"description\":\"<p>Geen uitweg meer in de sleur van het dagdagelijks leven? Hoe moet het verder met jullie relatie na ontrouw van je partner? Het gevoel als broer en zus te leven? Jullie zijn niet de enige met dit probleem.</p>\\n<p>Dagelijks wordt je geconfronteerd met ruzies die jullie uitputten en waarvoor geen oplossing lijkt te zijn. Wat is jullie toekomst nog samen? Soms gaan koppels uit voorzorg in therapie, om de relatie te verrijken. Bespreek het met onze therapeut.</p>\",\"image\":[],\"video\":[\"7\"],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}}}}}','2019-02-05 17:58:50','2019-02-05 17:58:50','e71663e9-b3f8-4994-a7a8-c00ff441fdb4'),(14,19,3,1,1,3,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Familiale Bemiddeling\",\"slug\":\"familiale-bemiddeling\",\"postDate\":1549388640,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":{\"27\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Familiale Bemiddeling\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"24\"],\"video\":[],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"28\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 2 Rechts\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"25\"],\"video\":[],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"29\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 3 Links\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"26\"],\"video\":[],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}}}}}','2019-02-05 18:04:30','2019-02-05 18:04:30','cae5a1ca-3e17-4587-8d16-7354cae3df63'),(15,31,3,1,1,1,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"Familiale bemiddeling\",\"slug\":\"familiale-bemiddeling\",\"postDate\":1549390200,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"19\",\"fields\":{\"4\":{\"32\":{\"type\":\"heading\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading\"}},\"33\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"leadText\":false,\"heading\":\"Subtitel\",\"body\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"width\":\"full\",\"position\":\"full\",\"socialMedia\":[]}}},\"25\":[\"30\"]}}','2019-02-05 18:10:23','2019-02-05 18:10:23','d210acc9-9d02-460d-95a5-320d284dcf3a'),(16,19,3,1,1,4,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Familiale Bemiddeling\",\"slug\":\"familiale-bemiddeling\",\"postDate\":1549388640,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"53\":{\"27\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Familiale Bemiddeling\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"24\"],\"video\":[],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"meer info\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":\"31\"}}},\"28\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 2 Rechts\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"25\"],\"video\":[],\"position\":\"right\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}},\"29\":{\"type\":\"pageSection\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading 3 Links\",\"description\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"image\":[\"26\"],\"video\":[],\"position\":\"left\",\"button\":{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}}}}}}','2019-02-05 18:12:38','2019-02-05 18:12:38','3ebd6419-2bc5-492c-9264-e7cfeaa2f474'),(17,31,3,1,1,2,'','{\"typeId\":\"4\",\"authorId\":\"1\",\"title\":\"Familiale bemiddeling info\",\"slug\":\"familiale-bemiddeling\",\"postDate\":1549390200,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"19\",\"fields\":{\"4\":{\"32\":{\"type\":\"heading\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"heading\":\"Heading\"}},\"33\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"leadText\":false,\"heading\":\"Subtitel\",\"body\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>\",\"width\":\"full\",\"position\":\"full\"}}},\"25\":[\"30\"]}}','2019-02-05 19:28:24','2019-02-05 19:28:24','56722f4c-24fb-42b7-8abd-729f187b3b30'),(18,41,4,1,1,1,'Revision from Feb 5, 2019, 12:09:34 PM','{\"typeId\":\"5\",\"authorId\":null,\"title\":\"Contact\",\"slug\":\"contact\",\"postDate\":1549397340,\"expiryDate\":null,\"enabled\":\"1\",\"newParentId\":null,\"fields\":{\"25\":[],\"26\":[]}}','2019-02-05 20:09:55','2019-02-05 20:09:55','08717663-628b-46fd-9888-688374061e6f'),(19,41,4,1,1,2,'','{\"typeId\":\"5\",\"authorId\":null,\"title\":\"Contact\",\"slug\":\"contact\",\"postDate\":1549397340,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"23\":\"<p>Contacteer CareTo ...</p>\",\"25\":[],\"26\":[],\"49\":\"Contact\"}}','2019-02-05 20:09:55','2019-02-05 20:09:55','ae862d05-6aac-419e-b55b-c912afa9c653'),(20,41,4,1,1,3,'','{\"typeId\":\"5\",\"authorId\":null,\"title\":\"Contact\",\"slug\":\"contact\",\"postDate\":1549397340,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"23\":\"<p>Contacteer CareTo ...</p>\",\"25\":[\"30\"],\"26\":[],\"49\":\"Contact\"}}','2019-02-05 20:11:59','2019-02-05 20:11:59','fdc5dc70-25c7-48f4-8653-f667b13a41ba'),(21,41,4,1,1,4,'','{\"typeId\":\"5\",\"authorId\":null,\"title\":\"Contact\",\"slug\":\"contact\",\"postDate\":1549397340,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"23\":\"<p>Contacteer CareTo ...</p>\",\"25\":[\"30\"],\"26\":[],\"37\":\"Contacteer CareTo\",\"49\":\"Contact\"}}','2019-02-05 20:12:20','2019-02-05 20:12:20','e1efc925-1c17-418e-b8f0-2967db4987c9');
/*!40000 ALTER TABLE `entryversions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2019-02-05 15:44:19','2019-02-05 15:44:19','2e6fd2d5-770c-4818-bae7-4e41941c504e'),(2,'Globals','2019-02-05 16:45:08','2019-02-05 16:45:08','09993af6-8ddd-4fb2-8e61-9d49d82cd67c'),(3,'Categories','2019-02-05 16:45:08','2019-02-05 16:45:08','477ff96a-78f7-4479-8bc7-3eb4266a590a'),(4,'Content Builder','2019-02-05 16:45:08','2019-02-05 16:45:08','f999caae-8823-4fd5-b7ec-2855c3d5611c'),(5,'Teaser','2019-02-05 16:45:08','2019-02-05 16:45:08','4020c82b-7e58-4463-8ce5-06c8e7b59cf2'),(6,'Sections','2019-02-05 16:45:08','2019-02-05 16:45:08','7977128d-bd10-4e46-8871-96f94c3d06f2'),(7,'Header','2019-02-05 16:45:08','2019-02-05 16:45:08','7ab27bc0-119a-486c-8f9c-8a671b07c7c1'),(8,'Videos','2019-02-05 16:45:08','2019-02-05 16:45:08','b957a8d9-396d-41e3-9942-0cc56c0e2ff6'),(10,'Images','2019-02-05 16:45:08','2019-02-05 16:45:08','2faa2c63-b4fd-4bca-a79a-da9a6f06b109'),(12,'Relations','2019-02-05 16:45:08','2019-02-05 16:45:08','4839f379-a3a0-42ad-aa9c-4667bfa66987'),(13,'Social Media','2019-02-05 16:45:08','2019-02-05 16:45:08','05a89714-c405-4857-bb9e-8923651a7d37');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (18,5,5,47,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','c189e32e-a696-4579-8b60-e08671430882'),(19,5,5,48,0,2,'2019-02-05 16:45:11','2019-02-05 16:45:11','9d96e265-15a6-4260-afae-6feb985912a6'),(20,6,6,35,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','9e76adf2-0d07-4e98-bbda-ba83bb449e56'),(21,6,6,22,0,2,'2019-02-05 16:45:11','2019-02-05 16:45:11','68f04c1a-e557-45ea-b446-c17f0c676ba1'),(22,6,7,2,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','19f67aa9-c0b6-45cc-887d-63097050f5ce'),(23,6,7,41,0,2,'2019-02-05 16:45:11','2019-02-05 16:45:11','62930b90-b5b0-49b3-ba26-0ee91f53559a'),(24,6,8,25,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','d8d1185a-4920-4f0f-8534-0aacb05016c3'),(25,6,8,26,0,2,'2019-02-05 16:45:11','2019-02-05 16:45:11','018cad16-03cc-41f2-862f-ceca647987ae'),(26,6,9,4,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','8c583ce6-c8da-41a0-b5da-a8badb9798be'),(43,8,13,31,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','c309f111-3211-4785-9ac2-9a7e0004a760'),(44,9,14,30,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','e46e0739-2d8a-41c5-97f5-3f46eac87590'),(45,10,15,33,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','759dee61-2b0e-4876-a437-c6c6446a0b73'),(46,11,16,32,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','94b4955a-a24d-4d05-9273-eacdd253e64c'),(47,12,17,34,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','27e729e9-8fcd-4747-990c-3bbc8b9f2c95'),(48,13,18,3,0,1,'2019-02-05 16:45:11','2019-02-05 16:45:11','ffb31b5c-8cef-49fa-90ed-b6415190838c'),(49,13,18,1,0,2,'2019-02-05 16:45:11','2019-02-05 16:45:11','9535a07d-8089-4407-b47e-8b06d0dfe727'),(50,13,18,24,0,3,'2019-02-05 16:45:11','2019-02-05 16:45:11','afba3559-ce00-4092-a289-be4c4f6c2602'),(51,13,18,38,0,4,'2019-02-05 16:45:11','2019-02-05 16:45:11','dce94dab-376c-4310-ae47-f68edd0c1af6'),(56,7,20,36,0,1,'2019-02-05 17:02:25','2019-02-05 17:02:25','4a075349-a8cd-45d8-8299-dd1b094741d6'),(57,7,20,37,0,2,'2019-02-05 17:02:25','2019-02-05 17:02:25','6a2893da-0ee7-4c05-b2c0-1390afeb3b59'),(58,7,21,53,0,1,'2019-02-05 17:02:25','2019-02-05 17:02:25','679ada1b-78e9-4a32-9b50-4e9b537e595d'),(63,15,23,59,0,1,'2019-02-05 17:32:14','2019-02-05 17:32:14','59d695d0-8d76-4c42-8688-4cfc2bf9d758'),(64,15,23,60,0,2,'2019-02-05 17:32:14','2019-02-05 17:32:14','6102a4ae-fabb-487f-bb3e-0d9bebce6e17'),(66,16,25,58,0,1,'2019-02-05 17:33:35','2019-02-05 17:33:35','41deebce-5266-432f-be29-7a2b2cc539cb'),(67,17,26,53,0,1,'2019-02-05 17:38:32','2019-02-05 17:38:32','b842f135-3f36-46fb-84fd-6deb10f86498'),(68,18,27,25,0,1,'2019-02-05 17:39:21','2019-02-05 17:39:21','e251342c-ef4e-4aff-b759-c03811ef25bf'),(69,18,27,36,0,2,'2019-02-05 17:39:21','2019-02-05 17:39:21','3d29cb86-ba14-46e9-9df1-5c99e208fb15'),(70,18,27,37,0,3,'2019-02-05 17:39:21','2019-02-05 17:39:21','34cbdc3c-b122-47ef-8c70-e0c0cc1db5b3'),(71,18,28,4,0,1,'2019-02-05 17:39:21','2019-02-05 17:39:21','3a25e50e-fe26-46c3-a0a8-d131712e3004'),(77,14,30,54,0,1,'2019-02-05 17:46:57','2019-02-05 17:46:57','e7343f25-cfe7-45da-9c28-a462cfd58cad'),(78,14,30,55,0,2,'2019-02-05 17:46:57','2019-02-05 17:46:57','88393c06-7229-47d3-b47b-003acd03ca84'),(79,14,30,61,0,3,'2019-02-05 17:46:57','2019-02-05 17:46:57','96311920-72cb-4bd1-a4fa-85402c5d3796'),(80,14,30,56,0,4,'2019-02-05 17:46:57','2019-02-05 17:46:57','4433a620-ec37-43ba-86ed-07d3c895ae70'),(81,14,30,57,0,5,'2019-02-05 17:46:57','2019-02-05 17:46:57','eb72803c-2306-4029-ad83-096e657feed6'),(82,14,30,63,0,6,'2019-02-05 17:46:57','2019-02-05 17:46:57','f96c0923-e483-4c49-ac95-85a09b0dea13'),(83,1,31,5,1,1,'2019-02-05 18:10:43','2019-02-05 18:10:43','17562edf-63c7-40c1-9c9b-19a552fa0c13'),(84,2,32,6,0,1,'2019-02-05 18:10:43','2019-02-05 18:10:43','1d475fb7-5b73-47b0-9988-728880813597'),(85,2,32,7,0,2,'2019-02-05 18:10:43','2019-02-05 18:10:43','2f2c3b02-a3e9-4bab-a05e-8c947bac26da'),(86,2,32,8,1,3,'2019-02-05 18:10:43','2019-02-05 18:10:43','40bc6800-3101-4f5e-930d-f3b81ec3dc91'),(87,2,32,9,1,4,'2019-02-05 18:10:43','2019-02-05 18:10:43','d6d59654-fed4-4e11-8189-f499eb2e2a92'),(88,2,32,10,1,5,'2019-02-05 18:10:43','2019-02-05 18:10:43','0b364a38-8bf4-4952-af3d-16b418a6aa2c'),(89,3,33,12,1,1,'2019-02-05 18:10:43','2019-02-05 18:10:43','8fd4b35b-c5d0-41ad-82de-3381d7865d68'),(90,3,33,13,0,2,'2019-02-05 18:10:43','2019-02-05 18:10:43','90882991-aadc-4877-92a7-d848f0cd1f77'),(91,3,33,14,1,3,'2019-02-05 18:10:43','2019-02-05 18:10:43','287a874a-9642-4d69-9471-5c4887f86e21'),(92,3,33,15,1,4,'2019-02-05 18:10:43','2019-02-05 18:10:43','74d25fd0-11dd-4cc4-9288-1014c861dbbf'),(93,4,34,16,0,1,'2019-02-05 18:10:43','2019-02-05 18:10:43','fd40d552-76d9-40b3-8c5b-9ee6937f3451'),(94,4,34,17,1,2,'2019-02-05 18:10:43','2019-02-05 18:10:43','2039aa97-9f5f-4f3a-a274-b0647af567e9'),(95,4,34,18,1,3,'2019-02-05 18:10:43','2019-02-05 18:10:43','7c9f71cf-116c-4904-86d7-0031babd11ed'),(96,4,34,19,0,4,'2019-02-05 18:10:43','2019-02-05 18:10:43','529e238a-e03a-4178-a3a7-7322a30ac29d'),(97,4,34,20,1,5,'2019-02-05 18:10:43','2019-02-05 18:10:43','f318a30f-9ba7-4aa0-853f-05982e1019a6'),(98,4,34,21,1,6,'2019-02-05 18:10:43','2019-02-05 18:10:43','3cb14cda-1fa1-4a00-8f8a-e86ebdadcf17'),(99,19,35,64,0,1,'2019-02-05 19:26:02','2019-02-05 19:26:02','25363b92-c5ec-4256-809b-6aa5f8db0a6d'),(100,20,36,36,0,1,'2019-02-05 20:09:34','2019-02-05 20:09:34','148bbfa7-64d5-4da1-914c-d7f206023879'),(101,20,36,37,0,2,'2019-02-05 20:09:34','2019-02-05 20:09:34','c1be260f-7be4-4cb7-a24d-b0799a0bb771'),(102,20,37,25,0,1,'2019-02-05 20:09:34','2019-02-05 20:09:34','bb860254-56f1-413a-bc3f-c8984ff00329'),(103,20,37,26,0,2,'2019-02-05 20:09:34','2019-02-05 20:09:34','6cf541a1-c771-494e-9a9c-3a3a4be9c73a'),(104,20,38,49,0,1,'2019-02-05 20:09:34','2019-02-05 20:09:34','f58e5f3c-6c6a-406b-b202-b9f883c6517e'),(105,20,38,23,0,2,'2019-02-05 20:09:34','2019-02-05 20:09:34','901352ce-f446-4347-9e9a-f42df1bae472');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\MatrixBlock','2019-02-05 16:45:08','2019-02-05 18:10:43',NULL,'7e9c82b0-083a-4b9e-bc9c-31662a8f3628'),(2,'craft\\elements\\MatrixBlock','2019-02-05 16:45:08','2019-02-05 18:10:43',NULL,'f6f94d9c-04ed-4d08-85c7-a9fc45f927a3'),(3,'craft\\elements\\MatrixBlock','2019-02-05 16:45:09','2019-02-05 18:10:43',NULL,'6a06a9bd-0a76-421b-8125-41a4c9ead610'),(4,'craft\\elements\\MatrixBlock','2019-02-05 16:45:09','2019-02-05 18:10:43',NULL,'54f6de39-1374-4dc7-9b59-826127f0ac58'),(5,'craft\\elements\\MatrixBlock','2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'5840686a-9862-402e-a802-afd1df5059a7'),(6,'craft\\elements\\Entry','2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'75897d66-503a-4380-ab29-8f0241f14017'),(7,'craft\\elements\\Entry','2019-02-05 16:45:11','2019-02-05 17:02:25',NULL,'964d8728-7d0c-46ac-b0fc-6993821ab196'),(8,'craft\\elements\\Asset','2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'0f242cf9-1f95-4340-8746-e53857043973'),(9,'craft\\elements\\Asset','2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'951fb3e3-710f-4fb0-88ac-136917e57afe'),(10,'craft\\elements\\Asset','2019-02-05 16:45:11','2019-02-05 16:45:11','2019-02-05 16:54:05','9bf147fc-ac08-445e-9f46-4512d9d1e923'),(11,'craft\\elements\\Asset','2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'5995dbde-5175-48bb-8a70-70da51566196'),(12,'craft\\elements\\Asset','2019-02-05 16:45:11','2019-02-05 16:45:11','2019-02-05 16:54:01','52367875-f616-4e05-aa4f-7372d30afd84'),(13,'craft\\elements\\GlobalSet','2019-02-05 16:45:11','2019-02-05 16:45:11',NULL,'129ea065-edb9-4478-828b-6cb619a3328e'),(14,'craft\\elements\\MatrixBlock','2019-02-05 16:53:52','2019-02-05 17:46:57',NULL,'65351a45-8610-46c5-bc0c-cbcd7b7052ab'),(15,'craft\\elements\\MatrixBlock','2019-02-05 17:32:14','2019-02-05 17:32:14',NULL,'2edef910-150e-4e1e-941a-18597a6d0952'),(16,'craft\\elements\\GlobalSet','2019-02-05 17:32:51','2019-02-05 17:33:35',NULL,'6fd50707-6c72-45c6-8664-904611a37057'),(17,'craft\\elements\\Entry','2019-02-05 17:38:32','2019-02-05 17:38:32',NULL,'00939823-5d73-47a6-8f3b-98d9fc8c1806'),(18,'craft\\elements\\Entry','2019-02-05 17:39:21','2019-02-05 17:39:21',NULL,'94753381-46d0-484e-bed4-42537996cfef'),(19,'craft\\elements\\GlobalSet','2019-02-05 19:26:02','2019-02-05 19:26:02',NULL,'bcc9f9c7-e89b-47a9-a9b2-525b022e3897'),(20,'craft\\elements\\Entry','2019-02-05 20:09:34','2019-02-05 20:09:34',NULL,'8af52315-de4f-4bff-ab0d-61151b0fbcf0');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (5,5,'Content',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','4e78ea33-9bf4-49cf-b19a-3d60abc8ae19'),(6,6,'Teaser',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','1d131193-79c2-4e94-9c14-b5e0a78b6fbb'),(7,6,'Structure',2,'2019-02-05 16:45:11','2019-02-05 16:45:11','0d493e54-ea6e-4036-a240-f2dc13d113fd'),(8,6,'Visuals',3,'2019-02-05 16:45:11','2019-02-05 16:45:11','5735f30e-6893-489c-85d6-a2f19417a294'),(9,6,'Content',4,'2019-02-05 16:45:11','2019-02-05 16:45:11','d14d5183-fd15-46f3-be8e-89a42c68d323'),(13,8,'Content',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','0e16bb0b-3802-4872-9b52-045b0700cfe9'),(14,9,'Content',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','f358b8dc-337f-44be-9002-f69a6f8850a8'),(15,10,'Content',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','6ddbbd80-aff9-4642-b059-d7e36aec608a'),(16,11,'Content',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','b49bac8b-df47-4f6a-9e5d-40edf15de8a2'),(17,12,'Content',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','a822ef45-73a1-436e-9777-bdfb9349e33b'),(18,13,'Business Information',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','fbdea44d-9adf-4608-a803-398493399cb1'),(20,7,'Pagina Info',1,'2019-02-05 17:02:25','2019-02-05 17:02:25','f12b1475-67dd-40ab-a810-52e7b4509d8a'),(21,7,'Content ( Visuele Builder )',2,'2019-02-05 17:02:25','2019-02-05 17:02:25','52d63b3e-aacf-4ed0-a71f-1655a3389a25'),(23,15,'Content',1,'2019-02-05 17:32:14','2019-02-05 17:32:14','1b28273f-9b6a-4e8c-ab8f-dfb6fa55703a'),(25,16,'Sociale Media',1,'2019-02-05 17:33:35','2019-02-05 17:33:35','8bced3cd-2e9e-4c49-bcc7-193d4b8121d7'),(26,17,'Visuele Builder',1,'2019-02-05 17:38:32','2019-02-05 17:38:32','d1a69edc-301c-4be7-a2ef-7c4cbcb0e364'),(27,18,'Pagina Info',1,'2019-02-05 17:39:21','2019-02-05 17:39:21','61ca770f-8805-42ef-8251-7828abecf66b'),(28,18,'Content Builder',2,'2019-02-05 17:39:21','2019-02-05 17:39:21','88148c1a-8b05-4e03-b06e-2e711ab1dd7a'),(30,14,'Content',1,'2019-02-05 17:46:57','2019-02-05 17:46:57','240021e3-d611-42c2-8c48-0286e8407d58'),(31,1,'Content',1,'2019-02-05 18:10:43','2019-02-05 18:10:43','3811206f-493f-4faa-8f55-9e3f836b8ba8'),(32,2,'Content',1,'2019-02-05 18:10:43','2019-02-05 18:10:43','6683d8e5-ba80-4cc4-a6d3-8e982f204d0b'),(33,3,'Content',1,'2019-02-05 18:10:43','2019-02-05 18:10:43','8f91d4e3-26f9-4a9f-9980-28d2baef656a'),(34,4,'Content',1,'2019-02-05 18:10:43','2019-02-05 18:10:43','7c79519b-fb12-4546-b4fc-1d868b0e096d'),(35,19,'Branding',1,'2019-02-05 19:26:02','2019-02-05 19:26:02','8864fbc0-679b-4f8b-8f61-a43058468491'),(36,20,'Header',1,'2019-02-05 20:09:34','2019-02-05 20:09:34','24802d7b-51cc-401c-abeb-78cb15184c2d'),(37,20,'Visuals',2,'2019-02-05 20:09:34','2019-02-05 20:09:34','f97acec9-d4cd-4e62-9932-e7c04da06cd9'),(38,20,'Page',3,'2019-02-05 20:09:34','2019-02-05 20:09:34','522cde93-b563-4971-8832-42bfa0bf37c0');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,2,'Address','address','global','',1,'none',NULL,'barrelstrength\\sproutfields\\fields\\Address','{\"value\":null,\"addressHelper\":{},\"defaultLanguage\":null,\"defaultCountry\":\"BE\",\"showCountryDropdown\":true,\"hideCountryDropdown\":\"1\",\"highlightCountries\":[]}','2019-02-05 16:45:08','2019-02-05 16:45:08','9479e2aa-aa84-4b85-bedf-ae3f0acc9133'),(2,3,'Blog categories','blogCategories','global','',1,'site',NULL,'craft\\fields\\Categories','{\"branchLimit\":\"3\",\"sources\":\"*\",\"source\":\"group:0e2ea179-556a-4404-ad6b-d2a673b23e8e\",\"targetSiteId\":null,\"viewMode\":null,\"limit\":null,\"selectionLabel\":\"Choose blog categories ( max. 3 )\",\"localizeRelations\":false}','2019-02-05 16:45:08','2019-02-05 16:45:08','f243311c-5768-49be-b903-2917c7f18dcf'),(3,2,'Business name','businessName','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:08','2019-02-05 16:45:08','6d478d4f-9299-4ee7-9a56-6a43774f3007'),(4,4,'Content Builder','contentBuilder','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_contentbuilder}}\",\"localizeBlocks\":false}','2019-02-05 16:45:08','2019-02-05 18:10:43','7e29e417-2ff9-4158-aeb5-b789113c4d1f'),(5,NULL,'Heading','heading','matrixBlockType:26001dc6-a1b6-43af-8542-d488f87d3e94','Add main heading text ( h2 )',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','2f5fad2b-51f5-4fa8-afc8-4a3ecd124cf8'),(6,NULL,'Lead Text ?','leadText','matrixBlockType:da843291-6248-409e-a948-94ea290bf850','Select this option if the text is a lead text. Warning ! Position and Width have no influence when this option is selected!',1,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":\"\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','3e982c8d-bcfa-48a8-b921-ad35611bcfec'),(7,NULL,'Heading','heading','matrixBlockType:da843291-6248-409e-a948-94ea290bf850','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','9ee8e929-d66e-4446-80f0-265283b4dec4'),(8,NULL,'Body','body','matrixBlockType:da843291-6248-409e-a948-94ea290bf850','',1,'none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"Standard.json\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','c3e7b85b-d2ec-430e-a959-e36a853be3d4'),(9,NULL,'Width','width','matrixBlockType:da843291-6248-409e-a948-94ea290bf850','',1,'none',NULL,'rias\\widthfieldtype\\fields\\Width','{\"options\":{\"1/6\":\"\",\"1/5\":\"\",\"1/4\":\"\",\"1/3\":\"1\",\"2/5\":\"\",\"1/2\":\"1\",\"3/5\":\"\",\"2/3\":\"\",\"3/4\":\"\",\"4/5\":\"\",\"5/6\":\"\",\"full\":\"1\"},\"default\":\"full\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','83eb216a-4f98-4935-8ed1-5946f93b5ed6'),(10,NULL,'Position','position','matrixBlockType:da843291-6248-409e-a948-94ea290bf850','Choosing the postion only has an influence on half blocks!',1,'none',NULL,'rias\\positionfieldtype\\fields\\Position','{\"options\":{\"left\":\"1\",\"center\":\"\",\"right\":\"1\",\"full\":\"1\",\"drop-left\":\"\",\"drop-right\":\"\"},\"default\":\"full\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','c1e231a8-b866-44f4-8d0f-5491d9210ed3'),(12,NULL,'Image','image','matrixBlockType:cb5bf083-a7d2-4696-91a9-7f90ac118ca0','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"singleUploadLocationSubpath\":\"{owner.slug}\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 16:45:08','2019-02-05 18:10:43','a5da4306-09e4-4217-aa7b-35e7f40593e2'),(13,NULL,'Caption','caption','matrixBlockType:cb5bf083-a7d2-4696-91a9-7f90ac118ca0','The caption will only show if the image is displayed in full width !',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"100\",\"columnType\":\"text\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','00f35c2a-1ee5-4c0d-9404-36b89ab48574'),(14,NULL,'Width','width','matrixBlockType:cb5bf083-a7d2-4696-91a9-7f90ac118ca0','',1,'none',NULL,'rias\\widthfieldtype\\fields\\Width','{\"options\":{\"1/6\":\"\",\"1/5\":\"\",\"1/4\":\"\",\"1/3\":\"\",\"2/5\":\"\",\"1/2\":\"1\",\"3/5\":\"\",\"2/3\":\"\",\"3/4\":\"\",\"4/5\":\"\",\"5/6\":\"\",\"full\":\"1\"},\"default\":\"full\"}','2019-02-05 16:45:08','2019-02-05 18:10:43','2cb6eb30-3d11-4b9b-a0a4-1d54fbe3cd50'),(15,NULL,'Position','position','matrixBlockType:cb5bf083-a7d2-4696-91a9-7f90ac118ca0','The position only influences images when they\'re half a block!',1,'none',NULL,'rias\\positionfieldtype\\fields\\Position','{\"options\":{\"left\":\"1\",\"center\":\"\",\"right\":\"1\",\"full\":\"1\",\"drop-left\":\"\",\"drop-right\":\"\"},\"default\":\"full\"}','2019-02-05 16:45:09','2019-02-05 18:10:43','3df57062-6ff3-4545-a06f-ec30ec62d071'),(16,NULL,'Video Url','videoUrl','matrixBlockType:299bc55b-d15a-4949-97f2-eb0d2e563898','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:09','2019-02-05 18:10:43','88313d6e-13d8-406c-8811-c15bc5b71f3b'),(17,NULL,'Video Source','videoSource','matrixBlockType:299bc55b-d15a-4949-97f2-eb0d2e563898','',1,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Vimeo\",\"value\":\"vimeo\",\"default\":\"1\"},{\"label\":\"Youtube\",\"value\":\"youtube\",\"default\":\"\"}]}','2019-02-05 16:45:09','2019-02-05 18:10:43','fddb769f-f4c8-407a-8cd1-6c05e2c9d0a2'),(18,NULL,'Video Thumbnail','videoThumbnail','matrixBlockType:299bc55b-d15a-4949-97f2-eb0d2e563898','Add a nice looking thumbnail for the video',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 16:45:09','2019-02-05 18:10:43','7af4a442-0d31-4637-8b25-64c12865b3b4'),(19,NULL,'Caption','caption','matrixBlockType:299bc55b-d15a-4949-97f2-eb0d2e563898','The caption will only show if the image is displayed in full width !',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:09','2019-02-05 18:10:43','cb58bfc5-5133-4998-ab6e-929d6d7939a0'),(20,NULL,'Width','width','matrixBlockType:299bc55b-d15a-4949-97f2-eb0d2e563898','',1,'none',NULL,'rias\\widthfieldtype\\fields\\Width','{\"options\":{\"1/6\":\"\",\"1/5\":\"\",\"1/4\":\"\",\"1/3\":\"\",\"2/5\":\"\",\"1/2\":\"1\",\"3/5\":\"\",\"2/3\":\"\",\"3/4\":\"\",\"4/5\":\"\",\"5/6\":\"\",\"full\":\"1\"},\"default\":\"full\"}','2019-02-05 16:45:09','2019-02-05 18:10:43','cf30ee49-954a-4715-b230-23975eea1ba6'),(21,NULL,'Position','position','matrixBlockType:299bc55b-d15a-4949-97f2-eb0d2e563898','',1,'none',NULL,'rias\\positionfieldtype\\fields\\Position','{\"options\":{\"left\":\"1\",\"center\":\"\",\"right\":\"1\",\"full\":\"1\",\"drop-left\":\"\",\"drop-right\":\"\"},\"default\":\"full\"}','2019-02-05 16:45:09','2019-02-05 18:10:43','60bef741-f542-495d-a877-61ce244f6f05'),(22,5,'Description','teaserDescription','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"1\",\"initialRows\":\"3\",\"charLimit\":\"250\",\"columnType\":\"text\"}','2019-02-05 16:45:09','2019-02-05 16:45:09','23f65acb-01ee-4654-92ac-9aeff81ed483'),(23,6,'Description','sectionDescription','global','',1,'none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"\",\"availableTransforms\":\"*\"}','2019-02-05 16:45:09','2019-02-05 16:45:09','6cd11a34-7bf1-4568-8fd8-d94489f16a59'),(24,2,'Email Address','email','global','',1,'none',NULL,'barrelstrength\\sproutfields\\fields\\Email','{\"customPattern\":\"(.*)@pixville.be$\",\"customPatternToggle\":\"1\",\"customPatternErrorMessage\":\"\",\"uniqueEmail\":\"\",\"placeholder\":\"\"}','2019-02-05 16:45:09','2019-02-05 16:45:09','287e08eb-254e-4334-a7d1-78acaa94a267'),(25,7,'Hero Image','heroImage','global','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:3ae495a2-3065-4cbf-a837-37ac98b1267f\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add or upload hero image ( header photo )\",\"localizeRelations\":false}','2019-02-05 16:45:09','2019-02-05 16:45:09','cc6d3e25-f923-402b-9473-d601c49caaed'),(26,8,'Hero video','heroVideo','global','Upload your video in mp4 format, make sure the video doesn\'t exceed 10 seconds in length, the shorter the better.',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:7abe41af-4979-4ac8-be5e-8c0c85a91dd3\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"video\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add or upload header video\",\"localizeRelations\":false}','2019-02-05 16:45:09','2019-02-05 16:45:09','440ee632-f669-46f9-b5f4-343a65f1ca73'),(29,6,'Name','sectionName','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:09','2019-02-05 16:45:09','03ef46d1-ef2a-466d-bd98-3fa159f4f942'),(30,10,'Optimized Hero Images','optimizedHero','global','',1,'none',NULL,'nystudio107\\imageoptimize\\fields\\OptimizedImages','{\"ignoreFilesOfType\":[],\"displayOptimizedImageVariants\":\"1\",\"displayDominantColorPalette\":\"1\",\"displayLazyLoadPlaceholderImages\":\"1\",\"variants\":[{\"width\":\"1440\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"1200\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"1200\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"900\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"},{\"width\":\"576\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"3\",\"aspectRatioY\":\"4\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"}]}','2019-02-05 16:45:09','2019-02-05 16:45:09','16fc9373-e312-433c-8f17-84e2fcdb110e'),(31,10,'Optimized Images','optimizedImages','global','',1,'none',NULL,'nystudio107\\imageoptimize\\fields\\OptimizedImages','{\"ignoreFilesOfType\":[],\"displayOptimizedImageVariants\":\"1\",\"displayDominantColorPalette\":\"1\",\"displayLazyLoadPlaceholderImages\":\"1\",\"variants\":[{\"width\":\"1200\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"992\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"768\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"4\",\"aspectRatioY\":\"3\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"},{\"width\":\"576\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"4\",\"aspectRatioY\":\"3\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"}]}','2019-02-05 16:45:09','2019-02-05 16:45:09','2eac8f76-372f-48c2-89e7-8188e33848b8'),(32,10,'Optimized Overview Images','optimizedOverview','global','',1,'none',NULL,'nystudio107\\imageoptimize\\fields\\OptimizedImages','{\"ignoreFilesOfType\":[],\"displayOptimizedImageVariants\":\"1\",\"displayDominantColorPalette\":\"1\",\"displayLazyLoadPlaceholderImages\":\"1\",\"variants\":[{\"width\":\"800\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"5\",\"aspectRatioY\":\"4\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"500\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"5\",\"aspectRatioY\":\"4\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"400\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"5\",\"aspectRatioY\":\"4\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"}]}','2019-02-05 16:45:10','2019-02-05 16:45:10','3f586fec-d777-4257-9c2b-ab4f923aec40'),(33,10,'Optimized Services','optimizedServices','global','',1,'none',NULL,'nystudio107\\imageoptimize\\fields\\OptimizedImages','{\"ignoreFilesOfType\":[],\"displayOptimizedImageVariants\":\"1\",\"displayDominantColorPalette\":\"1\",\"displayLazyLoadPlaceholderImages\":\"1\",\"variants\":[{\"width\":\"1000\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"9\",\"aspectRatioY\":\"16\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"500\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"9\",\"aspectRatioY\":\"16\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"400\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"9\",\"aspectRatioY\":\"16\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"}]}','2019-02-05 16:45:10','2019-02-05 16:45:10','02911763-8e8f-4856-830e-241d0ff09120'),(34,10,'Optimized Video Thumbnails','optimizedVideoThumbnails','global','',1,'none',NULL,'nystudio107\\imageoptimize\\fields\\OptimizedImages','{\"ignoreFilesOfType\":[],\"displayOptimizedImageVariants\":\"1\",\"displayDominantColorPalette\":\"1\",\"displayLazyLoadPlaceholderImages\":\"1\",\"variants\":[{\"width\":\"1200\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"992\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"768\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"},{\"width\":\"576\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"}]}','2019-02-05 16:45:10','2019-02-05 16:45:10','f815968b-156d-4974-ab8e-9e815c81e89c'),(35,5,'Overview Image','teaserImage','global','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:912b07d6-4f72-4970-9809-cc4258aeade8\",\"singleUploadLocationSubpath\":\"{slug}\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 16:45:10','2019-02-05 16:45:10','86575e5c-a873-4eae-bf9d-eff1d887972a'),(36,7,'Page Name','pageName','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"24\",\"columnType\":\"text\"}','2019-02-05 16:45:10','2019-02-05 16:45:10','a41e8897-67b2-407d-8cb4-c110296c9638'),(37,7,'Page Title','pageTitle','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:10','2019-02-05 16:45:10','47ab7e60-eef3-491c-8c6d-e019842f5d45'),(38,2,'Phone Number','phone','global','Enter the main phone number of your business',1,'none',NULL,'barrelstrength\\sproutfields\\fields\\Phone','{\"customPatternErrorMessage\":\"\",\"limitToSingleCountry\":\"1\",\"country\":\"BE\",\"placeholder\":\"\",\"customPatternToggle\":null,\"mask\":null,\"inputMask\":null}','2019-02-05 16:45:10','2019-02-05 16:45:10','45784098-995c-40a8-a7d3-7faad1234bd7'),(41,12,'Related Blog Posts','relatedBlogPosts','global','',1,'site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:281d49cb-e385-451c-938b-cb4641235de8\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"3\",\"selectionLabel\":\"Select related blog entries ( max. 3 )\",\"localizeRelations\":false}','2019-02-05 16:45:10','2019-02-05 16:45:10','2cd97d0b-a0ee-4b22-be14-929ff9d32856'),(42,12,'Related Projects','relatedProjects','global','',1,'site',NULL,'craft\\fields\\Entries','{\"sources\":[\"projects\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"4\",\"selectionLabel\":\"Select related projects ( max. 4 )\",\"localizeRelations\":false}','2019-02-05 16:45:10','2019-02-05 16:45:10','bda5366d-ab6c-46b9-9f6b-6f9701494660'),(43,10,'Service overview image','serviceImage','global','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:52dc81e2-fba5-448f-8827-2cde4e2ef7a3\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":[\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 16:45:10','2019-02-05 16:45:10','fbbd601d-984b-4722-9f1f-537a6b1aa053'),(46,13,'Social Media Builder','socialBuilder','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_socialbuilder}}\",\"localizeBlocks\":false}','2019-02-05 16:45:10','2019-02-05 16:45:10','e7a66dc1-8fb5-4c11-9395-098086f00bba'),(47,NULL,'Social Media Type','socialType','matrixBlockType:09be61e5-e205-4f6f-bef4-94624de2b5ee','',1,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Email\",\"value\":\"email\",\"default\":\"1\"},{\"label\":\"Facebook\",\"value\":\"facebook\",\"default\":\"\"},{\"label\":\"Instagram\",\"value\":\"instagram\",\"default\":\"\"},{\"label\":\"LinkedIn\",\"value\":\"linkedin\",\"default\":\"\"}]}','2019-02-05 16:45:11','2019-02-05 16:45:11','824acb69-e348-4edc-87dd-1cbd481679e2'),(48,NULL,'Social Media Handle','socialHandle','matrixBlockType:09be61e5-e205-4f6f-bef4-94624de2b5ee','If you are entering your social media, do not enter the full url, only the handle eg. pixville if your facebook url would be facebook.com/pixville',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:11','2019-02-05 16:45:11','00ed994f-d4eb-4c96-af26-756231339f97'),(49,6,'Title','sectionTitle','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:11','2019-02-05 16:45:11','755a19d6-c648-4956-b27a-6aebdded76f4'),(50,8,'Video Source','videoSource','global','',1,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Vimeo\",\"value\":\"vimeo\",\"default\":\"1\"},{\"label\":\"Youtube\",\"value\":\"youtube\",\"default\":\"\"}]}','2019-02-05 16:45:11','2019-02-05 16:45:11','3089bf8f-02a6-4cba-8199-7b5160afae2f'),(51,8,'Video Thumbnail','videoThumbnail','global','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:c94ebff4-b2ef-483a-aa76-81aea5d608ac\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 16:45:11','2019-02-05 16:45:11','bcbb8fb0-15cc-4b09-8b1c-50618185abe0'),(52,8,'Video Url','videoUrl','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:45:11','2019-02-05 16:45:11','f4c2ee5a-dd69-44ea-b0ef-2fb46c831660'),(53,4,'Visual Builder','visualBuilder','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_visualbuilder}}\",\"localizeBlocks\":false}','2019-02-05 16:53:51','2019-02-05 17:46:57','8c2ffb37-a84f-4e8e-acd1-918bf2411ade'),(54,NULL,'Heading','heading','matrixBlockType:176b97a1-6688-4da5-9f6e-af076a591408','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-02-05 16:53:52','2019-02-05 17:46:57','f6f0b2e9-aacc-4263-8331-50888bc29fce'),(55,NULL,'Omschrijving','description','matrixBlockType:176b97a1-6688-4da5-9f6e-af076a591408','',1,'none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"\",\"availableTransforms\":\"*\"}','2019-02-05 16:53:52','2019-02-05 17:46:57','4a610845-4add-497d-b644-2407d53b2cb6'),(56,NULL,'Video Bestand','video','matrixBlockType:176b97a1-6688-4da5-9f6e-af076a591408','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:7abe41af-4979-4ac8-be5e-8c0c85a91dd3\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"video\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 16:53:52','2019-02-05 17:46:57','31ffcee5-00c4-45a1-b98b-ef612e17799e'),(57,NULL,'Positie','position','matrixBlockType:176b97a1-6688-4da5-9f6e-af076a591408','',1,'none',NULL,'rias\\positionfieldtype\\fields\\Position','{\"options\":{\"left\":\"1\",\"center\":\"\",\"right\":\"1\",\"full\":\"\",\"drop-left\":\"\",\"drop-right\":\"\"},\"default\":\"\"}','2019-02-05 16:53:52','2019-02-05 17:46:57','f63058da-24d7-492f-a783-dcf2e893f3d4'),(58,4,'Social Media','socialMedia','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_socialmedia}}\",\"localizeBlocks\":false}','2019-02-05 17:32:14','2019-02-05 17:32:14','1ecb7ca2-2f4b-4be1-9831-d401ed900d94'),(59,NULL,'Sociale Media Naam','socialMediaName','matrixBlockType:635802c2-875d-46ed-ac27-e4787038f284','',1,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Facebook\",\"value\":\"facebook\",\"default\":\"\"},{\"label\":\"Instagram\",\"value\":\"instagram\",\"default\":\"\"},{\"label\":\"Twitter\",\"value\":\"twitter\",\"default\":\"\"}]}','2019-02-05 17:32:14','2019-02-05 17:32:14','bf0a9b8c-926d-45e3-9a9f-9d68a1c88cdb'),(60,NULL,'Sociale Media Url','socialMediaUrl','matrixBlockType:635802c2-875d-46ed-ac27-e4787038f284','',1,'none',NULL,'barrelstrength\\sproutfields\\fields\\Url','{\"customPatternErrorMessage\":\"\",\"customPatternToggle\":\"\",\"customPattern\":\"\",\"placeholder\":\"\"}','2019-02-05 17:32:14','2019-02-05 17:32:14','eb060988-6801-492e-9ec2-ce5588a08322'),(61,NULL,'Afbeelding','image','matrixBlockType:176b97a1-6688-4da5-9f6e-af076a591408','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 17:41:41','2019-02-05 17:46:57','90203408-6f4e-4b51-87b2-8021c2914dbc'),(62,10,'Optimized Full Page','optimizedFullPage','global','',1,'none',NULL,'nystudio107\\imageoptimize\\fields\\OptimizedImages','{\"ignoreFilesOfType\":[\"image/svg\",\"image/gif\"],\"displayOptimizedImageVariants\":\"1\",\"displayDominantColorPalette\":\"1\",\"displayLazyLoadPlaceholderImages\":\"1\",\"variants\":[{\"width\":\"1920\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"1024\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"16\",\"aspectRatioY\":\"9\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"82\",\"format\":\"jpg\"},{\"width\":\"768\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"9\",\"aspectRatioY\":\"16\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"},{\"width\":\"576\",\"useAspectRatio\":\"1\",\"aspectRatioX\":\"9\",\"aspectRatioY\":\"16\",\"retinaSizes\":[\"1\",\"2\"],\"quality\":\"60\",\"format\":\"jpg\"}]}','2019-02-05 17:43:05','2019-02-05 17:43:05','1508fefe-d2bb-4af7-9d80-0f13b444edbe'),(63,NULL,'Knop','button','matrixBlockType:176b97a1-6688-4da5-9f6e-af076a591408','',1,'none',NULL,'typedlinkfield\\fields\\LinkField','{\"allowCustomText\":\"1\",\"allowedLinkNames\":{\"3\":\"entry\"},\"allowTarget\":\"\",\"autoNoReferrer\":\"\",\"defaultLinkName\":\"asset\",\"defaultText\":\"\",\"enableAriaLabel\":\"\",\"enableTitle\":\"\",\"typeSettings\":{\"asset\":{\"sources\":\"*\",\"allowCustomQuery\":\"\"},\"category\":{\"sources\":\"*\",\"allowCustomQuery\":\"\"},\"entry\":{\"sources\":\"*\",\"allowCustomQuery\":\"\"},\"site\":{\"sites\":\"*\"},\"user\":{\"sources\":\"*\",\"allowCustomQuery\":\"\"},\"custom\":{\"disableValidation\":\"\",\"allowAliases\":\"\"},\"email\":{\"disableValidation\":\"\",\"allowAliases\":\"\"},\"tel\":{\"disableValidation\":\"\",\"allowAliases\":\"\"},\"url\":{\"disableValidation\":\"\",\"allowAliases\":\"\"}}}','2019-02-05 17:46:57','2019-02-05 17:46:57','e50f5c06-23e7-4dc4-ab5c-558ccff08916'),(64,10,'Logo','logo','global','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2019-02-05 19:24:47','2019-02-05 19:24:47','940b5b29-ca1b-42b0-af88-c54030041237');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `globalsets` VALUES (3,'Business Info','businessInfo',13,'2019-02-05 16:45:11','2019-02-05 16:45:11','e43560e9-d586-47b3-802f-f011a542bba2'),(16,'Sociale Media','socialMedia',16,'2019-02-05 17:32:52','2019-02-05 17:33:35','a598fd75-f99c-463b-ad1c-42d530061e4b'),(34,'Branding','branding',19,'2019-02-05 19:26:02','2019-02-05 19:26:02','4ab168f2-9811-4f21-a536-79f9bb8e8f3b');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'3.1.8','3.1.23',0,'a:14:{s:11:\"fieldGroups\";a:11:{s:36:\"2e6fd2d5-770c-4818-bae7-4e41941c504e\";a:1:{s:4:\"name\";s:6:\"Common\";}s:36:\"09993af6-8ddd-4fb2-8e61-9d49d82cd67c\";a:1:{s:4:\"name\";s:7:\"Globals\";}s:36:\"477ff96a-78f7-4479-8bc7-3eb4266a590a\";a:1:{s:4:\"name\";s:10:\"Categories\";}s:36:\"f999caae-8823-4fd5-b7ec-2855c3d5611c\";a:1:{s:4:\"name\";s:15:\"Content Builder\";}s:36:\"4020c82b-7e58-4463-8ce5-06c8e7b59cf2\";a:1:{s:4:\"name\";s:6:\"Teaser\";}s:36:\"7977128d-bd10-4e46-8871-96f94c3d06f2\";a:1:{s:4:\"name\";s:8:\"Sections\";}s:36:\"7ab27bc0-119a-486c-8f9c-8a671b07c7c1\";a:1:{s:4:\"name\";s:6:\"Header\";}s:36:\"b957a8d9-396d-41e3-9942-0cc56c0e2ff6\";a:1:{s:4:\"name\";s:6:\"Videos\";}s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";a:1:{s:4:\"name\";s:6:\"Images\";}s:36:\"4839f379-a3a0-42ad-aa9c-4667bfa66987\";a:1:{s:4:\"name\";s:9:\"Relations\";}s:36:\"05a89714-c405-4857-bb9e-8923651a7d37\";a:1:{s:4:\"name\";s:12:\"Social Media\";}}s:10:\"siteGroups\";a:1:{s:36:\"5bbd509f-fb1f-4adc-af04-5d7ba96cd4d8\";a:1:{s:4:\"name\";s:6:\"CareTo\";}}s:5:\"sites\";a:1:{s:36:\"1503eb24-9970-44bf-87f1-55f1b103e228\";a:8:{s:7:\"baseUrl\";s:17:\"$DEFAULT_SITE_URL\";s:6:\"handle\";s:7:\"default\";s:7:\"hasUrls\";b:1;s:8:\"language\";s:5:\"en-US\";s:4:\"name\";s:6:\"CareTo\";s:7:\"primary\";b:1;s:9:\"siteGroup\";s:36:\"5bbd509f-fb1f-4adc-af04-5d7ba96cd4d8\";s:9:\"sortOrder\";i:1;}}s:5:\"email\";a:3:{s:9:\"fromEmail\";s:25:\"development@dadamotion.be\";s:8:\"fromName\";s:6:\"CareTo\";s:13:\"transportType\";s:37:\"craft\\mail\\transportadapters\\Sendmail\";}s:6:\"system\";a:5:{s:7:\"edition\";s:4:\"solo\";s:4:\"name\";s:6:\"CareTo\";s:4:\"live\";b:1;s:13:\"schemaVersion\";s:6:\"3.1.23\";s:8:\"timeZone\";s:19:\"America/Los_Angeles\";}s:5:\"users\";a:5:{s:24:\"requireEmailVerification\";b:1;s:23:\"allowPublicRegistration\";b:0;s:12:\"defaultGroup\";N;s:14:\"photoVolumeUid\";N;s:12:\"photoSubpath\";s:0:\"\";}s:12:\"dateModified\";i:1549397374;s:7:\"plugins\";a:20:{s:13:\"sprout-fields\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"3.2.0\";}s:9:\"architect\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"2.0.0\";}s:11:\"async-queue\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:15:\"colour-swatches\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:12:\"contact-form\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:23:\"contact-form-extensions\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:12:\"eager-beaver\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:16:\"expanded-singles\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:14:\"image-optimize\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:3:\"mix\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:15:\"password-policy\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:6:\"minify\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:18:\"position-fieldtype\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:8:\"redactor\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"2.2.1\";}s:8:\"seomatic\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"3.0.6\";}s:13:\"section-field\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"0.0.1\";}s:14:\"typedlinkfield\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:9:\"typogrify\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:11:\"super-table\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"2.0.8\";}s:15:\"width-fieldtype\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}}s:8:\"sections\";a:4:{s:36:\"281d49cb-e385-451c-938b-cb4641235de8\";a:7:{s:4:\"name\";s:4:\"Blog\";s:6:\"handle\";s:4:\"blog\";s:4:\"type\";s:7:\"channel\";s:16:\"enableVersioning\";b:1;s:16:\"propagateEntries\";b:1;s:12:\"siteSettings\";a:1:{s:36:\"1503eb24-9970-44bf-87f1-55f1b103e228\";a:4:{s:16:\"enabledByDefault\";b:1;s:7:\"hasUrls\";b:1;s:9:\"uriFormat\";s:11:\"blog/{slug}\";s:8:\"template\";s:11:\"blog/_entry\";}}s:10:\"entryTypes\";a:1:{s:36:\"5a7034e8-3859-440e-a10c-81bef694075a\";a:7:{s:4:\"name\";s:4:\"Blog\";s:6:\"handle\";s:4:\"blog\";s:13:\"hasTitleField\";b:1;s:10:\"titleLabel\";s:5:\"Title\";s:11:\"titleFormat\";N;s:9:\"sortOrder\";i:1;s:12:\"fieldLayouts\";a:1:{s:36:\"75897d66-503a-4380-ab29-8f0241f14017\";a:1:{s:4:\"tabs\";a:4:{i:0;a:3:{s:4:\"name\";s:6:\"Teaser\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"86575e5c-a873-4eae-bf9d-eff1d887972a\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"23f65acb-01ee-4654-92ac-9aeff81ed483\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}i:1;a:3:{s:4:\"name\";s:9:\"Structure\";s:9:\"sortOrder\";i:2;s:6:\"fields\";a:2:{s:36:\"f243311c-5768-49be-b903-2917c7f18dcf\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"2cd97d0b-a0ee-4b22-be14-929ff9d32856\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}i:2;a:3:{s:4:\"name\";s:7:\"Visuals\";s:9:\"sortOrder\";i:3;s:6:\"fields\";a:2:{s:36:\"cc6d3e25-f923-402b-9473-d601c49caaed\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"440ee632-f669-46f9-b5f4-343a65f1ca73\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}i:3;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:4;s:6:\"fields\";a:1:{s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}}}s:36:\"3d17d5f1-283c-4ec6-86a2-0eb706954987\";a:7:{s:4:\"name\";s:8:\"Homepage\";s:6:\"handle\";s:4:\"home\";s:4:\"type\";s:6:\"single\";s:16:\"enableVersioning\";b:1;s:16:\"propagateEntries\";b:1;s:12:\"siteSettings\";a:1:{s:36:\"1503eb24-9970-44bf-87f1-55f1b103e228\";a:4:{s:16:\"enabledByDefault\";b:1;s:7:\"hasUrls\";b:1;s:9:\"uriFormat\";s:8:\"__home__\";s:8:\"template\";s:5:\"index\";}}s:10:\"entryTypes\";a:1:{s:36:\"f4bef959-cbd7-4bb7-a9ae-c4c63f73446f\";a:7:{s:4:\"name\";s:8:\"Homepage\";s:6:\"handle\";s:4:\"home\";s:13:\"hasTitleField\";b:0;s:10:\"titleLabel\";s:0:\"\";s:11:\"titleFormat\";s:18:\"{section.name|raw}\";s:9:\"sortOrder\";i:1;s:12:\"fieldLayouts\";a:1:{s:36:\"964d8728-7d0c-46ac-b0fc-6993821ab196\";a:1:{s:4:\"tabs\";a:2:{i:0;a:3:{s:4:\"name\";s:11:\"Pagina Info\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"a41e8897-67b2-407d-8cb4-c110296c9638\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"47ab7e60-eef3-491c-8c6d-e019842f5d45\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}i:1;a:3:{s:4:\"name\";s:27:\"Content ( Visuele Builder )\";s:9:\"sortOrder\";i:2;s:6:\"fields\";a:1:{s:36:\"8c2ffb37-a84f-4e8e-acd1-918bf2411ade\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}}}s:36:\"f0c4afcd-2924-4918-991b-d4a4bc327d11\";a:8:{s:4:\"name\";s:9:\"Pagina\'s \";s:6:\"handle\";s:12:\"contentPages\";s:4:\"type\";s:9:\"structure\";s:16:\"enableVersioning\";b:1;s:16:\"propagateEntries\";b:1;s:12:\"siteSettings\";a:1:{s:36:\"1503eb24-9970-44bf-87f1-55f1b103e228\";a:4:{s:16:\"enabledByDefault\";b:1;s:7:\"hasUrls\";b:1;s:9:\"uriFormat\";s:33:\"{parent.uri ?? parent.uri}/{slug}\";s:8:\"template\";s:14:\"content/_entry\";}}s:9:\"structure\";a:2:{s:3:\"uid\";s:36:\"b0b07e93-d6ca-42cb-994d-f0360f175d01\";s:9:\"maxLevels\";s:1:\"2\";}s:10:\"entryTypes\";a:2:{s:36:\"32f6ba84-8af3-4465-8a43-cf96770ad7d2\";a:7:{s:4:\"name\";s:17:\"Visuele Pagina\'s \";s:6:\"handle\";s:11:\"visualPages\";s:13:\"hasTitleField\";b:1;s:10:\"titleLabel\";s:5:\"Title\";s:11:\"titleFormat\";s:0:\"\";s:9:\"sortOrder\";i:1;s:12:\"fieldLayouts\";a:1:{s:36:\"00939823-5d73-47a6-8f3b-98d9fc8c1806\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:15:\"Visuele Builder\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"8c2ffb37-a84f-4e8e-acd1-918bf2411ade\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}s:36:\"a6c4307b-1614-425c-8164-e2c892f1afa5\";a:7:{s:4:\"name\";s:18:\"Textuele Pagina\'s \";s:6:\"handle\";s:12:\"textualPages\";s:13:\"hasTitleField\";b:1;s:10:\"titleLabel\";s:5:\"Title\";s:11:\"titleFormat\";s:0:\"\";s:9:\"sortOrder\";i:2;s:12:\"fieldLayouts\";a:1:{s:36:\"94753381-46d0-484e-bed4-42537996cfef\";a:1:{s:4:\"tabs\";a:2:{i:0;a:3:{s:4:\"name\";s:11:\"Pagina Info\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:3:{s:36:\"cc6d3e25-f923-402b-9473-d601c49caaed\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"a41e8897-67b2-407d-8cb4-c110296c9638\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}s:36:\"47ab7e60-eef3-491c-8c6d-e019842f5d45\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:3;}}}i:1;a:3:{s:4:\"name\";s:15:\"Content Builder\";s:9:\"sortOrder\";i:2;s:6:\"fields\";a:1:{s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}}}s:36:\"b59151a4-05d6-4aaa-b351-459eb5916cd6\";a:7:{s:4:\"name\";s:7:\"Contact\";s:6:\"handle\";s:7:\"contact\";s:4:\"type\";s:6:\"single\";s:16:\"enableVersioning\";b:1;s:16:\"propagateEntries\";b:1;s:12:\"siteSettings\";a:1:{s:36:\"1503eb24-9970-44bf-87f1-55f1b103e228\";a:4:{s:16:\"enabledByDefault\";b:1;s:7:\"hasUrls\";b:1;s:9:\"uriFormat\";s:7:\"contact\";s:8:\"template\";s:13:\"contact/index\";}}s:10:\"entryTypes\";a:1:{s:36:\"0ba792ca-b17b-4790-905a-574666808176\";a:7:{s:4:\"name\";s:7:\"Contact\";s:6:\"handle\";s:7:\"contact\";s:13:\"hasTitleField\";b:0;s:10:\"titleLabel\";N;s:11:\"titleFormat\";s:18:\"{section.name|raw}\";s:9:\"sortOrder\";i:1;s:12:\"fieldLayouts\";a:1:{s:36:\"8af52315-de4f-4bff-ab0d-61151b0fbcf0\";a:1:{s:4:\"tabs\";a:3:{i:0;a:3:{s:4:\"name\";s:6:\"Header\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"a41e8897-67b2-407d-8cb4-c110296c9638\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"47ab7e60-eef3-491c-8c6d-e019842f5d45\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}i:1;a:3:{s:4:\"name\";s:7:\"Visuals\";s:9:\"sortOrder\";i:2;s:6:\"fields\";a:2:{s:36:\"cc6d3e25-f923-402b-9473-d601c49caaed\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"440ee632-f669-46f9-b5f4-343a65f1ca73\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}i:2;a:3:{s:4:\"name\";s:4:\"Page\";s:9:\"sortOrder\";i:3;s:6:\"fields\";a:2:{s:36:\"755a19d6-c648-4956-b27a-6aebdded76f4\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"6cd11a34-7bf1-4568-8fd8-d94489f16a59\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}}}}}}}}s:7:\"volumes\";a:5:{s:36:\"a191c99d-cf7a-4919-a0e9-82fd99da791c\";a:8:{s:4:\"name\";s:6:\"Images\";s:6:\"handle\";s:6:\"images\";s:4:\"type\";s:19:\"craft\\volumes\\Local\";s:7:\"hasUrls\";s:1:\"1\";s:3:\"url\";s:35:\"@baseUrl/assets/img/uploads/general\";s:8:\"settings\";a:1:{s:4:\"path\";s:36:\"@basePath/assets/img/uploads/general\";}s:9:\"sortOrder\";N;s:12:\"fieldLayouts\";a:1:{s:36:\"0f242cf9-1f95-4340-8746-e53857043973\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"2eac8f76-372f-48c2-89e7-8188e33848b8\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}s:36:\"7abe41af-4979-4ac8-be5e-8c0c85a91dd3\";a:7:{s:4:\"name\";s:6:\"Videos\";s:6:\"handle\";s:6:\"videos\";s:4:\"type\";s:19:\"craft\\volumes\\Local\";s:7:\"hasUrls\";b:1;s:3:\"url\";s:30:\"@baseUrl/assets/uploads/videos\";s:8:\"settings\";a:1:{s:4:\"path\";s:31:\"@basePath/assets/uploads/videos\";}s:9:\"sortOrder\";N;}s:36:\"3ae495a2-3065-4cbf-a837-37ac98b1267f\";a:8:{s:4:\"name\";s:11:\"Hero Images\";s:6:\"handle\";s:10:\"heroImages\";s:4:\"type\";s:19:\"craft\\volumes\\Local\";s:7:\"hasUrls\";s:1:\"1\";s:3:\"url\";s:32:\"@baseUrl/assets/img/uploads/hero\";s:8:\"settings\";a:1:{s:4:\"path\";s:33:\"@basePath/assets/img/uploads/hero\";}s:9:\"sortOrder\";N;s:12:\"fieldLayouts\";a:1:{s:36:\"951fb3e3-710f-4fb0-88ac-136917e57afe\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"16fc9373-e312-433c-8f17-84e2fcdb110e\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}s:36:\"912b07d6-4f72-4970-9809-cc4258aeade8\";a:8:{s:4:\"name\";s:15:\"Overview images\";s:6:\"handle\";s:14:\"overviewImages\";s:4:\"type\";s:19:\"craft\\volumes\\Local\";s:7:\"hasUrls\";s:1:\"1\";s:3:\"url\";s:34:\"@baseUrl/assets/img/uploads/teaser\";s:8:\"settings\";a:1:{s:4:\"path\";s:35:\"@basePath/assets/img/uploads/teaser\";}s:9:\"sortOrder\";N;s:12:\"fieldLayouts\";a:1:{s:36:\"5995dbde-5175-48bb-8a70-70da51566196\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"3f586fec-d777-4257-9c2b-ab4f923aec40\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}s:36:\"a5808c2c-206f-4161-af1b-06cf7d9a0e13\";a:7:{s:4:\"name\";s:9:\"Full Page\";s:6:\"handle\";s:8:\"fullPage\";s:4:\"type\";s:19:\"craft\\volumes\\Local\";s:7:\"hasUrls\";b:1;s:3:\"url\";s:32:\"@baseUrl/assets/img/uploads/full\";s:8:\"settings\";a:1:{s:4:\"path\";s:33:\"@basePath/assets/img/uploads/full\";}s:9:\"sortOrder\";i:1;}}s:14:\"categoryGroups\";a:1:{s:36:\"0e2ea179-556a-4404-ad6b-d2a673b23e8e\";a:4:{s:4:\"name\";s:4:\"Blog\";s:6:\"handle\";s:4:\"blog\";s:9:\"structure\";a:2:{s:3:\"uid\";s:36:\"24331ae6-0850-40a6-a251-a2d6c36d5230\";s:9:\"maxLevels\";i:1;}s:12:\"siteSettings\";a:1:{s:36:\"1503eb24-9970-44bf-87f1-55f1b103e228\";a:3:{s:7:\"hasUrls\";i:1;s:9:\"uriFormat\";s:11:\"blog/{slug}\";s:8:\"template\";s:14:\"blog/_category\";}}}}s:6:\"fields\";a:31:{s:36:\"9479e2aa-aa84-4b85-bedf-ae3f0acc9133\";a:10:{s:4:\"name\";s:7:\"Address\";s:6:\"handle\";s:7:\"address\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:42:\"barrelstrength\\sproutfields\\fields\\Address\";s:8:\"settings\";a:7:{s:5:\"value\";N;s:13:\"addressHelper\";O:58:\"barrelstrength\\sproutbase\\app\\fields\\helpers\\AddressHelper\":8:{s:26:\"\0*\0addressFormatRepository\";N;s:24:\"\0*\0subdivisionRepository\";N;s:12:\"\0*\0namespace\";s:7:\"address\";s:15:\"\0*\0addressModel\";N;s:14:\"\0*\0countryCode\";N;s:11:\"\0*\0language\";s:2:\"en\";s:21:\"\0*\0highlightCountries\";a:0:{}s:80:\"\0barrelstrength\\sproutbase\\app\\fields\\helpers\\AddressHelper\0baseAddressFieldPath\";s:49:\"sprout-base-fields/_components/fields/formfields/\";}s:15:\"defaultLanguage\";N;s:14:\"defaultCountry\";s:2:\"BE\";s:19:\"showCountryDropdown\";b:1;s:19:\"hideCountryDropdown\";s:1:\"1\";s:18:\"highlightCountries\";a:0:{}}s:17:\"contentColumnType\";s:7:\"integer\";s:10:\"fieldGroup\";s:36:\"09993af6-8ddd-4fb2-8e61-9d49d82cd67c\";}s:36:\"f243311c-5768-49be-b903-2917c7f18dcf\";a:10:{s:4:\"name\";s:15:\"Blog categories\";s:6:\"handle\";s:14:\"blogCategories\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:23:\"craft\\fields\\Categories\";s:8:\"settings\";a:8:{s:11:\"branchLimit\";s:1:\"3\";s:7:\"sources\";s:1:\"*\";s:6:\"source\";s:42:\"group:0e2ea179-556a-4404-ad6b-d2a673b23e8e\";s:12:\"targetSiteId\";N;s:8:\"viewMode\";N;s:5:\"limit\";N;s:14:\"selectionLabel\";s:33:\"Choose blog categories ( max. 3 )\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"477ff96a-78f7-4479-8bc7-3eb4266a590a\";}s:36:\"6d478d4f-9299-4ee7-9a56-6a43774f3007\";a:10:{s:4:\"name\";s:13:\"Business name\";s:6:\"handle\";s:12:\"businessName\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"09993af6-8ddd-4fb2-8e61-9d49d82cd67c\";}s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";a:10:{s:4:\"name\";s:15:\"Content Builder\";s:6:\"handle\";s:14:\"contentBuilder\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Matrix\";s:8:\"settings\";a:4:{s:9:\"minBlocks\";s:0:\"\";s:9:\"maxBlocks\";s:0:\"\";s:12:\"contentTable\";s:33:\"{{%matrixcontent_contentbuilder}}\";s:14:\"localizeBlocks\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"f999caae-8823-4fd5-b7ec-2855c3d5611c\";}s:36:\"23f65acb-01ee-4654-92ac-9aeff81ed483\";a:10:{s:4:\"name\";s:11:\"Description\";s:6:\"handle\";s:17:\"teaserDescription\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:1:\"1\";s:11:\"initialRows\";s:1:\"3\";s:9:\"charLimit\";s:3:\"250\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"4020c82b-7e58-4463-8ce5-06c8e7b59cf2\";}s:36:\"6cd11a34-7bf1-4568-8fd8-d94489f16a59\";a:10:{s:4:\"name\";s:11:\"Description\";s:6:\"handle\";s:18:\"sectionDescription\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:20:\"craft\\redactor\\Field\";s:8:\"settings\";a:7:{s:14:\"redactorConfig\";s:11:\"Simple.json\";s:14:\"purifierConfig\";s:0:\"\";s:11:\"cleanupHtml\";s:1:\"1\";s:10:\"purifyHtml\";s:1:\"1\";s:10:\"columnType\";s:4:\"text\";s:16:\"availableVolumes\";s:0:\"\";s:19:\"availableTransforms\";s:1:\"*\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"7977128d-bd10-4e46-8871-96f94c3d06f2\";}s:36:\"287e08eb-254e-4334-a7d1-78acaa94a267\";a:10:{s:4:\"name\";s:13:\"Email Address\";s:6:\"handle\";s:5:\"email\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:40:\"barrelstrength\\sproutfields\\fields\\Email\";s:8:\"settings\";a:5:{s:13:\"customPattern\";s:17:\"(.*)@pixville.be$\";s:19:\"customPatternToggle\";s:1:\"1\";s:25:\"customPatternErrorMessage\";s:0:\"\";s:11:\"uniqueEmail\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"09993af6-8ddd-4fb2-8e61-9d49d82cd67c\";}s:36:\"cc6d3e25-f923-402b-9473-d601c49caaed\";a:10:{s:4:\"name\";s:10:\"Hero Image\";s:6:\"handle\";s:9:\"heroImage\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:3ae495a2-3065-4cbf-a837-37ac98b1267f\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"image\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:41:\"Add or upload hero image ( header photo )\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"7ab27bc0-119a-486c-8f9c-8a671b07c7c1\";}s:36:\"440ee632-f669-46f9-b5f4-343a65f1ca73\";a:10:{s:4:\"name\";s:10:\"Hero video\";s:6:\"handle\";s:9:\"heroVideo\";s:12:\"instructions\";s:113:\"Upload your video in mp4 format, make sure the video doesn\'t exceed 10 seconds in length, the shorter the better.\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:7abe41af-4979-4ac8-be5e-8c0c85a91dd3\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"video\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:26:\"Add or upload header video\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"b957a8d9-396d-41e3-9942-0cc56c0e2ff6\";}s:36:\"03ef46d1-ef2a-466d-bd98-3fa159f4f942\";a:10:{s:4:\"name\";s:4:\"Name\";s:6:\"handle\";s:11:\"sectionName\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"7977128d-bd10-4e46-8871-96f94c3d06f2\";}s:36:\"16fc9373-e312-433c-8f17-84e2fcdb110e\";a:10:{s:4:\"name\";s:21:\"Optimized Hero Images\";s:6:\"handle\";s:13:\"optimizedHero\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:48:\"nystudio107\\imageoptimize\\fields\\OptimizedImages\";s:8:\"settings\";a:5:{s:17:\"ignoreFilesOfType\";a:0:{}s:29:\"displayOptimizedImageVariants\";s:1:\"1\";s:27:\"displayDominantColorPalette\";s:1:\"1\";s:32:\"displayLazyLoadPlaceholderImages\";s:1:\"1\";s:8:\"variants\";a:5:{i:0;a:7:{s:5:\"width\";s:4:\"1440\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:1;a:7:{s:5:\"width\";s:4:\"1200\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:2;a:7:{s:5:\"width\";s:4:\"1200\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:3;a:7:{s:5:\"width\";s:3:\"900\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}i:4;a:7:{s:5:\"width\";s:3:\"576\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"3\";s:12:\"aspectRatioY\";s:1:\"4\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"2eac8f76-372f-48c2-89e7-8188e33848b8\";a:10:{s:4:\"name\";s:16:\"Optimized Images\";s:6:\"handle\";s:15:\"optimizedImages\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:48:\"nystudio107\\imageoptimize\\fields\\OptimizedImages\";s:8:\"settings\";a:5:{s:17:\"ignoreFilesOfType\";a:0:{}s:29:\"displayOptimizedImageVariants\";s:1:\"1\";s:27:\"displayDominantColorPalette\";s:1:\"1\";s:32:\"displayLazyLoadPlaceholderImages\";s:1:\"1\";s:8:\"variants\";a:4:{i:0;a:7:{s:5:\"width\";s:4:\"1200\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:1;a:7:{s:5:\"width\";s:3:\"992\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:2;a:7:{s:5:\"width\";s:3:\"768\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"4\";s:12:\"aspectRatioY\";s:1:\"3\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}i:3;a:7:{s:5:\"width\";s:3:\"576\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"4\";s:12:\"aspectRatioY\";s:1:\"3\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"3f586fec-d777-4257-9c2b-ab4f923aec40\";a:10:{s:4:\"name\";s:25:\"Optimized Overview Images\";s:6:\"handle\";s:17:\"optimizedOverview\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:48:\"nystudio107\\imageoptimize\\fields\\OptimizedImages\";s:8:\"settings\";a:5:{s:17:\"ignoreFilesOfType\";a:0:{}s:29:\"displayOptimizedImageVariants\";s:1:\"1\";s:27:\"displayDominantColorPalette\";s:1:\"1\";s:32:\"displayLazyLoadPlaceholderImages\";s:1:\"1\";s:8:\"variants\";a:3:{i:0;a:7:{s:5:\"width\";s:3:\"800\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"5\";s:12:\"aspectRatioY\";s:1:\"4\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:1;a:7:{s:5:\"width\";s:3:\"500\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"5\";s:12:\"aspectRatioY\";s:1:\"4\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:2;a:7:{s:5:\"width\";s:3:\"400\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"5\";s:12:\"aspectRatioY\";s:1:\"4\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"02911763-8e8f-4856-830e-241d0ff09120\";a:10:{s:4:\"name\";s:18:\"Optimized Services\";s:6:\"handle\";s:17:\"optimizedServices\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:48:\"nystudio107\\imageoptimize\\fields\\OptimizedImages\";s:8:\"settings\";a:5:{s:17:\"ignoreFilesOfType\";a:0:{}s:29:\"displayOptimizedImageVariants\";s:1:\"1\";s:27:\"displayDominantColorPalette\";s:1:\"1\";s:32:\"displayLazyLoadPlaceholderImages\";s:1:\"1\";s:8:\"variants\";a:3:{i:0;a:7:{s:5:\"width\";s:4:\"1000\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"9\";s:12:\"aspectRatioY\";s:2:\"16\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:1;a:7:{s:5:\"width\";s:3:\"500\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"9\";s:12:\"aspectRatioY\";s:2:\"16\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:2;a:7:{s:5:\"width\";s:3:\"400\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"9\";s:12:\"aspectRatioY\";s:2:\"16\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"f815968b-156d-4974-ab8e-9e815c81e89c\";a:10:{s:4:\"name\";s:26:\"Optimized Video Thumbnails\";s:6:\"handle\";s:24:\"optimizedVideoThumbnails\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:48:\"nystudio107\\imageoptimize\\fields\\OptimizedImages\";s:8:\"settings\";a:5:{s:17:\"ignoreFilesOfType\";a:0:{}s:29:\"displayOptimizedImageVariants\";s:1:\"1\";s:27:\"displayDominantColorPalette\";s:1:\"1\";s:32:\"displayLazyLoadPlaceholderImages\";s:1:\"1\";s:8:\"variants\";a:4:{i:0;a:7:{s:5:\"width\";s:4:\"1200\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:1;a:7:{s:5:\"width\";s:3:\"992\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:2;a:7:{s:5:\"width\";s:3:\"768\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}i:3;a:7:{s:5:\"width\";s:3:\"576\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"86575e5c-a873-4eae-bf9d-eff1d887972a\";a:10:{s:4:\"name\";s:14:\"Overview Image\";s:6:\"handle\";s:11:\"teaserImage\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:912b07d6-4f72-4970-9809-cc4258aeade8\";s:27:\"singleUploadLocationSubpath\";s:6:\"{slug}\";s:13:\"restrictFiles\";s:0:\"\";s:12:\"allowedKinds\";N;s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"4020c82b-7e58-4463-8ce5-06c8e7b59cf2\";}s:36:\"a41e8897-67b2-407d-8cb4-c110296c9638\";a:10:{s:4:\"name\";s:9:\"Page Name\";s:6:\"handle\";s:8:\"pageName\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:2:\"24\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"7ab27bc0-119a-486c-8f9c-8a671b07c7c1\";}s:36:\"47ab7e60-eef3-491c-8c6d-e019842f5d45\";a:10:{s:4:\"name\";s:10:\"Page Title\";s:6:\"handle\";s:9:\"pageTitle\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"7ab27bc0-119a-486c-8f9c-8a671b07c7c1\";}s:36:\"45784098-995c-40a8-a7d3-7faad1234bd7\";a:10:{s:4:\"name\";s:12:\"Phone Number\";s:6:\"handle\";s:5:\"phone\";s:12:\"instructions\";s:44:\"Enter the main phone number of your business\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:40:\"barrelstrength\\sproutfields\\fields\\Phone\";s:8:\"settings\";a:7:{s:25:\"customPatternErrorMessage\";s:0:\"\";s:20:\"limitToSingleCountry\";s:1:\"1\";s:7:\"country\";s:2:\"BE\";s:11:\"placeholder\";s:0:\"\";s:19:\"customPatternToggle\";N;s:4:\"mask\";N;s:9:\"inputMask\";N;}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"09993af6-8ddd-4fb2-8e61-9d49d82cd67c\";}s:36:\"2cd97d0b-a0ee-4b22-be14-929ff9d32856\";a:10:{s:4:\"name\";s:18:\"Related Blog Posts\";s:6:\"handle\";s:16:\"relatedBlogPosts\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:20:\"craft\\fields\\Entries\";s:8:\"settings\";a:7:{s:7:\"sources\";a:1:{i:0;s:44:\"section:281d49cb-e385-451c-938b-cb4641235de8\";}s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";N;s:5:\"limit\";s:1:\"3\";s:14:\"selectionLabel\";s:38:\"Select related blog entries ( max. 3 )\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"4839f379-a3a0-42ad-aa9c-4667bfa66987\";}s:36:\"bda5366d-ab6c-46b9-9f6b-6f9701494660\";a:10:{s:4:\"name\";s:16:\"Related Projects\";s:6:\"handle\";s:15:\"relatedProjects\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:20:\"craft\\fields\\Entries\";s:8:\"settings\";a:7:{s:7:\"sources\";a:1:{i:0;s:8:\"projects\";}s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";N;s:5:\"limit\";s:1:\"4\";s:14:\"selectionLabel\";s:34:\"Select related projects ( max. 4 )\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"4839f379-a3a0-42ad-aa9c-4667bfa66987\";}s:36:\"fbbd601d-984b-4722-9f1f-537a6b1aa053\";a:10:{s:4:\"name\";s:22:\"Service overview image\";s:6:\"handle\";s:12:\"serviceImage\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:52dc81e2-fba5-448f-8827-2cde4e2ef7a3\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"image\";}s:7:\"sources\";a:1:{i:0;s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";}s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"e7a66dc1-8fb5-4c11-9395-098086f00bba\";a:10:{s:4:\"name\";s:20:\"Social Media Builder\";s:6:\"handle\";s:13:\"socialBuilder\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Matrix\";s:8:\"settings\";a:4:{s:9:\"minBlocks\";s:0:\"\";s:9:\"maxBlocks\";s:0:\"\";s:12:\"contentTable\";s:32:\"{{%matrixcontent_socialbuilder}}\";s:14:\"localizeBlocks\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"05a89714-c405-4857-bb9e-8923651a7d37\";}s:36:\"755a19d6-c648-4956-b27a-6aebdded76f4\";a:10:{s:4:\"name\";s:5:\"Title\";s:6:\"handle\";s:12:\"sectionTitle\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"7977128d-bd10-4e46-8871-96f94c3d06f2\";}s:36:\"3089bf8f-02a6-4cba-8199-7b5160afae2f\";a:10:{s:4:\"name\";s:12:\"Video Source\";s:6:\"handle\";s:11:\"videoSource\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:21:\"craft\\fields\\Dropdown\";s:8:\"settings\";a:1:{s:7:\"options\";a:2:{i:0;a:3:{s:5:\"label\";s:5:\"Vimeo\";s:5:\"value\";s:5:\"vimeo\";s:7:\"default\";s:1:\"1\";}i:1;a:3:{s:5:\"label\";s:7:\"Youtube\";s:5:\"value\";s:7:\"youtube\";s:7:\"default\";s:0:\"\";}}}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"b957a8d9-396d-41e3-9942-0cc56c0e2ff6\";}s:36:\"bcbb8fb0-15cc-4b09-8b1c-50618185abe0\";a:10:{s:4:\"name\";s:15:\"Video Thumbnail\";s:6:\"handle\";s:14:\"videoThumbnail\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:c94ebff4-b2ef-483a-aa76-81aea5d608ac\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"image\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"b957a8d9-396d-41e3-9942-0cc56c0e2ff6\";}s:36:\"f4c2ee5a-dd69-44ea-b0ef-2fb46c831660\";a:10:{s:4:\"name\";s:9:\"Video Url\";s:6:\"handle\";s:8:\"videoUrl\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"b957a8d9-396d-41e3-9942-0cc56c0e2ff6\";}s:36:\"8c2ffb37-a84f-4e8e-acd1-918bf2411ade\";a:10:{s:4:\"name\";s:14:\"Visual Builder\";s:6:\"handle\";s:13:\"visualBuilder\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Matrix\";s:8:\"settings\";a:4:{s:9:\"minBlocks\";s:0:\"\";s:9:\"maxBlocks\";s:0:\"\";s:12:\"contentTable\";s:32:\"{{%matrixcontent_visualbuilder}}\";s:14:\"localizeBlocks\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"f999caae-8823-4fd5-b7ec-2855c3d5611c\";}s:36:\"1ecb7ca2-2f4b-4be1-9831-d401ed900d94\";a:10:{s:4:\"name\";s:12:\"Social Media\";s:6:\"handle\";s:11:\"socialMedia\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Matrix\";s:8:\"settings\";a:4:{s:9:\"minBlocks\";s:0:\"\";s:9:\"maxBlocks\";s:0:\"\";s:12:\"contentTable\";s:30:\"{{%matrixcontent_socialmedia}}\";s:14:\"localizeBlocks\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"f999caae-8823-4fd5-b7ec-2855c3d5611c\";}s:36:\"1508fefe-d2bb-4af7-9d80-0f13b444edbe\";a:10:{s:4:\"name\";s:19:\"Optimized Full Page\";s:6:\"handle\";s:17:\"optimizedFullPage\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:48:\"nystudio107\\imageoptimize\\fields\\OptimizedImages\";s:8:\"settings\";a:5:{s:17:\"ignoreFilesOfType\";a:2:{i:0;s:9:\"image/svg\";i:1;s:9:\"image/gif\";}s:29:\"displayOptimizedImageVariants\";s:1:\"1\";s:27:\"displayDominantColorPalette\";s:1:\"1\";s:32:\"displayLazyLoadPlaceholderImages\";s:1:\"1\";s:8:\"variants\";a:4:{i:0;a:7:{s:5:\"width\";s:4:\"1920\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:1;a:7:{s:5:\"width\";s:4:\"1024\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:2:\"16\";s:12:\"aspectRatioY\";s:1:\"9\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"82\";s:6:\"format\";s:3:\"jpg\";}i:2;a:7:{s:5:\"width\";s:3:\"768\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"9\";s:12:\"aspectRatioY\";s:2:\"16\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}i:3;a:7:{s:5:\"width\";s:3:\"576\";s:14:\"useAspectRatio\";s:1:\"1\";s:12:\"aspectRatioX\";s:1:\"9\";s:12:\"aspectRatioY\";s:2:\"16\";s:11:\"retinaSizes\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:7:\"quality\";s:2:\"60\";s:6:\"format\";s:3:\"jpg\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}s:36:\"940b5b29-ca1b-42b0-af88-c54030041237\";a:10:{s:4:\"name\";s:4:\"Logo\";s:6:\"handle\";s:4:\"logo\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"image\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";s:36:\"2faa2c63-b4fd-4bca-a79a-da9a6f06b109\";}}s:16:\"matrixBlockTypes\";a:7:{s:36:\"26001dc6-a1b6-43af-8542-d488f87d3e94\";a:6:{s:5:\"field\";s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";s:4:\"name\";s:7:\"Heading\";s:6:\"handle\";s:7:\"heading\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"2f5fad2b-51f5-4fa8-afc8-4a3ecd124cf8\";a:10:{s:4:\"name\";s:7:\"Heading\";s:6:\"handle\";s:7:\"heading\";s:12:\"instructions\";s:28:\"Add main heading text ( h2 )\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"7e9c82b0-083a-4b9e-bc9c-31662a8f3628\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"2f5fad2b-51f5-4fa8-afc8-4a3ecd124cf8\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:1;}}}}}}}s:36:\"da843291-6248-409e-a948-94ea290bf850\";a:6:{s:5:\"field\";s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";s:4:\"name\";s:4:\"Text\";s:6:\"handle\";s:4:\"text\";s:9:\"sortOrder\";i:2;s:6:\"fields\";a:5:{s:36:\"3e982c8d-bcfa-48a8-b921-ad35611bcfec\";a:10:{s:4:\"name\";s:11:\"Lead Text ?\";s:6:\"handle\";s:8:\"leadText\";s:12:\"instructions\";s:123:\"Select this option if the text is a lead text. Warning ! Position and Width have no influence when this option is selected!\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:24:\"craft\\fields\\Lightswitch\";s:8:\"settings\";a:1:{s:7:\"default\";s:0:\"\";}s:17:\"contentColumnType\";s:7:\"boolean\";s:10:\"fieldGroup\";N;}s:36:\"9ee8e929-d66e-4446-80f0-265283b4dec4\";a:10:{s:4:\"name\";s:7:\"Heading\";s:6:\"handle\";s:7:\"heading\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"c3e7b85b-d2ec-430e-a959-e36a853be3d4\";a:10:{s:4:\"name\";s:4:\"Body\";s:6:\"handle\";s:4:\"body\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:20:\"craft\\redactor\\Field\";s:8:\"settings\";a:7:{s:14:\"redactorConfig\";s:13:\"Standard.json\";s:14:\"purifierConfig\";s:0:\"\";s:11:\"cleanupHtml\";s:1:\"1\";s:10:\"purifyHtml\";s:1:\"1\";s:10:\"columnType\";s:4:\"text\";s:16:\"availableVolumes\";s:1:\"*\";s:19:\"availableTransforms\";s:1:\"*\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"83eb216a-4f98-4935-8ed1-5946f93b5ed6\";a:10:{s:4:\"name\";s:5:\"Width\";s:6:\"handle\";s:5:\"width\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:32:\"rias\\widthfieldtype\\fields\\Width\";s:8:\"settings\";a:2:{s:7:\"options\";a:12:{s:3:\"1/6\";s:0:\"\";s:3:\"1/5\";s:0:\"\";s:3:\"1/4\";s:0:\"\";s:3:\"1/3\";s:1:\"1\";s:3:\"2/5\";s:0:\"\";s:3:\"1/2\";s:1:\"1\";s:3:\"3/5\";s:0:\"\";s:3:\"2/3\";s:0:\"\";s:3:\"3/4\";s:0:\"\";s:3:\"4/5\";s:0:\"\";s:3:\"5/6\";s:0:\"\";s:4:\"full\";s:1:\"1\";}s:7:\"default\";s:4:\"full\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"c1e231a8-b866-44f4-8d0f-5491d9210ed3\";a:10:{s:4:\"name\";s:8:\"Position\";s:6:\"handle\";s:8:\"position\";s:12:\"instructions\";s:58:\"Choosing the postion only has an influence on half blocks!\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:38:\"rias\\positionfieldtype\\fields\\Position\";s:8:\"settings\";a:2:{s:7:\"options\";a:6:{s:4:\"left\";s:1:\"1\";s:6:\"center\";s:0:\"\";s:5:\"right\";s:1:\"1\";s:4:\"full\";s:1:\"1\";s:9:\"drop-left\";s:0:\"\";s:10:\"drop-right\";s:0:\"\";}s:7:\"default\";s:4:\"full\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"f6f94d9c-04ed-4d08-85c7-a9fc45f927a3\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:5:{s:36:\"3e982c8d-bcfa-48a8-b921-ad35611bcfec\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"9ee8e929-d66e-4446-80f0-265283b4dec4\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}s:36:\"c3e7b85b-d2ec-430e-a959-e36a853be3d4\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:3;}s:36:\"83eb216a-4f98-4935-8ed1-5946f93b5ed6\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:4;}s:36:\"c1e231a8-b866-44f4-8d0f-5491d9210ed3\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:5;}}}}}}}s:36:\"cb5bf083-a7d2-4696-91a9-7f90ac118ca0\";a:6:{s:5:\"field\";s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";s:4:\"name\";s:5:\"Image\";s:6:\"handle\";s:5:\"image\";s:9:\"sortOrder\";i:3;s:6:\"fields\";a:4:{s:36:\"a5da4306-09e4-4217-aa7b-35e7f40593e2\";a:10:{s:4:\"name\";s:5:\"Image\";s:6:\"handle\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:27:\"singleUploadLocationSubpath\";s:12:\"{owner.slug}\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"image\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"00f35c2a-1ee5-4c0d-9404-36b89ab48574\";a:10:{s:4:\"name\";s:7:\"Caption\";s:6:\"handle\";s:7:\"caption\";s:12:\"instructions\";s:68:\"The caption will only show if the image is displayed in full width !\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:3:\"100\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"2cb6eb30-3d11-4b9b-a0a4-1d54fbe3cd50\";a:10:{s:4:\"name\";s:5:\"Width\";s:6:\"handle\";s:5:\"width\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:32:\"rias\\widthfieldtype\\fields\\Width\";s:8:\"settings\";a:2:{s:7:\"options\";a:12:{s:3:\"1/6\";s:0:\"\";s:3:\"1/5\";s:0:\"\";s:3:\"1/4\";s:0:\"\";s:3:\"1/3\";s:0:\"\";s:3:\"2/5\";s:0:\"\";s:3:\"1/2\";s:1:\"1\";s:3:\"3/5\";s:0:\"\";s:3:\"2/3\";s:0:\"\";s:3:\"3/4\";s:0:\"\";s:3:\"4/5\";s:0:\"\";s:3:\"5/6\";s:0:\"\";s:4:\"full\";s:1:\"1\";}s:7:\"default\";s:4:\"full\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"3df57062-6ff3-4545-a06f-ec30ec62d071\";a:10:{s:4:\"name\";s:8:\"Position\";s:6:\"handle\";s:8:\"position\";s:12:\"instructions\";s:62:\"The position only influences images when they\'re half a block!\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:38:\"rias\\positionfieldtype\\fields\\Position\";s:8:\"settings\";a:2:{s:7:\"options\";a:6:{s:4:\"left\";s:1:\"1\";s:6:\"center\";s:0:\"\";s:5:\"right\";s:1:\"1\";s:4:\"full\";s:1:\"1\";s:9:\"drop-left\";s:0:\"\";s:10:\"drop-right\";s:0:\"\";}s:7:\"default\";s:4:\"full\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"6a06a9bd-0a76-421b-8125-41a4c9ead610\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:4:{s:36:\"a5da4306-09e4-4217-aa7b-35e7f40593e2\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:1;}s:36:\"00f35c2a-1ee5-4c0d-9404-36b89ab48574\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}s:36:\"2cb6eb30-3d11-4b9b-a0a4-1d54fbe3cd50\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:3;}s:36:\"3df57062-6ff3-4545-a06f-ec30ec62d071\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:4;}}}}}}}s:36:\"299bc55b-d15a-4949-97f2-eb0d2e563898\";a:6:{s:5:\"field\";s:36:\"7e29e417-2ff9-4158-aeb5-b789113c4d1f\";s:4:\"name\";s:5:\"Video\";s:6:\"handle\";s:5:\"video\";s:9:\"sortOrder\";i:4;s:6:\"fields\";a:6:{s:36:\"88313d6e-13d8-406c-8811-c15bc5b71f3b\";a:10:{s:4:\"name\";s:9:\"Video Url\";s:6:\"handle\";s:8:\"videoUrl\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"fddb769f-f4c8-407a-8cd1-6c05e2c9d0a2\";a:10:{s:4:\"name\";s:12:\"Video Source\";s:6:\"handle\";s:11:\"videoSource\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:21:\"craft\\fields\\Dropdown\";s:8:\"settings\";a:1:{s:7:\"options\";a:2:{i:0;a:3:{s:5:\"label\";s:5:\"Vimeo\";s:5:\"value\";s:5:\"vimeo\";s:7:\"default\";s:1:\"1\";}i:1;a:3:{s:5:\"label\";s:7:\"Youtube\";s:5:\"value\";s:7:\"youtube\";s:7:\"default\";s:0:\"\";}}}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"7af4a442-0d31-4637-8b25-64c12865b3b4\";a:10:{s:4:\"name\";s:15:\"Video Thumbnail\";s:6:\"handle\";s:14:\"videoThumbnail\";s:12:\"instructions\";s:42:\"Add a nice looking thumbnail for the video\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"image\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"cb58bfc5-5133-4998-ab6e-929d6d7939a0\";a:10:{s:4:\"name\";s:7:\"Caption\";s:6:\"handle\";s:7:\"caption\";s:12:\"instructions\";s:68:\"The caption will only show if the image is displayed in full width !\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"cf30ee49-954a-4715-b230-23975eea1ba6\";a:10:{s:4:\"name\";s:5:\"Width\";s:6:\"handle\";s:5:\"width\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:32:\"rias\\widthfieldtype\\fields\\Width\";s:8:\"settings\";a:2:{s:7:\"options\";a:12:{s:3:\"1/6\";s:0:\"\";s:3:\"1/5\";s:0:\"\";s:3:\"1/4\";s:0:\"\";s:3:\"1/3\";s:0:\"\";s:3:\"2/5\";s:0:\"\";s:3:\"1/2\";s:1:\"1\";s:3:\"3/5\";s:0:\"\";s:3:\"2/3\";s:0:\"\";s:3:\"3/4\";s:0:\"\";s:3:\"4/5\";s:0:\"\";s:3:\"5/6\";s:0:\"\";s:4:\"full\";s:1:\"1\";}s:7:\"default\";s:4:\"full\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"60bef741-f542-495d-a877-61ce244f6f05\";a:10:{s:4:\"name\";s:8:\"Position\";s:6:\"handle\";s:8:\"position\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:38:\"rias\\positionfieldtype\\fields\\Position\";s:8:\"settings\";a:2:{s:7:\"options\";a:6:{s:4:\"left\";s:1:\"1\";s:6:\"center\";s:0:\"\";s:5:\"right\";s:1:\"1\";s:4:\"full\";s:1:\"1\";s:9:\"drop-left\";s:0:\"\";s:10:\"drop-right\";s:0:\"\";}s:7:\"default\";s:4:\"full\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"54f6de39-1374-4dc7-9b59-826127f0ac58\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:6:{s:36:\"88313d6e-13d8-406c-8811-c15bc5b71f3b\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"fddb769f-f4c8-407a-8cd1-6c05e2c9d0a2\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:2;}s:36:\"7af4a442-0d31-4637-8b25-64c12865b3b4\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:3;}s:36:\"cb58bfc5-5133-4998-ab6e-929d6d7939a0\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:4;}s:36:\"cf30ee49-954a-4715-b230-23975eea1ba6\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:5;}s:36:\"60bef741-f542-495d-a877-61ce244f6f05\";a:2:{s:8:\"required\";b:1;s:9:\"sortOrder\";i:6;}}}}}}}s:36:\"09be61e5-e205-4f6f-bef4-94624de2b5ee\";a:6:{s:5:\"field\";s:36:\"e7a66dc1-8fb5-4c11-9395-098086f00bba\";s:4:\"name\";s:6:\"social\";s:6:\"handle\";s:6:\"social\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"824acb69-e348-4edc-87dd-1cbd481679e2\";a:10:{s:4:\"name\";s:17:\"Social Media Type\";s:6:\"handle\";s:10:\"socialType\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:21:\"craft\\fields\\Dropdown\";s:8:\"settings\";a:1:{s:7:\"options\";a:4:{i:0;a:3:{s:5:\"label\";s:5:\"Email\";s:5:\"value\";s:5:\"email\";s:7:\"default\";s:1:\"1\";}i:1;a:3:{s:5:\"label\";s:8:\"Facebook\";s:5:\"value\";s:8:\"facebook\";s:7:\"default\";s:0:\"\";}i:2;a:3:{s:5:\"label\";s:9:\"Instagram\";s:5:\"value\";s:9:\"instagram\";s:7:\"default\";s:0:\"\";}i:3;a:3:{s:5:\"label\";s:8:\"LinkedIn\";s:5:\"value\";s:8:\"linkedin\";s:7:\"default\";s:0:\"\";}}}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"00ed994f-d4eb-4c96-af26-756231339f97\";a:10:{s:4:\"name\";s:19:\"Social Media Handle\";s:6:\"handle\";s:12:\"socialHandle\";s:12:\"instructions\";s:146:\"If you are entering your social media, do not enter the full url, only the handle eg. pixville if your facebook url would be facebook.com/pixville\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"5840686a-9862-402e-a802-afd1df5059a7\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"824acb69-e348-4edc-87dd-1cbd481679e2\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"00ed994f-d4eb-4c96-af26-756231339f97\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}}}}}s:36:\"176b97a1-6688-4da5-9f6e-af076a591408\";a:6:{s:5:\"field\";s:36:\"8c2ffb37-a84f-4e8e-acd1-918bf2411ade\";s:4:\"name\";s:13:\"Pagina Sectie\";s:6:\"handle\";s:11:\"pageSection\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:6:{s:36:\"f6f0b2e9-aacc-4263-8331-50888bc29fce\";a:10:{s:4:\"name\";s:7:\"Heading\";s:6:\"handle\";s:7:\"heading\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:22:\"craft\\fields\\PlainText\";s:8:\"settings\";a:6:{s:11:\"placeholder\";s:0:\"\";s:4:\"code\";s:0:\"\";s:9:\"multiline\";s:0:\"\";s:11:\"initialRows\";s:1:\"4\";s:9:\"charLimit\";s:0:\"\";s:10:\"columnType\";s:4:\"text\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"4a610845-4add-497d-b644-2407d53b2cb6\";a:10:{s:4:\"name\";s:12:\"Omschrijving\";s:6:\"handle\";s:11:\"description\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:20:\"craft\\redactor\\Field\";s:8:\"settings\";a:7:{s:14:\"redactorConfig\";s:0:\"\";s:14:\"purifierConfig\";s:0:\"\";s:11:\"cleanupHtml\";s:1:\"1\";s:10:\"purifyHtml\";s:1:\"1\";s:10:\"columnType\";s:4:\"text\";s:16:\"availableVolumes\";s:0:\"\";s:19:\"availableTransforms\";s:1:\"*\";}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}s:36:\"90203408-6f4e-4b51-87b2-8021c2914dbc\";a:10:{s:4:\"name\";s:10:\"Afbeelding\";s:6:\"handle\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:0:\"\";s:12:\"allowedKinds\";N;s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"31ffcee5-00c4-45a1-b98b-ef612e17799e\";a:10:{s:4:\"name\";s:13:\"Video Bestand\";s:6:\"handle\";s:5:\"video\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"site\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:19:\"craft\\fields\\Assets\";s:8:\"settings\";a:14:{s:15:\"useSingleFolder\";s:1:\"1\";s:27:\"defaultUploadLocationSource\";s:43:\"volume:a191c99d-cf7a-4919-a0e9-82fd99da791c\";s:28:\"defaultUploadLocationSubpath\";s:0:\"\";s:26:\"singleUploadLocationSource\";s:43:\"volume:7abe41af-4979-4ac8-be5e-8c0c85a91dd3\";s:27:\"singleUploadLocationSubpath\";s:0:\"\";s:13:\"restrictFiles\";s:1:\"1\";s:12:\"allowedKinds\";a:1:{i:0;s:5:\"video\";}s:7:\"sources\";s:1:\"*\";s:6:\"source\";N;s:12:\"targetSiteId\";N;s:8:\"viewMode\";s:4:\"list\";s:5:\"limit\";s:1:\"1\";s:14:\"selectionLabel\";s:0:\"\";s:17:\"localizeRelations\";b:0;}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"f63058da-24d7-492f-a783-dcf2e893f3d4\";a:10:{s:4:\"name\";s:7:\"Positie\";s:6:\"handle\";s:8:\"position\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:38:\"rias\\positionfieldtype\\fields\\Position\";s:8:\"settings\";a:2:{s:7:\"options\";a:6:{s:4:\"left\";s:1:\"1\";s:6:\"center\";s:0:\"\";s:5:\"right\";s:1:\"1\";s:4:\"full\";s:0:\"\";s:9:\"drop-left\";s:0:\"\";s:10:\"drop-right\";s:0:\"\";}s:7:\"default\";s:0:\"\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"e50f5c06-23e7-4dc4-ab5c-558ccff08916\";a:10:{s:4:\"name\";s:4:\"Knop\";s:6:\"handle\";s:6:\"button\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:31:\"typedlinkfield\\fields\\LinkField\";s:8:\"settings\";a:9:{s:15:\"allowCustomText\";s:1:\"1\";s:16:\"allowedLinkNames\";a:1:{i:3;s:5:\"entry\";}s:11:\"allowTarget\";s:0:\"\";s:14:\"autoNoReferrer\";s:0:\"\";s:15:\"defaultLinkName\";s:5:\"asset\";s:11:\"defaultText\";s:0:\"\";s:15:\"enableAriaLabel\";s:0:\"\";s:11:\"enableTitle\";s:0:\"\";s:12:\"typeSettings\";a:9:{s:5:\"asset\";a:2:{s:7:\"sources\";s:1:\"*\";s:16:\"allowCustomQuery\";s:0:\"\";}s:8:\"category\";a:2:{s:7:\"sources\";s:1:\"*\";s:16:\"allowCustomQuery\";s:0:\"\";}s:5:\"entry\";a:2:{s:7:\"sources\";s:1:\"*\";s:16:\"allowCustomQuery\";s:0:\"\";}s:4:\"site\";a:1:{s:5:\"sites\";s:1:\"*\";}s:4:\"user\";a:2:{s:7:\"sources\";s:1:\"*\";s:16:\"allowCustomQuery\";s:0:\"\";}s:6:\"custom\";a:2:{s:17:\"disableValidation\";s:0:\"\";s:12:\"allowAliases\";s:0:\"\";}s:5:\"email\";a:2:{s:17:\"disableValidation\";s:0:\"\";s:12:\"allowAliases\";s:0:\"\";}s:3:\"tel\";a:2:{s:17:\"disableValidation\";s:0:\"\";s:12:\"allowAliases\";s:0:\"\";}s:3:\"url\";a:2:{s:17:\"disableValidation\";s:0:\"\";s:12:\"allowAliases\";s:0:\"\";}}}s:17:\"contentColumnType\";s:4:\"text\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"65351a45-8610-46c5-bc0c-cbcd7b7052ab\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:6:{s:36:\"f6f0b2e9-aacc-4263-8331-50888bc29fce\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"4a610845-4add-497d-b644-2407d53b2cb6\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}s:36:\"90203408-6f4e-4b51-87b2-8021c2914dbc\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:3;}s:36:\"31ffcee5-00c4-45a1-b98b-ef612e17799e\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:4;}s:36:\"f63058da-24d7-492f-a783-dcf2e893f3d4\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:5;}s:36:\"e50f5c06-23e7-4dc4-ab5c-558ccff08916\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:6;}}}}}}}s:36:\"635802c2-875d-46ed-ac27-e4787038f284\";a:6:{s:5:\"field\";s:36:\"1ecb7ca2-2f4b-4be1-9831-d401ed900d94\";s:4:\"name\";s:12:\"Social Media\";s:6:\"handle\";s:11:\"socialMedia\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"bf0a9b8c-926d-45e3-9a9f-9d68a1c88cdb\";a:10:{s:4:\"name\";s:18:\"Sociale Media Naam\";s:6:\"handle\";s:15:\"socialMediaName\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:21:\"craft\\fields\\Dropdown\";s:8:\"settings\";a:1:{s:7:\"options\";a:3:{i:0;a:3:{s:5:\"label\";s:8:\"Facebook\";s:5:\"value\";s:8:\"facebook\";s:7:\"default\";s:0:\"\";}i:1;a:3:{s:5:\"label\";s:9:\"Instagram\";s:5:\"value\";s:9:\"instagram\";s:7:\"default\";s:0:\"\";}i:2;a:3:{s:5:\"label\";s:7:\"Twitter\";s:5:\"value\";s:7:\"twitter\";s:7:\"default\";s:0:\"\";}}}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}s:36:\"eb060988-6801-492e-9ec2-ce5588a08322\";a:10:{s:4:\"name\";s:17:\"Sociale Media Url\";s:6:\"handle\";s:14:\"socialMediaUrl\";s:12:\"instructions\";s:0:\"\";s:10:\"searchable\";b:1;s:17:\"translationMethod\";s:4:\"none\";s:20:\"translationKeyFormat\";N;s:4:\"type\";s:38:\"barrelstrength\\sproutfields\\fields\\Url\";s:8:\"settings\";a:4:{s:25:\"customPatternErrorMessage\";s:0:\"\";s:19:\"customPatternToggle\";s:0:\"\";s:13:\"customPattern\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}s:17:\"contentColumnType\";s:6:\"string\";s:10:\"fieldGroup\";N;}}s:12:\"fieldLayouts\";a:1:{s:36:\"2edef910-150e-4e1e-941a-18597a6d0952\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:7:\"Content\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:2:{s:36:\"bf0a9b8c-926d-45e3-9a9f-9d68a1c88cdb\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"eb060988-6801-492e-9ec2-ce5588a08322\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}}}}}}}}s:10:\"globalSets\";a:3:{s:36:\"e43560e9-d586-47b3-802f-f011a542bba2\";a:3:{s:4:\"name\";s:13:\"Business Info\";s:6:\"handle\";s:12:\"businessInfo\";s:12:\"fieldLayouts\";a:1:{s:36:\"129ea065-edb9-4478-828b-6cb619a3328e\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:20:\"Business Information\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:4:{s:36:\"6d478d4f-9299-4ee7-9a56-6a43774f3007\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}s:36:\"9479e2aa-aa84-4b85-bedf-ae3f0acc9133\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:2;}s:36:\"287e08eb-254e-4334-a7d1-78acaa94a267\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:3;}s:36:\"45784098-995c-40a8-a7d3-7faad1234bd7\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:4;}}}}}}}s:36:\"a598fd75-f99c-463b-ad1c-42d530061e4b\";a:3:{s:4:\"name\";s:13:\"Sociale Media\";s:6:\"handle\";s:11:\"socialMedia\";s:12:\"fieldLayouts\";a:1:{s:36:\"6fd50707-6c72-45c6-8664-904611a37057\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:13:\"Sociale Media\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"1ecb7ca2-2f4b-4be1-9831-d401ed900d94\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}s:36:\"4ab168f2-9811-4f21-a536-79f9bb8e8f3b\";a:3:{s:4:\"name\";s:8:\"Branding\";s:6:\"handle\";s:8:\"branding\";s:12:\"fieldLayouts\";a:1:{s:36:\"bcc9f9c7-e89b-47a9-a9b2-525b022e3897\";a:1:{s:4:\"tabs\";a:1:{i:0;a:3:{s:4:\"name\";s:8:\"Branding\";s:9:\"sortOrder\";i:1;s:6:\"fields\";a:1:{s:36:\"940b5b29-ca1b-42b0-af88-c54030041237\";a:2:{s:8:\"required\";b:0;s:9:\"sortOrder\";i:1;}}}}}}}}}','[]','pxQLp5lleChE','2019-02-05 15:44:19','2019-02-05 20:09:34','95eb1b95-db8e-4c90-848b-b42df72ca535');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (4,2,NULL,53,6,1,NULL,'2019-02-05 17:06:26','2019-02-05 17:58:50','c498c876-b18a-401c-ba76-e2fde972838b'),(14,2,NULL,53,6,2,NULL,'2019-02-05 17:26:06','2019-02-05 17:58:50','fc6afeee-484f-4a53-a801-be899479e52a'),(15,2,NULL,53,6,3,NULL,'2019-02-05 17:26:49','2019-02-05 17:58:50','07e3e832-046e-42f0-a30d-89f51655fe30'),(17,16,NULL,58,7,1,NULL,'2019-02-05 17:34:00','2019-02-05 17:34:00','63b1961a-d8db-4116-b118-968ae6974eb7'),(18,16,NULL,58,7,2,NULL,'2019-02-05 17:34:00','2019-02-05 17:34:00','64355fce-6438-4306-bf15-10371450d07d'),(27,19,NULL,53,6,1,NULL,'2019-02-05 17:54:07','2019-02-05 18:12:38','0e0ed425-0783-4325-8ccc-dd456c486558'),(28,19,NULL,53,6,2,NULL,'2019-02-05 17:54:07','2019-02-05 18:12:38','0fe11570-8326-4481-b527-d751344cc6ca'),(29,19,NULL,53,6,3,NULL,'2019-02-05 17:54:07','2019-02-05 18:12:38','4fb0e9d8-9b7d-4df9-a6d5-ee251e44ab7a'),(32,31,NULL,4,1,1,NULL,'2019-02-05 18:10:23','2019-02-05 19:28:24','8b482e37-ae46-43bd-a276-fa58fc4bd841'),(33,31,NULL,4,2,2,NULL,'2019-02-05 18:10:23','2019-02-05 19:28:24','104ba61b-6d65-41ea-9ff4-40f116392518');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (1,4,1,'Heading','heading',1,'2019-02-05 16:45:08','2019-02-05 18:10:43','26001dc6-a1b6-43af-8542-d488f87d3e94'),(2,4,2,'Text','text',2,'2019-02-05 16:45:08','2019-02-05 18:10:43','da843291-6248-409e-a948-94ea290bf850'),(3,4,3,'Image','image',3,'2019-02-05 16:45:09','2019-02-05 18:10:43','cb5bf083-a7d2-4696-91a9-7f90ac118ca0'),(4,4,4,'Video','video',4,'2019-02-05 16:45:09','2019-02-05 18:10:43','299bc55b-d15a-4949-97f2-eb0d2e563898'),(5,46,5,'social','social',1,'2019-02-05 16:45:11','2019-02-05 16:45:11','09be61e5-e205-4f6f-bef4-94624de2b5ee'),(6,53,14,'Pagina Sectie','pageSection',1,'2019-02-05 16:53:52','2019-02-05 17:46:57','176b97a1-6688-4da5-9f6e-af076a591408'),(7,58,15,'Social Media','socialMedia',1,'2019-02-05 17:32:14','2019-02-05 17:32:14','635802c2-875d-46ed-ac27-e4787038f284');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_contentbuilder`
--

LOCK TABLES `matrixcontent_contentbuilder` WRITE;
/*!40000 ALTER TABLE `matrixcontent_contentbuilder` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_contentbuilder` VALUES (1,32,1,'2019-02-05 18:10:23','2019-02-05 19:28:24','18f6e130-a1f2-4db0-90c7-53c007ec94f0','Heading',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,33,1,'2019-02-05 18:10:23','2019-02-05 19:28:24','31e9954b-7927-4d8b-ac18-2b9a10c9ef38',NULL,0,'Subtitel','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>','full','full',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `matrixcontent_contentbuilder` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_socialbuilder`
--

LOCK TABLES `matrixcontent_socialbuilder` WRITE;
/*!40000 ALTER TABLE `matrixcontent_socialbuilder` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixcontent_socialbuilder` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_socialmedia`
--

LOCK TABLES `matrixcontent_socialmedia` WRITE;
/*!40000 ALTER TABLE `matrixcontent_socialmedia` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_socialmedia` VALUES (1,17,1,'2019-02-05 17:34:00','2019-02-05 17:34:00','6e43f79b-892b-4d7b-94d1-0bf0894871a3','facebook','https://facebook.com'),(2,18,1,'2019-02-05 17:34:00','2019-02-05 17:34:00','b94999b9-30f9-4bff-bc52-a2a636a50a33','instagram','https://instagram.com');
/*!40000 ALTER TABLE `matrixcontent_socialmedia` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_visualbuilder`
--

LOCK TABLES `matrixcontent_visualbuilder` WRITE;
/*!40000 ALTER TABLE `matrixcontent_visualbuilder` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_visualbuilder` VALUES (1,4,1,'2019-02-05 17:06:26','2019-02-05 17:58:50','ad0f663f-76ae-40ac-96ab-af22aad99898','Soms heeft een zoektocht, een gids nodig','<p>Ben je de weg kwijt, voel je je eenzaam en onbegrepen, twijfel je aan jezelf, voel je je uitgeblust, is de magie uit jullie relatie verdwenen, ontbreekt het je aan levenslust , stel je vragen bij je toekomst,… Weet je, iedereen verdient gelukkig te zijn en dit ook te voelen. Bij careto ondersteunen we koppels, kinderen, ouders en individuen in hun zoektocht naar hun eigen geluk.</p>\n<p>Scheiden brengt veel zorgen, onzekerheden en verdriet met zich mee. Dikwijls ontstaat er ook een strijd, die niet alleen emotioneel maar ook financieel uitputtend kan zijn. Bemiddeling houdt jullie uit de strijd met elkaar... De bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex-partner en ouder.</p>','left','{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"Bemiddeling\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":\"19\"}'),(2,14,1,'2019-02-05 17:26:06','2019-02-05 17:58:50','0c5fe385-d1ff-4b92-ac1d-d85d7d33a1a4','Zing je eigen lied,  dans je eigen dans','<p>Wanneer een moeilijke fase je leven binnensluipt, hebben jouw emoties zorg en aandacht nodig. Careto is een ruimte waar je even tot rust kan komen, vrij en on over je emoties kan spreken. Een plaats waar alles mag zijn en niets ‘moet’. Een plek waar je gedachten, angsten, boosheid, verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt.</p>','right','{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}'),(3,15,1,'2019-02-05 17:26:49','2019-02-05 17:58:50','d47469fd-ae82-47ba-9195-c8402d979a22','Verandering begint bij jezelf, eenzaam in de relatie?','<p>Geen uitweg meer in de sleur van het dagdagelijks leven? Hoe moet het verder met jullie relatie na ontrouw van je partner? Het gevoel als broer en zus te leven? Jullie zijn niet de enige met dit probleem.</p>\n<p>Dagelijks wordt je geconfronteerd met ruzies die jullie uitputten en waarvoor geen oplossing lijkt te zijn. Wat is jullie toekomst nog samen? Soms gaan koppels uit voorzorg in therapie, om de relatie te verrijken. Bespreek het met onze therapeut.</p>','right','{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}'),(4,27,1,'2019-02-05 17:54:07','2019-02-05 18:12:38','2277deae-c8e2-4daf-ace2-7bd9b1200237','Familiale Bemiddeling','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>','left','{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"meer info\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":\"31\"}'),(5,28,1,'2019-02-05 17:54:07','2019-02-05 18:12:38','4caf3382-3cb8-4457-827e-3133b76b00db','Heading 2 Rechts','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>','right','{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}'),(6,29,1,'2019-02-05 17:54:07','2019-02-05 18:12:38','980b38e0-356e-40f5-a122-4daa26144944','Heading 3 Links','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur justo mi, dictum nec sem nec, scelerisque lobortis mi. Pellentesque eget nulla mattis, cursus risus in, bibendum mauris. Phasellus hendrerit venenatis feugiat. Etiam semper ex consequat iaculis ullamcorper. Cras porttitor bibendum tristique. Sed aliquam dui purus, nec iaculis lorem consequat quis. Etiam cursus risus nec consectetur pharetra. Aliquam tempor diam porta felis lobortis pulvinar sed in eros.</p>','left','{\"ariaLabel\":null,\"customQuery\":null,\"customText\":\"\",\"target\":null,\"title\":null,\"type\":\"entry\",\"value\":null}');
/*!40000 ALTER TABLE `matrixcontent_visualbuilder` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,NULL,'app','Install','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','c6394e4c-489a-4d33-b5d3-06e2f10fb39a'),(2,NULL,'app','m150403_183908_migrations_table_changes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5285c1c2-e9c2-4f71-9650-8330cc482fea'),(3,NULL,'app','m150403_184247_plugins_table_changes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','30f07461-72c3-41ec-b868-fb302009f89b'),(4,NULL,'app','m150403_184533_field_version','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','701189bc-4d1c-4099-8e33-93edb315996c'),(5,NULL,'app','m150403_184729_type_columns','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','ea952c91-8d7b-4ced-8cd5-290d8878ec9e'),(6,NULL,'app','m150403_185142_volumes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','62aacfa6-9d3e-4a4a-8e57-3e85e2327b6e'),(7,NULL,'app','m150428_231346_userpreferences','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','97e25815-8963-4187-acac-24776fb058bd'),(8,NULL,'app','m150519_150900_fieldversion_conversion','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','2682fb3c-86a4-48ae-9e30-b951d4c91bc1'),(9,NULL,'app','m150617_213829_update_email_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','f9920d98-588d-4f73-86d3-a73408730831'),(10,NULL,'app','m150721_124739_templatecachequeries','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','6bb7e817-1e4d-40e9-a3a9-8e640ed7663b'),(11,NULL,'app','m150724_140822_adjust_quality_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','cdb826e5-8090-4d2d-abf6-8304caba87d7'),(12,NULL,'app','m150815_133521_last_login_attempt_ip','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','13955796-c2e9-43e1-ab3f-4611d0682114'),(13,NULL,'app','m151002_095935_volume_cache_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','f640f2cb-8561-4115-bb63-a4cb2f77f558'),(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3ed3b347-c511-4100-9132-767df36e1cb2'),(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','adf86093-3e8b-415e-8a92-aba863051d56'),(16,NULL,'app','m151209_000000_move_logo','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','8c33683a-dee9-4a23-8e84-b7c0bfba12d7'),(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','9487d111-937b-4b42-b62b-3aec6d0e5806'),(18,NULL,'app','m151215_000000_rename_asset_permissions','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','b261589e-04f0-41da-99b1-8ff8b03bee8b'),(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','1ec7023e-92d8-4b52-8237-b4866ace06ac'),(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','e3a313d7-c0b8-4663-9986-428df20fabed'),(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','d50e8d0c-fe8e-4a41-8260-6a45fc6576d7'),(22,NULL,'app','m160727_194637_column_cleanup','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','12eb7ade-abf0-4294-8369-0b6adda5d1a0'),(23,NULL,'app','m160804_110002_userphotos_to_assets','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','89e3f13f-b0be-4403-89ec-ee70b9b5f440'),(24,NULL,'app','m160807_144858_sites','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','46daad72-f9aa-43a7-afe2-c461a20cfca1'),(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','ba7218a7-bc32-45e7-be55-ba78fe8fce47'),(26,NULL,'app','m160830_000000_asset_index_uri_increase','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','655f7932-da1d-47bd-b64a-18d20399bc6e'),(27,NULL,'app','m160912_230520_require_entry_type_id','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','f5b80cad-a8a7-4c5c-9cbf-0ee6c9034306'),(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','9905f229-4098-4fe0-9e7d-7a7b3200fab3'),(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5419cdb2-602c-4ea8-9e6e-49b032bd920d'),(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','fb2f7e77-97e7-4bfc-8ac4-5092a3ba4499'),(31,NULL,'app','m160925_113941_route_uri_parts','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','1074e8ca-3552-40b9-9fd0-8b3054b1fbce'),(32,NULL,'app','m161006_205918_schemaVersion_not_null','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','90b44cd0-1d7c-4bb5-93d2-3da33489e0d2'),(33,NULL,'app','m161007_130653_update_email_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','ffb8386e-a320-4fd5-9a8f-4e751ba11e4f'),(34,NULL,'app','m161013_175052_newParentId','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','14b86148-4068-46b3-9953-16fe09363358'),(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5d318dc8-1127-4573-9966-1b5a0f5e4746'),(36,NULL,'app','m161021_182140_rename_get_help_widget','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','86fad542-ae50-412b-9f6d-092c0256734b'),(37,NULL,'app','m161025_000000_fix_char_columns','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','2cc97421-52a8-4324-92ac-85627474125b'),(38,NULL,'app','m161029_124145_email_message_languages','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3a4e0469-6cdc-4564-b28f-13a58ad21be6'),(39,NULL,'app','m161108_000000_new_version_format','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','02f8acf3-cd86-4a6a-8126-8f552dc3af49'),(40,NULL,'app','m161109_000000_index_shuffle','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5cc2c5a7-e49b-4a3b-a3d8-c4d6164f9539'),(41,NULL,'app','m161122_185500_no_craft_app','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','6babc13b-9677-44a4-a869-07d0d31d8acd'),(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','b92b8df0-9ca6-4670-a2a3-aa700dcdf172'),(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','7386de6c-c7a8-48f1-a966-8b47b93b2ae5'),(44,NULL,'app','m170114_161144_udates_permission','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','070f2ddf-ff55-4fa6-80b1-539eed094051'),(45,NULL,'app','m170120_000000_schema_cleanup','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','df00d2a8-1f59-426b-95e7-cfdfa4179664'),(46,NULL,'app','m170126_000000_assets_focal_point','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','818d7c34-6a7c-4334-9384-f21660ebab55'),(47,NULL,'app','m170206_142126_system_name','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5b970b13-f599-434f-8ea5-32ab8668aead'),(48,NULL,'app','m170217_044740_category_branch_limits','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','06b12317-0367-473f-9b30-092868b5af6f'),(49,NULL,'app','m170217_120224_asset_indexing_columns','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','6b4a2947-e24c-4460-a78c-48a83f6271d3'),(50,NULL,'app','m170223_224012_plain_text_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','32a79f9d-b959-46e8-a9b4-1ec2dbf9da0f'),(51,NULL,'app','m170227_120814_focal_point_percentage','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','368ebc5f-1025-4b11-87bf-09151006d08c'),(52,NULL,'app','m170228_171113_system_messages','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','dde7cedd-1d0a-4667-9976-2114d2143bba'),(53,NULL,'app','m170303_140500_asset_field_source_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','f6741cc2-7efb-4b18-908c-89b03c548449'),(54,NULL,'app','m170306_150500_asset_temporary_uploads','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','bcd209fc-8eef-452f-b569-628741ece51a'),(55,NULL,'app','m170523_190652_element_field_layout_ids','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','17846428-3db0-4f65-be00-780a5153b0d1'),(56,NULL,'app','m170612_000000_route_index_shuffle','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','02dd32be-a271-4a4f-a54f-27eb8b6e21aa'),(57,NULL,'app','m170621_195237_format_plugin_handles','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','1fa0ee66-7970-4cdb-b3b7-5c50d2794454'),(58,NULL,'app','m170630_161027_deprecation_line_nullable','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','19afbdec-90a7-406c-9bfc-5e0265d712a9'),(59,NULL,'app','m170630_161028_deprecation_changes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','b65aff09-9f2b-4dfc-9d6c-949b2aee188e'),(60,NULL,'app','m170703_181539_plugins_table_tweaks','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','c2054717-e059-4b51-93df-f5a21c6dbcee'),(61,NULL,'app','m170704_134916_sites_tables','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','eb73c153-a4ec-4059-ae2c-91fadcdfdfb6'),(62,NULL,'app','m170706_183216_rename_sequences','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','c186e2ed-d614-4f6a-98d2-546172901e95'),(63,NULL,'app','m170707_094758_delete_compiled_traits','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','e5c20a7f-6663-4c53-a5d2-298436e4957e'),(64,NULL,'app','m170731_190138_drop_asset_packagist','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','692ca9d7-d2f1-4624-8236-cd95135306fb'),(65,NULL,'app','m170810_201318_create_queue_table','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','34920a1c-22e4-4592-8ded-0305b3156f2f'),(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','26cf8878-fe48-441a-bd5f-5d2173626b27'),(67,NULL,'app','m170903_192801_longblob_for_queue_jobs','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','a4170173-52f8-4df9-bf49-14ab31ffee00'),(68,NULL,'app','m170914_204621_asset_cache_shuffle','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','50e3c2b7-3605-4e20-a1b2-f9369103bb87'),(69,NULL,'app','m171011_214115_site_groups','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','f912a358-c4e7-43f6-944f-f19e03da3c13'),(70,NULL,'app','m171012_151440_primary_site','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','31f5dccb-63ae-48d6-99a5-997942c3b283'),(71,NULL,'app','m171013_142500_transform_interlace','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','d8fe7753-3710-4c49-90cb-94ffb6080c68'),(72,NULL,'app','m171016_092553_drop_position_select','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','e71ab04e-bede-454e-bad7-745ed3a72e81'),(73,NULL,'app','m171016_221244_less_strict_translation_method','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3bb6c24e-556f-4bf9-b0b0-2f28a8e94115'),(74,NULL,'app','m171107_000000_assign_group_permissions','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','81b54f31-5591-4cd7-91d1-e2716559d2b0'),(75,NULL,'app','m171117_000001_templatecache_index_tune','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','933efe62-032f-468a-89d7-701e7efbf0f5'),(76,NULL,'app','m171126_105927_disabled_plugins','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','80dd1ee2-25d4-4324-91fb-89142fba415a'),(77,NULL,'app','m171130_214407_craftidtokens_table','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','40b317cc-61af-4224-ab41-72dccf6c8a13'),(78,NULL,'app','m171202_004225_update_email_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','fccaf18f-7e2c-4eb5-b968-1e4680b3566b'),(79,NULL,'app','m171204_000001_templatecache_index_tune_deux','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','35853142-a388-4560-b57f-38d05747a4d8'),(80,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3cf7f801-9dab-415c-812d-fcf8d92a98d7'),(81,NULL,'app','m171218_143135_longtext_query_column','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','52d718da-3555-49f1-8a5b-c10f7dbb9d9d'),(82,NULL,'app','m171231_055546_environment_variables_to_aliases','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','d45ac7a0-1eb8-4db8-b1ac-b4ce9055c2b9'),(83,NULL,'app','m180113_153740_drop_users_archived_column','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','88bdc8b8-4159-497a-8479-1ebc9f8b0401'),(84,NULL,'app','m180122_213433_propagate_entries_setting','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','8f8ac665-48f0-430f-a7af-5c2c83c645bb'),(85,NULL,'app','m180124_230459_fix_propagate_entries_values','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','7720136c-f83e-4046-a5d7-af03bfda5e12'),(86,NULL,'app','m180128_235202_set_tag_slugs','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','d684e877-370f-4d47-957c-c10af0bbc427'),(87,NULL,'app','m180202_185551_fix_focal_points','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3cd0b22f-b75e-43e2-8800-7015bb3062af'),(88,NULL,'app','m180217_172123_tiny_ints','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','038441fe-8368-4459-9913-08b486e1e54d'),(89,NULL,'app','m180321_233505_small_ints','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','0d7c4833-e779-46f5-8d90-8475906b6464'),(90,NULL,'app','m180328_115523_new_license_key_statuses','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','a2a3f128-3115-4ebc-ac9f-52343afc7ad2'),(91,NULL,'app','m180404_182320_edition_changes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5856f035-57a3-4bc3-a00d-930a93245aad'),(92,NULL,'app','m180411_102218_fix_db_routes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3409f3f7-c2c6-49ef-a4b8-28574c2f4299'),(93,NULL,'app','m180416_205628_resourcepaths_table','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','4408b2e1-c44d-492c-9755-f23efb4fee5b'),(94,NULL,'app','m180418_205713_widget_cleanup','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','38260cca-1486-44cc-aa51-0899f07b819e'),(95,NULL,'app','m180425_203349_searchable_fields','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','0f03fdc0-a312-48f9-920d-55845b34b375'),(96,NULL,'app','m180516_153000_uids_in_field_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3ae4afde-2088-404f-9419-6da9dcb23af6'),(97,NULL,'app','m180517_173000_user_photo_volume_to_uid','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','06de2a59-2c42-4935-bad4-f8b4a5b02eee'),(98,NULL,'app','m180518_173000_permissions_to_uid','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','d58611d7-cb91-4356-97ad-6ac021d97849'),(99,NULL,'app','m180520_173000_matrix_context_to_uids','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','9549eb6b-4340-49a1-9138-3e7a47c85958'),(100,NULL,'app','m180521_173000_initial_yml_and_snapshot','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','459a162a-b6c9-47a8-92b1-865916411681'),(101,NULL,'app','m180731_162030_soft_delete_sites','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','2f08a7c1-8861-484b-8f6b-db62dd6ccd74'),(102,NULL,'app','m180810_214427_soft_delete_field_layouts','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','23c9df6b-cb55-43c8-b689-184d27a0c0f5'),(103,NULL,'app','m180810_214439_soft_delete_elements','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','65efaedb-9825-4c60-99ba-d09cf0bbaf0f'),(104,NULL,'app','m180824_193422_case_sensitivity_fixes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','47b9f11b-4718-43e5-81b5-11cc3915a367'),(105,NULL,'app','m180901_151639_fix_matrixcontent_tables','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','750889a8-d292-4a9e-b105-a291346494bd'),(106,NULL,'app','m180904_112109_permission_changes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','f03dcf92-1518-471b-aee5-3d5f8302c923'),(107,NULL,'app','m180910_142030_soft_delete_sitegroups','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','a8423baa-9f04-48ba-83c7-5a48b3081670'),(108,NULL,'app','m181011_160000_soft_delete_asset_support','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','4618079e-d2ec-4be7-b085-f3de84462670'),(109,NULL,'app','m181016_183648_set_default_user_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','ec1bdfac-c95f-46c9-9a40-56020b2cd7c9'),(110,NULL,'app','m181017_225222_system_config_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','b94ea297-c2f6-47f3-86f5-59a84fcc3741'),(111,NULL,'app','m181018_222343_drop_userpermissions_from_config','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','c5d546f8-db7a-4561-a487-1632b34cd0c4'),(112,NULL,'app','m181029_130000_add_transforms_routes_to_config','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','0471caa4-5924-4a4a-9a35-e161cd052950'),(113,NULL,'app','m181112_203955_sequences_table','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','b832ae51-998f-4aab-855d-6f9fb4201e06'),(114,NULL,'app','m181121_001712_cleanup_field_configs','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','ba93bd38-f361-4eb1-b16f-309598eff451'),(115,NULL,'app','m181128_193942_fix_project_config','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','866459ba-5d2f-4bba-bca9-cd9cc649a2b5'),(116,NULL,'app','m181130_143040_fix_schema_version','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','92997275-939d-4e18-b695-823a4ee85dbd'),(117,NULL,'app','m181211_143040_fix_entry_type_uids','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','09e88aab-606c-4d3f-93f1-e764e90db57e'),(118,NULL,'app','m181213_102500_config_map_aliases','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','112732d7-154d-488c-a32e-47e842902ab8'),(119,NULL,'app','m181217_153000_fix_structure_uids','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','ca9613d5-48e0-41cf-8e51-825730738a36'),(120,NULL,'app','m190104_152725_store_licensed_plugin_editions','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','a98c69bc-8260-45f6-97bb-29d28ab7f020'),(121,NULL,'app','m190108_110000_cleanup_project_config','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','48e5e4e3-81db-49ee-b4b6-63f73b9683d6'),(122,NULL,'app','m190108_113000_asset_field_setting_change','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','5bd00367-13d3-4bee-bcbf-ed65902353a0'),(123,NULL,'app','m190109_172845_fix_colspan','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3fc1a754-3008-419b-a561-f36f3d52b3b2'),(124,NULL,'app','m190110_150000_prune_nonexisting_sites','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','fb85dc3a-5fd5-4ebd-9b88-09efb67b0d38'),(125,NULL,'app','m190110_214819_soft_delete_volumes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','0626eab4-c7ce-465d-8b7e-483dc3a1eace'),(126,NULL,'app','m190112_124737_fix_user_settings','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','15222844-dee4-42c7-86fd-304dba24e0e6'),(127,NULL,'app','m190112_131225_fix_field_layouts','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','2ad373bf-c399-4308-80f3-fdfc5b38edaa'),(128,NULL,'app','m190112_201010_more_soft_deletes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','b856e29f-da2f-427d-bf63-b4409bbf0816'),(129,NULL,'app','m190114_143000_more_asset_field_setting_changes','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','dcc0ff34-ef32-4ce4-bb18-f6d15da4335e'),(130,NULL,'app','m190121_120000_rich_text_config_setting','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','7a533d69-a841-4add-a7dc-bd5b22fd4b88'),(131,NULL,'app','m190125_191628_fix_email_transport_password','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','2ed9fe87-6471-4a08-8846-0c9172a267fa'),(132,NULL,'app','m190128_181422_cleanup_volume_folders','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','4ab0ae83-f354-468f-86ab-b0f8ac7920c4'),(133,NULL,'app','m190218_143000_element_index_settings_uid','2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 15:44:19','3ce9c59e-a79f-4d85-b57e-c7959e542df7'),(134,1,'plugin','Install','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','bba81d42-bf2b-4d09-af52-ef17e4492ba4'),(135,1,'plugin','m180221_161521_update_type','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','6ddccbd6-c17e-4360-8dee-2096ca56a679'),(136,1,'plugin','m180221_161522_notes_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','1d412025-ee0c-477c-a0f7-ed6da1b09f41'),(137,1,'plugin','m180221_161523_phone_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','59d4c803-c179-46e9-b563-b4f738931b6f'),(138,1,'plugin','m180221_161524_email_select_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','b6a2ba16-b18a-408a-90df-53fe184d46ae'),(139,1,'plugin','m180221_161525_regular_expression_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','f3af0217-6957-492f-983b-2b49481e6396'),(140,1,'plugin','m180221_161526_link_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','e7d01358-99fd-48a0-ac68-540211f63520'),(141,1,'plugin','m180221_161527_email_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','89f6cae1-7ad9-41d2-a649-b20ebf6b14f9'),(142,1,'plugin','m180221_161528_hidden_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','057df08a-2c26-4dd3-87cc-de59d413ed51'),(143,1,'plugin','m180221_161529_invisible_fields','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','5a33b90d-1262-4520-8f55-5f651f48f0ca'),(144,1,'plugin','m180228_161529_settings_to_null','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','b702630d-22ce-43b3-b589-d1927ee707f0'),(145,1,'plugin','m180328_073816_create_address_table','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','4d904b12-533a-4145-b925-7da5f70afa20'),(146,1,'plugin','m190116_000000_address_field','2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:41:56','b197c7af-6564-4abe-97f4-4b136ede8a27'),(147,6,'plugin','Install','2019-02-05 16:42:39','2019-02-05 16:42:39','2019-02-05 16:42:39','2a0bd452-6556-4c6c-a475-6241daf5f9c5'),(148,14,'plugin','m180430_204710_remove_old_plugins','2019-02-05 16:43:07','2019-02-05 16:43:07','2019-02-05 16:43:07','0a0e2f8f-592c-4f0d-8714-cfb008d9fd90'),(149,14,'plugin','Install','2019-02-05 16:43:07','2019-02-05 16:43:07','2019-02-05 16:43:07','325ee054-d7da-4415-956f-6b7021e16692'),(150,14,'plugin','m181101_110000_ids_in_settings_to_uids','2019-02-05 16:43:07','2019-02-05 16:43:07','2019-02-05 16:43:07','711dd6b0-1c97-44f2-9560-d189ad55dcb4'),(151,15,'plugin','Install','2019-02-05 16:43:11','2019-02-05 16:43:11','2019-02-05 16:43:11','0264721c-8740-4c36-841f-7dfeb71e1b1e'),(152,15,'plugin','m180314_002755_field_type','2019-02-05 16:43:11','2019-02-05 16:43:11','2019-02-05 16:43:11','0a004d05-62ce-478f-ab6e-4aa3746fcd0a'),(153,15,'plugin','m180314_002756_base_install','2019-02-05 16:43:11','2019-02-05 16:43:11','2019-02-05 16:43:11','923cb607-1ea0-4f81-9a72-22bdeed097da'),(154,15,'plugin','m180502_202319_remove_field_metabundles','2019-02-05 16:43:11','2019-02-05 16:43:11','2019-02-05 16:43:11','99094205-56b4-40a0-85ca-98c398402d5b'),(155,15,'plugin','m180711_024947_commerce_products','2019-02-05 16:43:11','2019-02-05 16:43:11','2019-02-05 16:43:11','2addc854-2aa0-44c2-b773-d2d113c73dc0'),(156,19,'plugin','Install','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','e1a5d18a-1534-4c9b-b66f-fa0e66b19e04'),(157,19,'plugin','m180210_000000_migrate_content_tables','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','4f24dee8-d1cb-4a6a-a29e-6d174697099d'),(158,19,'plugin','m180211_000000_type_columns','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','ccc73c5d-d558-4b98-93f1-304f503e3dea'),(159,19,'plugin','m180219_000000_sites','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','4e7a28de-9a40-4079-94b5-f34f818b7b01'),(160,19,'plugin','m180220_000000_fix_context','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','a8178d12-3f2b-4b59-8083-c689713fbed8'),(161,19,'plugin','m190117_000000_soft_deletes','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','a15e91f0-cdff-419a-9e5a-579fa6b87431'),(162,19,'plugin','m190117_000001_context_to_uids','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','5ae8498a-e6b3-4728-81e8-ac371dc5bf9a'),(163,19,'plugin','m190120_000000_fix_supertablecontent_tables','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','41ee499a-daf6-4e02-946c-3ea2647a3d42'),(164,19,'plugin','m190131_000000_fix_supertable_missing_fields','2019-02-05 16:43:30','2019-02-05 16:43:30','2019-02-05 16:43:30','7b760f71-1410-483c-a6c2-644f10c22a12');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'sprout-fields','3.2.1','3.2.0','unknown',NULL,'2019-02-05 16:41:56','2019-02-05 16:41:56','2019-02-05 16:46:44','62b4a5bb-2eee-4075-9285-859953ef2f3a'),(2,'architect','2.2.12','2.0.0','unknown',NULL,'2019-02-05 16:42:32','2019-02-05 16:42:32','2019-02-05 16:46:44','24131836-de96-40d1-8b31-ab0b7f5f4778'),(3,'async-queue','2.0.0','1.0.0','unknown',NULL,'2019-02-05 16:42:33','2019-02-05 16:42:33','2019-02-05 16:46:44','7ab27213-17ba-41c9-8f26-e02f969b1c3c'),(4,'colour-swatches','1.2.0','1.0.0','unknown',NULL,'2019-02-05 16:42:35','2019-02-05 16:42:35','2019-02-05 16:46:44','c910c056-b33d-4d09-8442-3306e9194d16'),(5,'contact-form','2.2.3','1.0.0','unknown',NULL,'2019-02-05 16:42:37','2019-02-05 16:42:37','2019-02-05 16:46:44','2fb797fb-e917-4c79-803b-7de9440e8d9f'),(6,'contact-form-extensions','1.1.0','1.0.0','unknown',NULL,'2019-02-05 16:42:39','2019-02-05 16:42:39','2019-02-05 16:46:44','987496ed-c77c-461e-bd3a-ab66291d9657'),(7,'eager-beaver','1.0.4','1.0.0','unknown',NULL,'2019-02-05 16:42:41','2019-02-05 16:42:41','2019-02-05 16:46:44','ff6cd750-fc03-4721-8396-79544820b190'),(8,'expanded-singles','1.0.6','1.0.0','unknown',NULL,'2019-02-05 16:42:44','2019-02-05 16:42:44','2019-02-05 16:46:44','078ea6a2-687e-404a-84fb-e701653997df'),(9,'image-optimize','1.5.1','1.0.0','invalid',NULL,'2019-02-05 16:42:47','2019-02-05 16:42:47','2019-02-05 16:46:44','b3dec3e9-7083-44dc-909d-2705c14a70f2'),(10,'mix','1.5.2','1.0.0','unknown',NULL,'2019-02-05 16:42:54','2019-02-05 16:42:54','2019-02-05 16:46:44','4e4c6691-1334-49a9-9909-e9a83feb6bb7'),(11,'password-policy','1.0.4','1.0.0','unknown',NULL,'2019-02-05 16:42:57','2019-02-05 16:42:57','2019-02-05 16:46:44','9ef1d4d6-0e0e-4c9c-859f-f1de3bc4986c'),(12,'minify','1.2.9','1.0.0','unknown',NULL,'2019-02-05 16:43:00','2019-02-05 16:43:00','2019-02-05 16:46:44','d959ba57-dc71-4177-a1e3-a5278ebd7144'),(13,'position-fieldtype','1.0.14','1.0.0','unknown',NULL,'2019-02-05 16:43:04','2019-02-05 16:43:04','2019-02-05 16:46:44','dda2fb7f-aa94-49f4-ae87-b14ef563cc2b'),(14,'redactor','2.3.1','2.2.1','unknown',NULL,'2019-02-05 16:43:07','2019-02-05 16:43:07','2019-02-05 16:46:44','bf930034-25a2-4d26-aea5-316756f66bf6'),(15,'seomatic','3.1.40','3.0.6','invalid',NULL,'2019-02-05 16:43:11','2019-02-05 16:43:11','2019-02-05 16:46:44','130a58ac-7cdc-4a90-bfba-368e3f6b13d8'),(16,'section-field','1.1.0','0.0.1','unknown',NULL,'2019-02-05 16:43:20','2019-02-05 16:43:20','2019-02-05 16:46:44','3acf45d2-0a02-4a10-84ac-545a4ef0849f'),(17,'typedlinkfield','1.0.16','1.0.0','unknown',NULL,'2019-02-05 16:43:23','2019-02-05 16:43:23','2019-02-05 16:46:44','fc6b9c39-393b-4f87-83e8-a79efb03cc30'),(18,'typogrify','1.1.16','1.0.0','unknown',NULL,'2019-02-05 16:43:26','2019-02-05 16:43:26','2019-02-05 16:46:44','32c2699e-1f50-4906-81d6-21cdcc83ef32'),(19,'super-table','2.1.6','2.0.8','unknown',NULL,'2019-02-05 16:43:29','2019-02-05 16:43:29','2019-02-05 16:46:44','74d0c43b-10e1-416e-bf51-36362218e50a'),(20,'width-fieldtype','1.0.6','1.0.0','unknown',NULL,'2019-02-05 16:43:33','2019-02-05 16:43:33','2019-02-05 16:46:44','e6585492-931d-45f2-9176-4f8a44bc4ac8');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (16,56,4,NULL,5,1,'2019-02-05 17:58:50','2019-02-05 17:58:50','b5e114b1-5698-420f-a6a0-0bb1057072a8'),(17,56,14,NULL,6,1,'2019-02-05 17:58:50','2019-02-05 17:58:50','1299753a-8756-403c-a44a-8cd6fd62a8d9'),(18,56,15,NULL,7,1,'2019-02-05 17:58:50','2019-02-05 17:58:50','8e3d240a-54b4-4f1f-8a9f-0ab0fbfc3724'),(23,61,27,NULL,24,1,'2019-02-05 18:12:38','2019-02-05 18:12:38','8b9fecc6-d82a-4477-bea0-8758996b376f'),(24,61,28,NULL,25,1,'2019-02-05 18:12:38','2019-02-05 18:12:38','3d7ea9a0-5cde-4979-9e4c-d864f5cd82af'),(25,61,29,NULL,26,1,'2019-02-05 18:12:38','2019-02-05 18:12:38','77b14771-68c9-4422-aaf1-235f5eb1e3c7'),(26,25,31,NULL,30,1,'2019-02-05 19:28:24','2019-02-05 19:28:24','10667a90-5f7f-4700-8532-aa57cae78581'),(27,64,34,NULL,40,1,'2019-02-05 19:34:20','2019-02-05 19:34:20','8603d430-ab2b-4d85-9150-df563e6f31ec'),(29,25,41,NULL,30,1,'2019-02-05 20:12:20','2019-02-05 20:12:20','ae558605-49e5-4c1d-a6b2-191d93025584');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `resourcepaths` VALUES ('1345ab8','@vendor/craftcms/redactor/lib/redactor-plugins/video'),('13c48196','@lib/jquery-touch-events'),('1460bd54','@lib/picturefill'),('1ac59d05','@lib/d3'),('1cc38d53','@craft/web/assets/utilities/dist'),('1d616b7f','@rias/widthfieldtype/assetbundles/widthfieldtype/dist'),('248a74f9','@craft/web/assets/recententries/dist'),('273117e9','@rias/passwordpolicy/assetbundles/PasswordPolicy/dist'),('29788a83','@lib/garnishjs'),('33f2d6b0','@lib/timepicker'),('35460f21','@pennebaker/architect/assetbundles/indexcpsection/dist'),('3661a05e','@vendor/craftcms/redactor/lib/redactor-plugins/fullscreen'),('3c3e5ebd','@lib/fabric'),('3f4c0578','@app/web/assets/dashboard/dist'),('401e90d0','@lib/selectize'),('446445ef','@craft/web/assets/sites/dist'),('44b447a1','@rias/colourswatches/assetbundles/colourswatchesfield/dist'),('4631b599','@craft/web/assets/cp/dist'),('4a72d45a','@lib/xregexp'),('4af7e635','@lib/fileupload'),('4ffe3669','@app/web/assets/sites/dist'),('521fe7cb','@lib/picturefill'),('52967fba','@craft/web/assets/tablesettings/dist'),('53a19b84','@nystudio107/imageoptimize/assetbundles/imageoptimize/dist'),('549aff94','@nystudio107/seomatic/assetbundles/seomatic/dist'),('55bbdb09','@lib/jquery-touch-events'),('56b7bfd3','@app/web/assets/matrix/dist'),('573dd180','@lib/prismjs'),('59959de7','@app/web/assets/editentry/dist'),('59bd37cc','@lib/datepicker-i18n'),('5abcd7cc','@craft/web/assets/utilities/dist'),('5cbac79a','@lib/d3'),('62f52e66','@craft/web/assets/recententries/dist'),('661ca4f','@lib/selectize'),('69afbfda','@sproutbase/web/assets/cp/dist'),('6e08dc3d','@sitemodule/assetbundles/sitemodule/dist'),('6f07d01c','@lib/garnishjs'),('7a410422','@lib/fabric'),('7a84cdcf','@craft/web/assets/fields/dist'),('7d87486b','@app/web/assets/plugins/dist'),('7e5471a9','@app/web/assets/fields/dist'),('8193b794','@lib/jquery-ui'),('8289fdda','@craft/web/assets/feed/dist'),('833e1d91','@rias/positionfieldtype/assetbundles/positionfieldtype/dist'),('8464ded8','@craft/web/assets/updates/dist'),('855a008a','@app/web/assets/feed/dist'),('894576ae','@lib/velocity'),('8bb11d2e','@vendor/craftcms/redactor/lib/redactor'),('8dd16a8b','@verbb/supertable/resources/dist'),('9562d946','@lib/jquery.payment'),('98ca81d3','@bower/jquery/dist'),('b0a35e69','@sproutbaselib/quill'),('b75a2a26','@lib/element-resize-detector'),('b8a23105','@sproutbase/app/fields/web/assets'),('ba3e11ab','@app/web/assets/cp/dist'),('bd9cc09e','@craft/web/assets/craftsupport/dist'),('bdb5818e','@craft/web/assets/dashboard/dist'),('c00c04c4','@typedlinkfield/resources'),('c0d8ec5','@lib/xregexp'),('c21b8447','@craft/web/assets/updates/dist'),('c4f6a745','@craft/web/assets/feed/dist'),('c7eced0b','@lib/jquery-ui'),('c88bcaa','@lib/fileupload'),('cf3a2c31','@lib/velocity'),('d1248216','@app/web/assets/craftsupport/dist'),('d16f3d65','@app/web/assets/tablesettings/dist'),('d31d83d9','@lib/jquery.payment'),('d65684e0','@rias/widthfieldtype/assetbundles/widthfieldtype/dist/img'),('d6c18918','@sproutbase/app/fields/web/assets/address/dist'),('d845533a','@app/web/assets/utilities/dist'),('d9525cba','@craft/web/assets/plugins/dist'),('deb5db4c','@bower/jquery/dist'),('dfb62ed7','@app/web/assets/updateswidget/dist'),('e10c6cb9','@app/web/assets/recententries/dist'),('e400387d','@craft/web/assets/matrixsettings/dist'),('e69f1ab4','@lib'),('e7996e6c','@nystudio107/imageoptimize/assetbundles/optimizedimagesfield/dist'),('f12570b9','@lib/element-resize-detector'),('f2ef0e7a','@app/web/assets/matrixsettings/dist'),('f6eb80ae','@craft/redactor/assets/field/dist'),('f87f5e4a','@app/web/assets/login/dist'),('fbcadb11','@craft/web/assets/dashboard/dist'),('fbe39a01','@craft/web/assets/craftsupport/dist'),('fc414b34','@app/web/assets/cp/dist'),('fdf175ed','@app/web/assets/editcategory/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' careto '),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'fullname',0,1,''),(1,'email',0,1,' development dadamotion be '),(1,'slug',0,1,''),(2,'slug',0,1,' homepage '),(2,'title',0,1,' homepage '),(3,'slug',0,1,''),(3,'field',3,1,''),(3,'field',1,1,''),(3,'field',24,1,''),(3,'field',38,1,''),(2,'field',36,1,''),(2,'field',37,1,''),(2,'field',25,1,''),(2,'field',26,1,''),(2,'field',29,1,''),(2,'field',49,1,''),(2,'field',23,1,''),(2,'field',51,1,''),(2,'field',50,1,''),(2,'field',52,1,''),(2,'field',27,1,''),(2,'field',45,1,''),(2,'field',28,1,''),(2,'field',44,1,''),(2,'field',39,1,''),(2,'field',40,1,''),(2,'field',53,1,' soms heeft een zoektocht een gids nodig http careto test familiale bemiddeling ben je de weg kwijt voel je je eenzaam en onbegrepen twijfel je aan jezelf voel je je uitgeblust is de magie uit jullie relatie verdwenen ontbreekt het je aan levenslust stel je vragen bij je toekomst weet je iedereen verdient gelukkig te zijn en dit ook te voelen bij careto ondersteunen we koppels kinderen ouders en individuen in hun zoektocht naar hun eigen geluk scheiden brengt veel zorgen onzekerheden en verdriet met zich mee dikwijls ontstaat er ook een strijd die niet alleen emotioneel maar ook financieel uitputtend kan zijn bemiddeling houdt jullie uit de strijd met elkaar de bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex partner en ouder left homepage_1 zing je eigen lied dans je eigen dans wanneer een moeilijke fase je leven binnensluipt hebben jouw emoties zorg en aandacht nodig careto is een ruimte waar je even tot rust kan komen vrij en on over je emoties kan spreken een plaats waar alles mag zijn en niets moet een plek waar je gedachten angsten boosheid verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt right homepage_2 verandering begint bij jezelf eenzaam in de relatie geen uitweg meer in de sleur van het dagdagelijks leven hoe moet het verder met jullie relatie na ontrouw van je partner het gevoel als broer en zus te leven jullie zijn niet de enige met dit probleem dagelijks wordt je geconfronteerd met ruzies die jullie uitputten en waarvoor geen oplossing lijkt te zijn wat is jullie toekomst nog samen soms gaan koppels uit voorzorg in therapie om de relatie te verrijken bespreek het met onze therapeut right homepage_3 '),(4,'field',54,1,' soms heeft een zoektocht een gids nodig '),(4,'field',55,1,' ben je de weg kwijt voel je je eenzaam en onbegrepen twijfel je aan jezelf voel je je uitgeblust is de magie uit jullie relatie verdwenen ontbreekt het je aan levenslust stel je vragen bij je toekomst weet je iedereen verdient gelukkig te zijn en dit ook te voelen bij careto ondersteunen we koppels kinderen ouders en individuen in hun zoektocht naar hun eigen geluk scheiden brengt veel zorgen onzekerheden en verdriet met zich mee dikwijls ontstaat er ook een strijd die niet alleen emotioneel maar ook financieel uitputtend kan zijn bemiddeling houdt jullie uit de strijd met elkaar de bemiddelaar ondersteunt jullie in het zoeken naar de best mogelijke oplossingen voor jullie toekomst als ex partner en ouder '),(4,'field',56,1,' homepage_1 '),(4,'field',57,1,' left '),(4,'slug',0,1,''),(5,'filename',0,1,' homepage_1 mp4 '),(5,'extension',0,1,' mp4 '),(5,'kind',0,1,' video '),(5,'slug',0,1,''),(5,'title',0,1,' homepage_1 '),(6,'filename',0,1,' homepage_2 mp4 '),(6,'extension',0,1,' mp4 '),(6,'kind',0,1,' video '),(6,'slug',0,1,''),(6,'title',0,1,' homepage_2 '),(7,'filename',0,1,' homepage_3 mp4 '),(7,'extension',0,1,' mp4 '),(7,'kind',0,1,' video '),(7,'slug',0,1,''),(7,'title',0,1,' homepage_3 '),(8,'filename',0,1,' homepage_4 mp4 '),(8,'extension',0,1,' mp4 '),(8,'kind',0,1,' video '),(8,'slug',0,1,''),(8,'title',0,1,' homepage_4 '),(9,'filename',0,1,' homepage_5 mp4 '),(9,'extension',0,1,' mp4 '),(9,'kind',0,1,' video '),(9,'slug',0,1,''),(9,'title',0,1,' homepage_5 '),(10,'filename',0,1,' homepage_6 mp4 '),(10,'extension',0,1,' mp4 '),(10,'kind',0,1,' video '),(10,'slug',0,1,''),(10,'title',0,1,' homepage_6 '),(11,'filename',0,1,' homepage_7 mp4 '),(11,'extension',0,1,' mp4 '),(11,'kind',0,1,' video '),(11,'slug',0,1,''),(11,'title',0,1,' homepage_7 '),(12,'filename',0,1,' homepage_8 mp4 '),(12,'extension',0,1,' mp4 '),(12,'kind',0,1,' video '),(12,'slug',0,1,''),(12,'title',0,1,' homepage_8 '),(13,'filename',0,1,' homepage_9 mp4 '),(13,'extension',0,1,' mp4 '),(13,'kind',0,1,' video '),(13,'slug',0,1,''),(13,'title',0,1,' homepage_9 '),(14,'field',54,1,' zing je eigen lied dans je eigen dans '),(14,'field',55,1,' wanneer een moeilijke fase je leven binnensluipt hebben jouw emoties zorg en aandacht nodig careto is een ruimte waar je even tot rust kan komen vrij en on over je emoties kan spreken een plaats waar alles mag zijn en niets moet een plek waar je gedachten angsten boosheid verdriet en vreugde de vrije loop kunnen gaan zodat de energie terug in jezelf gaat stromen en beweging in je leven brengt '),(14,'field',56,1,' homepage_2 '),(14,'field',57,1,' right '),(14,'slug',0,1,''),(15,'field',54,1,' verandering begint bij jezelf eenzaam in de relatie '),(15,'field',55,1,' geen uitweg meer in de sleur van het dagdagelijks leven hoe moet het verder met jullie relatie na ontrouw van je partner het gevoel als broer en zus te leven jullie zijn niet de enige met dit probleem dagelijks wordt je geconfronteerd met ruzies die jullie uitputten en waarvoor geen oplossing lijkt te zijn wat is jullie toekomst nog samen soms gaan koppels uit voorzorg in therapie om de relatie te verrijken bespreek het met onze therapeut '),(15,'field',56,1,' homepage_3 '),(15,'field',57,1,' right '),(15,'slug',0,1,''),(16,'field',46,1,''),(16,'slug',0,1,''),(16,'field',58,1,' facebook https facebook com instagram https instagram com '),(17,'field',59,1,' facebook '),(17,'field',60,1,' https facebook com '),(17,'slug',0,1,''),(18,'field',59,1,' instagram '),(18,'field',60,1,' https instagram com '),(18,'slug',0,1,''),(19,'field',53,1,' individuele therapie_subpage_1 familiale bemiddeling http careto test familiale bemiddeling familiale bemiddeling lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros left individuele therapie_subpage_2 heading 2 rechts lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros right individuele therapie_subpage_3 heading 3 links lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros left '),(19,'slug',0,1,' familiale bemiddeling '),(19,'title',0,1,' familiale bemiddeling '),(20,'field',53,1,''),(20,'slug',0,1,' individuele therapie '),(20,'title',0,1,' individuele therapie '),(21,'field',53,1,''),(21,'slug',0,1,' relatietherapie '),(21,'title',0,1,' relatietherapie '),(22,'field',53,1,''),(22,'slug',0,1,' love2us '),(22,'title',0,1,' love2us '),(23,'field',53,1,''),(23,'slug',0,1,' bedrijfstherapie '),(23,'title',0,1,' bedrijfstherapie '),(4,'field',61,1,''),(4,'field',63,1,' http careto test familiale bemiddeling '),(14,'field',61,1,''),(14,'field',63,1,''),(15,'field',61,1,''),(15,'field',63,1,''),(24,'field',31,1,''),(24,'filename',0,1,' individueletherapie_subpage_1 jpg '),(24,'extension',0,1,' jpg '),(24,'kind',0,1,' image '),(24,'slug',0,1,''),(24,'title',0,1,' individuele therapie_subpage_1 '),(25,'field',31,1,''),(25,'filename',0,1,' individueletherapie_subpage_2 jpg '),(25,'extension',0,1,' jpg '),(25,'kind',0,1,' image '),(25,'slug',0,1,''),(25,'title',0,1,' individuele therapie_subpage_2 '),(26,'field',31,1,''),(26,'filename',0,1,' individueletherapie_subpage_3 jpg '),(26,'extension',0,1,' jpg '),(26,'kind',0,1,' image '),(26,'slug',0,1,''),(26,'title',0,1,' individuele therapie_subpage_3 '),(27,'field',54,1,' familiale bemiddeling '),(27,'field',55,1,' lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros '),(27,'field',61,1,' individuele therapie_subpage_1 '),(27,'field',56,1,''),(27,'field',57,1,' left '),(27,'field',63,1,' http careto test familiale bemiddeling familiale bemiddeling '),(27,'slug',0,1,''),(28,'field',54,1,' heading 2 rechts '),(28,'field',55,1,' lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros '),(28,'field',61,1,' individuele therapie_subpage_2 '),(28,'field',56,1,''),(28,'field',57,1,' right '),(28,'field',63,1,''),(28,'slug',0,1,''),(29,'field',54,1,' heading 3 links '),(29,'field',55,1,' lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros '),(29,'field',61,1,' individuele therapie_subpage_3 '),(29,'field',56,1,''),(29,'field',57,1,' left '),(29,'field',63,1,''),(29,'slug',0,1,''),(30,'field',30,1,''),(30,'filename',0,1,' individueletherapie_subpage_2 jpg '),(30,'extension',0,1,' jpg '),(30,'kind',0,1,' image '),(30,'slug',0,1,''),(30,'title',0,1,' individuele therapie_subpage_2 '),(31,'field',25,1,' individuele therapie_subpage_2 '),(31,'field',36,1,''),(31,'field',37,1,''),(31,'field',4,1,' heading lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros subtitel full full '),(32,'field',5,1,' heading '),(32,'slug',0,1,''),(33,'field',6,1,''),(33,'field',7,1,' subtitel '),(33,'field',8,1,' lorem ipsum dolor sit amet consectetur adipiscing elit curabitur justo mi dictum nec sem nec scelerisque lobortis mi pellentesque eget nulla mattis cursus risus in bibendum mauris phasellus hendrerit venenatis feugiat etiam semper ex consequat iaculis ullamcorper cras porttitor bibendum tristique sed aliquam dui purus nec iaculis lorem consequat quis etiam cursus risus nec consectetur pharetra aliquam tempor diam porta felis lobortis pulvinar sed in eros '),(33,'field',9,1,' full '),(33,'field',10,1,' full '),(33,'field',11,1,''),(33,'slug',0,1,''),(31,'slug',0,1,' familiale bemiddeling '),(31,'title',0,1,' familiale bemiddeling info '),(34,'field',64,1,' careto logo '),(34,'slug',0,1,''),(35,'slug',0,1,' bemiddeling '),(35,'title',0,1,' bemiddeling '),(36,'slug',0,1,' relatie '),(36,'title',0,1,' relatie '),(37,'slug',0,1,' bedrijf '),(37,'title',0,1,' bedrijf '),(38,'slug',0,1,' opvoeding '),(38,'title',0,1,' opvoeding '),(39,'slug',0,1,' therapie '),(39,'title',0,1,' therapie '),(40,'field',31,1,''),(40,'filename',0,1,' careto logo svg '),(40,'extension',0,1,' svg '),(40,'kind',0,1,' image '),(40,'slug',0,1,''),(40,'title',0,1,' careto logo '),(41,'slug',0,1,' contact '),(41,'title',0,1,' contact '),(41,'field',36,1,''),(41,'field',37,1,' contacteer careto '),(41,'field',25,1,' individuele therapie_subpage_2 '),(41,'field',26,1,''),(41,'field',49,1,' contact '),(41,'field',23,1,' contacteer careto ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Blog','blog','channel',1,1,'2019-02-05 16:45:05','2019-02-05 16:45:05',NULL,'281d49cb-e385-451c-938b-cb4641235de8'),(2,NULL,'Homepage','home','single',1,1,'2019-02-05 16:45:06','2019-02-05 17:02:24',NULL,'3d17d5f1-283c-4ec6-86a2-0eb706954987'),(3,2,'Pagina\'s ','contentPages','structure',1,1,'2019-02-05 17:37:57','2019-02-05 17:55:50',NULL,'f0c4afcd-2924-4918-991b-d4a4bc327d11'),(4,NULL,'Contact','contact','single',1,1,'2019-02-05 20:09:34','2019-02-05 20:09:34',NULL,'b59151a4-05d6-4aaa-b351-459eb5916cd6');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'blog/{slug}','blog/_entry',1,'2019-02-05 16:45:05','2019-02-05 16:45:05','f31fcaed-b43d-4bd1-8ebd-3651f0cf5498'),(2,2,1,1,'__home__','index',1,'2019-02-05 16:45:06','2019-02-05 17:02:24','672e181c-ed89-42e4-aeb3-5fbbb4f17ff1'),(3,3,1,1,'{parent.uri ?? parent.uri}/{slug}','content/_entry',1,'2019-02-05 17:37:57','2019-02-05 17:55:50','5804213e-51bc-4610-9d62-72757ad63928'),(4,4,1,1,'contact','contact/index',1,'2019-02-05 20:09:34','2019-02-05 20:09:34','a9ee8760-15ca-4f37-bb18-822a9f95edd6');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seomatic_metabundles`
--

LOCK TABLES `seomatic_metabundles` WRITE;
/*!40000 ALTER TABLE `seomatic_metabundles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `seomatic_metabundles` VALUES (1,'2019-02-05 16:43:11','2019-02-05 16:43:11','901c59a8-2dd8-4e85-bad0-a382820f2866','1.0.46','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','',1,'[]','2019-02-05 16:43:11','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"before\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{seomatic.helper.safeCanonicalUrl()}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"CareTo\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]}},\"keywords\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoKeywords}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null},\"description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoDescription}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null},\"referrer\":{\"charset\":\"\",\"content\":\"no-referrer-when-downgrade\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null},\"robots\":{\"charset\":\"\",\"content\":\"{seomatic.meta.robots}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{seomatic.meta.robots}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookProfileId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookAppId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null},\"og:site_name\":{\"charset\":\"\",\"content\":\"{seomatic.site.siteName}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null},\"og:type\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogType}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null},\"og:url\":{\"charset\":\"\",\"content\":\"{seomatic.meta.canonicalUrl}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null},\"og:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.ogSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.ogTitle}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null},\"og:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null},\"og:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImage}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null},\"og:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageWidth}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageHeight}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterCard}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{seomatic.site.twitterHandle}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]}},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{seomatic.meta.twitterCreator}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]}},\"twitter:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.twitterSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.twitterTitle}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null},\"twitter:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null},\"twitter:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImage}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageWidth}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageHeight}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.googleSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]}},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.bingSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]}},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.pinterestSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]}}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{seomatic.meta.canonicalUrl}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ siteUrl }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ url(\\\"/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]}},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{seomatic.site.googlePublisherLink}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]}}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"googleAnalytics\":{\"name\":\"Google Analytics\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https://www.google.com/analytics/analytics/)\",\"templatePath\":\"_frontend/scripts/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not craft.app.request.isLivePreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.google-analytics.com/analytics.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https://developers.google.com/gtagjs/)\",\"templatePath\":\"_frontend/scripts/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not craft.app.request.isLivePreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https://developers.google.com/adwords-remarketing-tag/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https://support.google.com/dcm/partner/answer/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtag/js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https://support.google.com/tagmanager/answer/6102821?hl=en)\",\"templatePath\":\"_frontend/scripts/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"></iframe></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https://developers.google.com/tag-manager/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dl\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/ns.html\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https://www.facebook.com/business/help/651294705016616)\",\"templatePath\":\"_frontend/scripts/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not craft.app.request.isLivePreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.facebook.com/docs/facebook-pixel/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://connect.facebook.net/en_US/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.facebook.com/tr\"}},\"dataLayer\":[],\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend/scripts/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n</script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" />\\n</noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://www.linkedin.com/help/lms/answer/65513/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://snap.licdn.com/li.lms-analytics/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://dc.ads.linkedin.com/collect/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://knowledge.hubspot.com/articles/kcs_article/reports/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"//js.hs-scripts.com/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"issn\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":null,\"creator\":{\"id\":\"{seomatic.site.creator.genericUrl}#creator\"},\"dateCreated\":null,\"dateModified\":null,\"datePublished\":null,\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"exampleOfWork\":null,\"expires\":null,\"fileFormat\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":null,\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":null,\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sourceOrganization\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null},\"identity\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.identity.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.identity.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.identity.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.identity.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.identity.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"duns\":\"{seomatic.site.identity.organizationDuns}\",\"email\":\"{seomatic.site.identity.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.identity.organizationFounder}\",\"foundingDate\":\"{seomatic.site.identity.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.identity.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"isicV4\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.identity.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.identity.genericAlternateName}\",\"description\":\"{seomatic.site.identity.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.identity.genericImage}\",\"width\":\"{seomatic.site.identity.genericImageWidth}\",\"height\":\"{seomatic.site.identity.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.identity.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"url\":\"{seomatic.site.identity.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.identity.computedType}\",\"id\":\"{seomatic.site.identity.genericUrl}#identity\",\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null},\"creator\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.creator.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.creator.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.creator.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.creator.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.creator.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"duns\":\"{seomatic.site.creator.organizationDuns}\",\"email\":\"{seomatic.site.creator.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.creator.organizationFounder}\",\"foundingDate\":\"{seomatic.site.creator.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.creator.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"isicV4\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.creator.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.creator.genericAlternateName}\",\"description\":\"{seomatic.site.creator.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.creator.genericImage}\",\"width\":\"{seomatic.site.creator.genericImageWidth}\",\"height\":\"{seomatic.site.creator.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.creator.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"url\":\"{seomatic.site.creator.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.creator.computedType}\",\"id\":\"{seomatic.site.creator.genericUrl}#creator\",\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"/* TEAM */\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n/a\\\" }}\\nURL: {{ seomatic.site.creator.genericUrl ?? \\\"n/a\\\" }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n/a\\\" }}\\n\\n/* THANKS */\\n\\nCraftCMS - https://craftcms.com\\nPixel & Tonic - https://pixelandtonic.com\\n\\n/* SITE */\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 3, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend/pages/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ siteUrl }}\\n\\nSitemap: {{ seomatic.helper.sitemapIndexForSiteId() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n# live - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\n\\n{% case \\\"staging\\\" %}\\n\\n# staging - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% case \\\"local\\\" %}\\n\\n# local - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% default %}\\n\\n# default - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\n\\n{% endswitch %}\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend/pages/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ siteUrl }}\\n# More info: https://support.google.com/admanager/answer/7441288?hl=en\\n{{ siteUrl }},123,DIRECT\\n\",\"siteId\":null,\"include\":true,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend/pages/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(2,'2019-02-05 16:45:05','2019-02-05 16:45:05','c03e337b-a2e7-44ef-a911-2ca410748d17','1.0.28','section',1,'Blog','blog','channel','blog/_entry',1,'{\"1\":{\"id\":\"1\",\"sectionId\":\"1\",\"siteId\":\"1\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"blog/{slug}\",\"template\":\"blog/_entry\",\"language\":\"en-us\"}}','2019-02-05 16:45:05','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"CareTo\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate |atom}\",\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"exampleOfWork\":null,\"expires\":null,\"fileFormat\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sourceOrganization\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(3,'2019-02-05 16:45:06','2019-02-05 17:58:50','6e297784-a4c6-4315-9e3a-f74ffb7ec062','1.0.28','section',2,'Homepage','home','single','index',1,'{\"1\":{\"id\":\"2\",\"sectionId\":\"2\",\"siteId\":\"1\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"__home__\",\"template\":\"index\",\"language\":\"en-us\"}}','2019-02-05 17:58:50','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"CareTo\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate |atom}\",\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"exampleOfWork\":null,\"expires\":null,\"fileFormat\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sourceOrganization\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(4,'2019-02-05 16:45:07','2019-02-05 19:27:34','5042c6f5-4077-4244-936a-e66807ab20ce','1.0.25','categorygroup',1,'Blog','blog','category','blog/_category',1,'{\"1\":{\"id\":1,\"groupId\":1,\"siteId\":1,\"hasUrls\":1,\"uriFormat\":\"blog/{slug}\",\"template\":\"blog/_category\",\"language\":\"en-us\"}}','2019-02-05 19:27:34','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{category.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{category.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"CareTo\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{category.postDate |atom}\",\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{category.dateUpdated |atom}\",\"datePublished\":\"{category.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"exampleOfWork\":null,\"expires\":null,\"fileFormat\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sourceOrganization\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(5,'2019-02-05 17:37:57','2019-02-05 19:28:24','fd727d32-61d8-47fb-937b-0bc08ee5adc0','1.0.28','section',3,'Pagina\'s ','contentPages','structure','',1,'{\"1\":{\"id\":\"3\",\"sectionId\":\"3\",\"siteId\":\"1\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"pagina-s/{slug}\",\"template\":\"\",\"language\":\"en-us\"}}','2019-02-05 19:28:24','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"CareTo\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate |atom}\",\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"exampleOfWork\":null,\"expires\":null,\"fileFormat\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sourceOrganization\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(6,'2019-02-05 20:09:34','2019-02-05 20:12:20','88ffb5b4-d3fd-4040-a7f9-3b8b2b386154','1.0.28','section',4,'Contact','contact','single','contact/index',1,'{\"1\":{\"id\":\"4\",\"sectionId\":\"4\",\"siteId\":\"1\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"contact\",\"template\":\"contact/index\",\"language\":\"en-us\"}}','2019-02-05 20:12:20','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"CareTo\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate |atom}\",\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"exampleOfWork\":null,\"expires\":null,\"fileFormat\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sourceOrganization\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
/*!40000 ALTER TABLE `seomatic_metabundles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'CareTo','2019-02-05 15:44:19','2019-02-05 15:44:19',NULL,'5bbd509f-fb1f-4adc-af04-5d7ba96cd4d8');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'CareTo','default','en-US',1,'$DEFAULT_SITE_URL',1,'2019-02-05 15:44:19','2019-02-05 15:44:19',NULL,'1503eb24-9970-44bf-87f1-55f1b103e228');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sproutfields_addresses`
--

LOCK TABLES `sproutfields_addresses` WRITE;
/*!40000 ALTER TABLE `sproutfields_addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sproutfields_addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,2,NULL,1,1,14,0,'2019-02-05 17:44:56','2019-02-05 18:10:22','c3371d23-7ba6-4788-8198-53c686011b83'),(2,2,19,1,2,5,1,'2019-02-05 17:44:56','2019-02-05 18:10:22','b1b5febb-b0fb-448f-b38f-ee70ab24fdba'),(3,2,20,1,6,7,1,'2019-02-05 17:45:08','2019-02-05 18:10:22','005b8174-fc76-486e-b656-5ed6a91d8577'),(4,2,21,1,8,9,1,'2019-02-05 17:45:13','2019-02-05 18:10:22','d2e79bb7-398d-42a7-b60a-ba64097b6295'),(5,2,22,1,10,11,1,'2019-02-05 17:45:30','2019-02-05 18:10:22','90cffd5d-3cfb-435e-8fff-8c12aae5e3a5'),(6,2,23,1,12,13,1,'2019-02-05 17:45:42','2019-02-05 18:10:22','4ec918ac-d3bb-4c96-a4bb-616da9ef0cd8'),(7,2,31,1,3,4,2,'2019-02-05 18:10:22','2019-02-05 18:10:22','1379c198-74d6-4782-8b41-2d8986cdfd60'),(8,1,NULL,8,1,12,0,'2019-02-05 19:27:05','2019-02-05 19:27:34','a7280a75-8593-450d-8b21-7f81fe539aaa'),(9,1,35,8,2,3,1,'2019-02-05 19:27:05','2019-02-05 19:27:05','5e155cbf-4ef8-498f-a330-68792c91e32b'),(10,1,36,8,4,5,1,'2019-02-05 19:27:14','2019-02-05 19:27:14','8f14c4f9-eeda-4269-b7ab-6c6e4896a609'),(11,1,37,8,6,7,1,'2019-02-05 19:27:17','2019-02-05 19:27:17','fdc4991a-e3ba-4a00-be10-a4c51ba40f80'),(12,1,38,8,8,9,1,'2019-02-05 19:27:30','2019-02-05 19:27:30','40fbd389-3389-42e2-849a-6f229844eb81'),(13,1,39,8,10,11,1,'2019-02-05 19:27:34','2019-02-05 19:27:34','92a15917-f6d9-4de8-bf56-17d6e2304c03');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,1,'2019-02-05 16:45:07','2019-02-05 16:45:11',NULL,'24331ae6-0850-40a6-a251-a2d6c36d5230'),(2,2,'2019-02-05 17:37:57','2019-02-05 17:55:50',NULL,'b0b07e93-d6ca-42cb-994d-f0360f175d01');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `supertableblocks`
--

LOCK TABLES `supertableblocks` WRITE;
/*!40000 ALTER TABLE `supertableblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `supertableblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `supertableblocktypes`
--

LOCK TABLES `supertableblocktypes` WRITE;
/*!40000 ALTER TABLE `supertableblocktypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `supertableblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,'careto',NULL,NULL,NULL,'development@dadamotion.be','$2y$13$IiQaJ0iOB541tsa2LN8kUe5PhO6i08WpHzpKbo.eAhuz9yrqanuUW',1,0,0,0,'2019-02-05 16:02:12',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2019-02-05 15:44:19','2019-02-05 15:44:19','2019-02-05 16:02:12','74aa9e1f-1429-427e-9a9f-76db93f4c547');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images','','2019-02-05 16:45:07','2019-02-05 16:45:11','cac88847-2145-4ce7-85c2-a74102afca8f'),(2,NULL,2,'Videos','','2019-02-05 16:45:07','2019-02-05 16:54:20','29181bf5-4139-4297-aecc-b85431835b78'),(3,NULL,3,'Hero Images','','2019-02-05 16:45:07','2019-02-05 16:45:11','526475df-9f6b-4be3-a324-7736a64c083a'),(4,NULL,4,'Service Images','','2019-02-05 16:45:07','2019-02-05 16:45:11','4c0d1222-0cb2-42c8-9d87-eb7eb590e273'),(5,NULL,5,'Overview images','','2019-02-05 16:45:07','2019-02-05 16:45:11','0bf972d8-05a1-4719-b13d-735711ab6e28'),(6,NULL,6,'Video Thumbnails','','2019-02-05 16:45:07','2019-02-05 16:45:11','e737e26f-6260-4a84-ab5c-3cee41ff7c75'),(7,NULL,NULL,'Temporary source',NULL,'2019-02-05 16:51:13','2019-02-05 16:51:13','37318026-1508-4ec8-a3fc-e210f8007fb6'),(8,7,NULL,'user_1','user_1/','2019-02-05 16:51:13','2019-02-05 16:51:13','b71394d5-ca50-4b06-a75e-f6b156d8ce64'),(9,NULL,7,'Full Page','','2019-02-05 17:43:54','2019-02-05 17:43:54','d56bee7e-3e36-45e7-a6aa-a445b9c9c22b');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,8,'Images','images','craft\\volumes\\Local',1,'@baseUrl/assets/img/uploads/general','{\"path\":\"@basePath/assets/img/uploads/general\"}',NULL,'2019-02-05 16:45:07','2019-02-05 16:45:11',NULL,'a191c99d-cf7a-4919-a0e9-82fd99da791c'),(2,NULL,'Videos','videos','craft\\volumes\\Local',1,'@baseUrl/assets/uploads/videos','{\"path\":\"@basePath/assets/uploads/videos\"}',NULL,'2019-02-05 16:45:07','2019-02-05 16:54:20',NULL,'7abe41af-4979-4ac8-be5e-8c0c85a91dd3'),(3,9,'Hero Images','heroImages','craft\\volumes\\Local',1,'@baseUrl/assets/img/uploads/hero','{\"path\":\"@basePath/assets/img/uploads/hero\"}',NULL,'2019-02-05 16:45:07','2019-02-05 16:45:11',NULL,'3ae495a2-3065-4cbf-a837-37ac98b1267f'),(4,10,'Service Images','serviceImages','craft\\volumes\\Local',1,'@baseUrl/assets/img/uploads/services','{\"path\":\"@basePath/assets/img/uploads/services\"}',NULL,'2019-02-05 16:45:07','2019-02-05 16:45:11','2019-02-05 16:54:05','52dc81e2-fba5-448f-8827-2cde4e2ef7a3'),(5,11,'Overview images','overviewImages','craft\\volumes\\Local',1,'@baseUrl/assets/img/uploads/teaser','{\"path\":\"@basePath/assets/img/uploads/teaser\"}',NULL,'2019-02-05 16:45:07','2019-02-05 16:45:11',NULL,'912b07d6-4f72-4970-9809-cc4258aeade8'),(6,12,'Video Thumbnails','videoThumbnails','craft\\volumes\\Local',1,'@baseUrl/assets/videos/thumbnails','{\"path\":\"@basePath/assets/videos/thumbnails\"}',NULL,'2019-02-05 16:45:07','2019-02-05 16:45:11','2019-02-05 16:54:01','c94ebff4-b2ef-483a-aa76-81aea5d608ac'),(7,NULL,'Full Page','fullPage','craft\\volumes\\Local',1,'@baseUrl/assets/img/uploads/full','{\"path\":\"@basePath/assets/img/uploads/full\"}',NULL,'2019-02-05 17:43:54','2019-02-05 17:43:54',NULL,'a5808c2c-206f-4161-af1b-06cf7d9a0e13');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2019-02-05 16:02:12','2019-02-05 16:02:12','62dd89ab-ecbb-46ab-9fe5-3ccc9555bb33'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2019-02-05 16:02:12','2019-02-05 16:02:12','0c6fe97f-a65e-424d-9930-e0a6e475f3a9'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2019-02-05 16:02:12','2019-02-05 16:02:12','56ea3ea1-9d7b-4cd1-9125-f5ef8d24abed'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2019-02-05 16:02:12','2019-02-05 16:02:12','c616235f-27de-4015-ac3a-8299aff6d2fc');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'careto'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-05 21:17:17
